using System;
using DotnetUserGroup.DataAccess.WcfProviders.Common;
using DotnetUserGroup.DataAccess.WcfProviders.Events;

namespace ConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            EventServiceHost.Instance.StartEventService();
            Console.WriteLine("Running...");
            Console.WriteLine("[ Press Enter to End ]");
            Console.ReadLine();
            EventServiceHost.Instance.StopEventService();
        }
    }
}
