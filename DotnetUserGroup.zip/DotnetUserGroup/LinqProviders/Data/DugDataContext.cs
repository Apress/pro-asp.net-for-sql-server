using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using System.Query;
using System.Expressions;
using System.Data;
using System.Data.DLinq;
using DotnetUserGroup.DataAccess.LinqProviders.Common;

namespace DotnetUserGroup.DataAccess.LinqProviders.Data
{
    public class DugDataContext : DataContext
    {

        #region "  Constructors  "

        public DugDataContext(string connection)
            : base(connection)
        {
        }

        public DugDataContext(System.Data.IDbConnection connection)
            : base(connection)
        {
        }

        public DugDataContext(string connection, MappingSource mappingSource)
            : base(connection, mappingSource)
        {
        }

        public DugDataContext(
            IDbConnection connection, MappingSource mappingSource)
            : base(connection, mappingSource)
        {
        }

        #endregion

        #region "  Methods  "

        [StoredProcedure(Name = "dug_GetEvent")]
        public StoredProcedureResult<EventResult> GetEvent(
            [Parameter(Name = "EventID", DBType = "BigInt")] 
            System.Nullable<long> eventID)
        {
            return this.ExecuteStoredProcedure<EventResult>(
                ((MethodInfo)(MethodInfo.GetCurrentMethod())), eventID);
        }

        [StoredProcedure(Name = "dug_GetEventsByDate")]
        public StoredProcedureResult<EventResult> GetEventsByDate(
            [Parameter(Name = "TargetDate", DBType = "DateTime")] 
            System.Nullable<System.DateTime> targetDate)
        {
            return this.ExecuteStoredProcedure<EventResult>(
                ((MethodInfo)(MethodInfo.GetCurrentMethod())), targetDate);
        }

        [StoredProcedure(Name = "dug_GetAllEvents")]
        public StoredProcedureResult<EventResult> GetAllEvents()
        {
            return this.ExecuteStoredProcedure<EventResult>(
                ((MethodInfo)(MethodInfo.GetCurrentMethod())));
        }

        [StoredProcedure(Name = "dug_SaveEvent")]
        public int SaveEvent(
            [Parameter(Name = "Title", DBType = "NVarChar(50)")] 
            string title, 
            [Parameter(Name = "Description", DBType = "Text")] 
            string description, 
            [Parameter(Name = "MeetingDate", DBType = "DateTime")] 
            System.Nullable<System.DateTime> meetingDate, 
            [Parameter(Name = "SpeakerID", DBType = "BigInt")] 
            System.Nullable<long> speakerID, 
            [Parameter(Name = "SponsorID", DBType = "BigInt")] 
            System.Nullable<long> sponsorID, 
            [Parameter(Name = "LocationID", DBType = "BigInt")] 
            System.Nullable<long> locationID, 
            [Parameter(Name = "OldEventID", DBType = "BigInt")] 
            System.Nullable<long> oldEventID, 
            [Parameter(Name = "EventID", DBType = "BigInt")] 
            ref System.Nullable<long> eventID)
        {
            StoredProcedureResult result = this.ExecuteStoredProcedure(
                ((MethodInfo)(MethodInfo.GetCurrentMethod())), title, 
                description, meetingDate, speakerID, sponsorID, locationID, 
                oldEventID, eventID);
            eventID = ((System.Nullable<long>)(result.GetParameterValue(7)));
            return result.ReturnValue.Value;
        }

        [StoredProcedure(Name = "dug_DeleteEvent")]
        public int DeleteEvent(
            [Parameter(Name = "EventID", DBType = "BigInt")] 
            System.Nullable<long> eventID)
        {
            StoredProcedureResult result = this.ExecuteStoredProcedure(
                ((MethodInfo)(MethodInfo.GetCurrentMethod())), eventID);
            return result.ReturnValue.Value;
        }

        [StoredProcedure(Name = "dug_IsEventUsingLocation")]
        public StoredProcedureResult<CountResult> IsEventUsingLocation(
            [Parameter(Name = "LocationID", DBType = "BigInt")] 
            System.Nullable<long> locationID)
        {
            return this.ExecuteStoredProcedure<CountResult>(
                ((MethodInfo)(MethodInfo.GetCurrentMethod())), locationID);
        }

        #endregion

    }

}
