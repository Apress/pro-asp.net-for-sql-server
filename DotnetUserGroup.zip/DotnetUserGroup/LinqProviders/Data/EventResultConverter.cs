using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using System.Reflection;
using System.Query;
using System.Expressions;
using System.Data;
using System.Data.DLinq;
using DotnetUserGroup.DataAccess.Events;

namespace DotnetUserGroup.DataAccess.LinqProviders.Data
{
    public static class EventResultConverter
    {

        public static EventCollection ToEventCollection(
            StoredProcedureResult<EventResult> eventResults)
        {
            EventCollection eventCollection = new EventCollection();
            foreach (EventResult eventResult in eventResults)
            {
                eventCollection.Add(Convert(eventResult));
            }
            return eventCollection;
        }

        public static Event Convert(EventResult eventResult)
        {
            Event evt = Event.CreateNewEvent();
            evt.ID.Value = (long) eventResult.ID;
            evt.Title = eventResult.Title;
            evt.MeetingDate = eventResult.MeetingDate;
            evt.Description = eventResult.Description;
            evt.Created = eventResult.Created;
            evt.Modified = eventResult.Modified;
            return evt;
        }

    }
}
