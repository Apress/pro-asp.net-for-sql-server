using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using System.Query;
using System.Expressions;
using System.Data;
using System.Data.DLinq;

namespace DotnetUserGroup.DataAccess.LinqProviders.Data
{
    public class EventResult
    {

        #region "  Variables  "

        private long _ID;

        private string _Title;

        private string _Description;

        private System.DateTime _MeetingDate;

        private System.DateTime _Created;

        private System.DateTime _Modified;

        #endregion
        
        #region "  Constructors  "

        public EventResult()
        {
        }

        #endregion

        #region "  Properties  "

        [Column(Name = "ID", Storage = "_ID", DBType = "BigInt")]
        [DataObjectField(false, false, false)]
        //[Precision(Precision = 19, Scale = 255)]
        public long ID
        {
            get
            {
                return this._ID;
            }
            set
            {
                if ((this._ID != value))
                {
                    this._ID = value;
                }
            }
        }

        [Column(Name = "Title", Storage = "_Title", DBType = "NVarChar(50)")]
        [DataObjectField(false, false, false, 50)]
        public string Title
        {
            get
            {
                return this._Title;
            }
            set
            {
                if ((this._Title != value))
                {
                    this._Title = value;
                }
            }
        }

        [Column(Name = "Description", Storage = "_Description", DBType = "Text")]
        [DataObjectField(false, false, false, 2147483647)]
        public string Description
        {
            get
            {
                return this._Description;
            }
            set
            {
                if ((this._Description != value))
                {
                    this._Description = value;
                }
            }
        }

        [Column(Name = "MeetingDate", Storage = "_MeetingDate", DBType = "DateTime")]
        [DataObjectField(false, false, false)]
        public System.DateTime MeetingDate
        {
            get
            {
                return this._MeetingDate;
            }
            set
            {
                if ((this._MeetingDate != value))
                {
                    this._MeetingDate = value;
                }
            }
        }

        [Column(Name = "Created", Storage = "_Created", DBType = "DateTime")]
        [DataObjectField(false, false, false)]
        public System.DateTime Created
        {
            get
            {
                return this._Created;
            }
            set
            {
                if ((this._Created != value))
                {
                    this._Created = value;
                }
            }
        }

        [Column(Name = "Modified", Storage = "_Modified", DBType = "DateTime")]
        [DataObjectField(false, false, false)]
        public System.DateTime Modified
        {
            get
            {
                return this._Modified;
            }
            set
            {
                if ((this._Modified != value))
                {
                    this._Modified = value;
                }
            }
        }

        #endregion

    }
}
