using System.ComponentModel;
using System.Reflection;
using System.Query;
using System.Expressions;
using System.Data;
using System.Data.DLinq;

namespace DotnetUserGroup.DataAccess.LinqProviders.Common
{
    public class CountResult
    {

        private int _CountResult;

        [Column(Name = "CountResult", Storage = "_CountResult", DBType = "Int")]
        [DataObjectField(false, false, false)]
        //[Precision(Precision = 10, Scale = 255)]
        public int Count
        {
            get
            {
                return this._CountResult;
            }
            set
            {
                if ((this._CountResult != value))
                {
                    this._CountResult = value;
                }
            }
        }


    }
}
