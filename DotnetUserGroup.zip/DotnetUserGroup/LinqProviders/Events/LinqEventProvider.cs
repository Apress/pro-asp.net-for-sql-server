using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Configuration.Provider;
using System.ComponentModel;
using System.Reflection;
using System.Query;
using System.Expressions;
using System.Data;
using System.Data.DLinq;
using System.Web;
using System.Web.Configuration;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Events;
using DotnetUserGroup.DataAccess.Locations;
using DotnetUserGroup.DataAccess.LinqProviders.Common;
using DotnetUserGroup.DataAccess.LinqProviders.Data;

namespace DotnetUserGroup.DataAccess.LinqProviders.Events
{
    public class LinqEventProvider : EventProvider
    {

        #region "  Variables  "

        private string connStringName = String.Empty;
        private DugDataContext db;

        #endregion

        #region "  Provider Methods  "

        /// <summary>
        /// SQL Implementation
        /// </summary>
        public override void Initialize(string name,
            NameValueCollection config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            if (String.IsNullOrEmpty(name))
            {
                name = "LinqEventProvider";
            }

            if (String.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "LINQ Events Provider");
            }

            base.Initialize(name, config);

            connStringName = config["connectionStringName"].ToString();
            config.Remove("connectionStringName");

            if (WebConfigurationManager.ConnectionStrings[connStringName] == null)
            {
                throw new ProviderException("Missing connection string");
            }
            
            string connString = ConfigurationManager.
                ConnectionStrings[connStringName].ConnectionString;
            db = new DugDataContext(connString);

            if (config.Count > 0)
            {
                string attr = config.GetKey(0);
                if (!String.IsNullOrEmpty(attr))
                {
                    throw new ProviderException("Unrecognized attribute: " + attr);
                }
            }
        }

        #endregion

        #region "  Implementation Methods  "

        public override Event GetNewEvent()
        {
            return Event.CreateNewEvent();
        }

        public override Event GetEvent(DomainKey key)
        {
            StoredProcedureResult<EventResult> eventResults = 
                db.GetEvent((long?) key.Value);
            EventCollection eventCollection = 
                EventResultConverter.ToEventCollection(eventResults);
            if (eventCollection.Count > 0)
            {
                return eventCollection[0];
            }
            else
            {
                return null;
            }
        }

        public override EventCollection GetAllEvents()
        {
            StoredProcedureResult<EventResult> eventResults = db.GetAllEvents();
            EventCollection eventCollection = 
                EventResultConverter.ToEventCollection(eventResults);
            return eventCollection;
        }

        public override EventCollection GetEventsByDate(DateTime targetDate)
        {
            StoredProcedureResult<EventResult> eventResults = 
                db.GetEventsByDate(targetDate);
            EventCollection eventCollection = 
                EventResultConverter.ToEventCollection(eventResults);
            return eventCollection;
        }

        public override DomainKey SaveEvent(Event evt)
        {
            if (evt == null) 
            {
                throw new ArgumentNullException("evt", "Event must be defined");
            }

            long? speakerId = null;            
            if (evt.Speaker != null)
            {
                speakerId = (long) evt.Speaker.ID.Value;
            }

            long? sponsorId = null;
            if (evt.Sponsor != null)
            {
                sponsorId = (long) evt.Sponsor.ID.Value;
            }

            long? locationId = null;
            if (evt.Location != null)
            {
                locationId = (long) evt.Location.ID.Value;
            }

            long? oldEventId = (long) evt.ID.Value;
            long? newEventId = null;

            db.SaveEvent(evt.Title, evt.Description, evt.MeetingDate, 
                speakerId, sponsorId, locationId, oldEventId, ref newEventId);
            evt.ID.Value = newEventId;

            return evt.ID;
        }

        public override void DeleteEvent(Event evt)
        {
            if (evt == null) 
            {
                throw new ArgumentNullException("evt", "Event must be defined");
            }
            db.DeleteEvent((long)evt.ID.Value);
        }
        
        public override bool IsUsingLocation(Location location)
        {
            if (location == null)
            {
                throw new ArgumentNullException("location");
            }

            StoredProcedureResult<CountResult> countResults = 
                db.IsEventUsingLocation((long)location.ID.Value);
            foreach (CountResult countResult in countResults)
            {
                return countResult.Count > 0;
            }
            return false;
        }

        #endregion

        private void GetEventsAtResearchPark()
        {
            EventCollection results = new EventCollection();
            EventCollection eventCollection = GetAllEvents();
            var queryResults = from e in eventCollection
                          where e.Location.Title.Equals("Research Park")
                          select e;
            foreach (Event evt in queryResults)
            {
                results.Add(evt);
            }
        }

    }
}
