using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Events;

public partial class Controls_EventListingControl : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //EventDataObject edo = new EventDataObject();
        //EventCollection events = edo.GetEventsByDate(DateTime.Now.AddDays(90));
        //rptEvents.DataSource = events;
        //rptEvents.DataBind();
    }

    protected void ObjectDataSource1_Selecting(object sender, ObjectDataSourceSelectingEventArgs e)
    {
        e.InputParameters["targetDate"] = DateTime.Now.AddDays(90);
    }

    protected void rptEvents_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.DataItem != null)
        {
            Event evt = e.Item.DataItem as Event;
            if (evt != null)
            {
                Literal ltMeetingDate = e.Item.FindControl("ltMeetingDate") as Literal;
                if (ltMeetingDate != null)
                {
                    ltMeetingDate.Text = evt.MeetingDate.ToShortDateString();
                }
            }
        }
    }
}
