using System;

/// <summary>
/// Summary description for DotnetUserGroupWebsiteException
/// </summary>
public class DugWebsiteException : Exception
{
    public DugWebsiteException(string message, Exception innerException)
        : base(message, innerException)
    {
    }
}
