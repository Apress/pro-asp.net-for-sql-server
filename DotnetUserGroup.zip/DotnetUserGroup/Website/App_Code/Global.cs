using System;
using System.Web;
using System.Web.Profile;
using System.Web.Security;

namespace DotnetUserGroup.Website
{
    /// <summary>
    /// Summary description for Global
    /// </summary>
    public class Global : HttpApplication
    {
        public Global()
        {
            // triggers the logger configuration
            //Utility.GetLogger(typeof(Global)).Info("Web Application Initialized");
        }

        public void Application_Start(object sender, EventArgs e)
        {
            if (Roles.Enabled)
            {
                String[] requiredRoles = { "Admin", "Users", "Editors" };
                foreach (String role in requiredRoles)
                {
                    if (!Roles.RoleExists(role))
                    {
                        Roles.CreateRole(role);
                    }
                }
                string[] users = Roles.GetUsersInRole("Admin");
                if (users.Length == 0)
                {
                    // create admin user
                    MembershipCreateStatus status;
                    Membership.CreateUser("admin", "abc123", "admin@offwhite.net",
                                          "Favorite color?", "offwhite", true, out status);
                    if (!MembershipCreateStatus.Success.Equals(status))
                    {
                        Roles.AddUserToRole("admin", "Admin");
                    }
                    else
                    {
                        //Logger.Warn(("Unable to create admin user"));
                    }
                }
            }
        }

        public void Application_Error(object sender, EventArgs e)
        {
            if (!HttpContext.Current.Request.Url.ToString().Contains(SiteConfiguration.ErrorUrl))
            {
                Exception lastError = Server.GetLastError();
                //Utility.GetLogger(typeof(Global)).Error(lastError.Message, lastError);
                if (HttpContext.Current.Session != null)
                {
                    HttpContext.Current.Session.Add("LastError", lastError);
                }

                HttpContext.Current.Response.Redirect(SiteConfiguration.ErrorUrl);
            }
        }

        public void Profile_OnMigrateAnonymous(object sender, ProfileMigrateEventArgs e)
        {
            //Guid authId = (Guid)Membership.GetUser().ProviderUserKey;
            //Guid anonID = new Guid(e.AnonymousID);
            //Utility.GetLogger(GetType()).Info("AnonymousID = " + anonID);
            //Utility.GetLogger(GetType()).Info("AuthID = " + authId);
            
            //TODO migrate anon to auth
            
            // remove the anonymous user, profile and cookie
            //Membership.DeleteUser(e.AnonymousID, true);
            //ProfileManager.DeleteProfile(e.AnonymousID);
            AnonymousIdentificationModule.ClearAnonymousIdentifier();
        }
        
        //private ILogger _logger = null;
        //public ILogger Logger
        //{
        //    get
        //    {
        //        if (_logger == null)
        //        {
        //            _logger = Utility.GetLogger(typeof(Global));
        //        }
        //        return _logger;
        //    }
        //}
    }
}