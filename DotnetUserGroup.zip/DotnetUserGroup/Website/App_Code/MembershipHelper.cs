using System;
using System.ComponentModel;
using System.Web;
using System.Web.Caching;
using System.Web.Security;

/// <summary>
/// Summary description for MembershipHelper
/// </summary>
[DataObject()]
public class MembershipHelper
{

    [DataObjectMethod(DataObjectMethodType.Select, false)]
    public MembershipUserCollection GetAllUsers(string filter)
    {
        Cache cache = HttpRuntime.Cache;
        string cacheKey = "AllUsers-" + filter;
        if (cache[cacheKey] != null)
        {
            return cache[cacheKey] as MembershipUserCollection;
        }
        
        MembershipUserCollection users = null;
        if (String.IsNullOrEmpty(filter))
        {
            users = Membership.GetAllUsers();
        }
        else
        {
            users = new MembershipUserCollection();
            foreach (MembershipUser user in Membership.GetAllUsers())
            {
                if (user.UserName.Contains(filter) ||
                    user.Email.Contains(filter))
                {
                    users.Add(user);
                }
            }
        }

        // hold for just 3 seconds
        cache.Insert(cacheKey, users, null, DateTime.Now.AddSeconds(3), 
            Cache.NoSlidingExpiration, CacheItemPriority.Normal, null);
        return users;
    }

    public int GetUsersCount()
    {
        MembershipUserCollection users = GetAllUsers(null);
        return users.Count;
    }

    public int GetUsersCount(string filter)
    {
        MembershipUserCollection users = GetAllUsers(filter);
        return users.Count;
    }

    [DataObjectMethod(DataObjectMethodType.Select, false)]
    public MembershipUserCollection GetAllUsers(string filter, int pageIndex, int pageSize, out int totalRecords)
    {
        MembershipUserCollection users = null;
        if (String.IsNullOrEmpty(filter))
        {
            users = Membership.GetAllUsers(pageIndex, pageSize, out totalRecords);
        }
        else
        {
            users = GetAllUsers(filter);
            totalRecords = users.Count;
        }
         
        return users;
    }

    [DataObjectMethod(DataObjectMethodType.Select, false)]
    public MembershipUserCollection GetAllUsers(string filter, int maximumRows, int startRowIndex)
    {
        MembershipUserCollection users = GetAllUsers(filter);
        if (users.Count > maximumRows)
        {
            int pageCount = users.Count/maximumRows;

        }
        return users;
    }

}
