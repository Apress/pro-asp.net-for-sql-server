using System;
using System.Configuration;

namespace DotnetUserGroup.Website
{
    /// <summary>
    /// Summary description for SiteConfiguration
    /// </summary>
    public class SiteConfiguration
    {

        public static string RootUrl
        {
            get
            {
                return Utility.GetSiteUrl("~/");
            }
        }

        public static string HomeUrl
        {
            get
            {
                if (Utility.IsUserAuthenticated)
                {
                    return Utility.GetSiteUrl("~/Home.aspx");
                }
                else
                {
                    return Utility.GetSiteUrl("~/");
                }
            }
        }

        public static string ErrorUrl
        {
            get
            {
                return Utility.GetSiteUrl("~/Error.aspx");
            }
        }

        public static string LoginUrl
        {
            get
            {
                return Utility.GetSiteUrl("~/Login.aspx");
            }
        }

        public static string GetSetting(string key)
        {
            try
            {
                return ConfigurationManager.AppSettings[key];
            }
            catch
            {
                throw new Exception("No " + key + " setting in the web.config.");
            }
        }

    }
}