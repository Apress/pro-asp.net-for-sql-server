SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dug_Locations]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dug_Locations](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Address1] [nvarchar](50) NOT NULL,
	[Address2] [nvarchar](50) NULL,
	[City] [nvarchar](35) NOT NULL,
	[State] [nvarchar](2) NOT NULL,
	[Zip] [nvarchar](5) NOT NULL,
	[Created] [datetime] NOT NULL,
	[Modified] [datetime] NOT NULL,
 CONSTRAINT [PK_dug_Locations] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dug_Sponsors]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dug_Sponsors](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[LocationID] [bigint] NULL,
	[Name] [nvarchar](50) NOT NULL,
	[Description] [text] NULL,
	[WebsiteUrl] [nvarchar](80) NULL,
	[LogoUrl] [nvarchar](80) NULL,
	[LogoWidth] [int] NULL,
	[LogoHeight] [int] NULL,
	[Created] [datetime] NOT NULL,
	[Modified] [datetime] NOT NULL,
 CONSTRAINT [PK_dug_Sponsors] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dug_JobContact]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dug_JobContact](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[LocationID] [bigint] NULL,
	[Name] [nvarchar](50) NOT NULL,
	[Phone] [nvarchar](50) NOT NULL,
	[Email] [nvarchar](150) NOT NULL,
	[WebsiteUrl] [nvarchar](80) NULL,
	[Created] [datetime] NOT NULL,
	[Modified] [datetime] NOT NULL,
 CONSTRAINT [PK_dug_JobContact] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dug_Jobs]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dug_Jobs](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[JobContactID] [bigint] NOT NULL,
	[JobTitle] [nvarchar](50) NOT NULL,
	[Description] [text] NULL,
	[Skills] [nvarchar](100) NOT NULL,
	[MinExp] [int] NOT NULL,
	[MaxExp] [int] NOT NULL,
	[CompanyName] [nvarchar](50) NOT NULL,
	[WebsiteUrl] [nvarchar](80) NULL,
	[EffectiveStartDate] [datetime] NOT NULL,
	[EffectiveEndDate] [datetime] NOT NULL,
	[Created] [datetime] NOT NULL,
	[Modified] [datetime] NOT NULL,
 CONSTRAINT [PK_dug_Jobs] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dug_GetAllLocations]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE Procedure [dbo].[dug_GetAllLocations]
AS

SELECT 
	ID, Address1, Address2, City, State, Zip, Created, Modified
FROM dug_Locations
' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dug_SaveLocation]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE Procedure [dbo].[dug_SaveLocation]
(
	@Address1 nvarchar(50),
	@Address2 nvarchar(50),
	@City nvarchar(35),
	@State nvarchar(2),
	@Zip nvarchar(5),
	@OldLocationID bigint,
	@LocationID bigint OUTPUT
)
AS

IF (@OldLocationID < 0)
	BEGIN
		INSERT INTO dug_Locations
		(Address1, Address2, City, State, Zip, Created, Modified)
		VALUES (
			@Address1,
			@Address2,
			@City,
			@State,
			@Zip,
			GETDATE(),
			GETDATE()
		)
		
		SELECT @LocationID = @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE dug_Locations
		SET
			Address1 = @Address1,
			Address2 = @Address2,
			City = @City,
			State = @State,
			Zip = @Zip,
			Modified = GETDATE()
		WHERE 
			ID = @OldLocationID

		SET @LocationID = @OldLocationID
	END

' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dug_SaveSponsor]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE Procedure [dbo].[dug_SaveSponsor]
(
	@LocationID bigint,
	@Name nvarchar(50),
	@Description text,
	@WebsiteUrl nvarchar(80),
	@LogoUrl nvarchar(80),
	@LogoWidth int,
	@LogoHeight int,
	@OldSponsorID bigint,
	@SponsorID bigint OUTPUT
)
AS

IF (@OldSponsorID < 0)
	BEGIN
		INSERT INTO dug_Sponsors
		(LocationID, [Name], Description, WebsiteUrl, LogoUrl, LogoWidth, LogoHeight, Created, Modified)
		VALUES (
			@LocationID,
			@Name,
			@Description,
			@WebsiteUrl,
			@LogoUrl,
			@LogoWidth,
			@LogoHeight,
			GETDATE(),
			GETDATE()
		)
		
		SELECT @SponsorID = @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE dug_Sponsors
		SET
			LocationID = @LocationID,
			[Name] = @Name,
			Description = @Description,
			WebsiteUrl = @WebsiteUrl,
			LogoUrl = @LogoUrl,
			LogoWidth = @LogoWidth,
			LogoHeight = @LogoHeight,
			Modified = GETDATE()
		WHERE 
			ID = @OldSponsorID

		SET @SponsorID = @OldSponsorID
	END

' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dug_GetAllSponsors]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE Procedure [dbo].[dug_GetAllSponsors]
AS

SELECT 
	ID, [Name], Description, WebsiteUrl, LogoUrl, LogoWidth, LogoHeight, Created, Modified
FROM dug_Sponsors
' 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_dug_Jobs_dug_JobContact]') AND parent_object_id = OBJECT_ID(N'[dbo].[dug_Jobs]'))
ALTER TABLE [dbo].[dug_Jobs]  WITH CHECK ADD  CONSTRAINT [FK_dug_Jobs_dug_JobContact] FOREIGN KEY([JobContactID])
REFERENCES [dbo].[dug_JobContact] ([ID])
GO
ALTER TABLE [dbo].[dug_Jobs] CHECK CONSTRAINT [FK_dug_Jobs_dug_JobContact]
