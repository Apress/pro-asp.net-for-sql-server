IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_IsJobContactUsingLocation')
	BEGIN
		DROP  Procedure  dug_IsJobContactUsingLocation
	END

GO

CREATE Procedure dbo.dug_IsJobContactUsingLocation
(
	@LocationID bigint
)
AS

SELECT COUNT(*)
FROM dug_JobContacts
WHERE LocationID = @LocationID

GO

GRANT EXEC ON dug_IsJobContactUsingLocation TO PUBLIC
GO
