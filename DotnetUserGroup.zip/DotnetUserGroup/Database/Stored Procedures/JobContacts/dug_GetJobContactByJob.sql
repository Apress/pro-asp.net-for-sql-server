IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetJobContactByJob')
	BEGIN
		DROP  Procedure  dug_GetJobContactByJob
	END

GO

CREATE Procedure dbo.dug_GetJobContactByJob
(
	@JobID bigint
)
AS

SELECT 
	jc.ID, jc.LocationID, jc.[Name], jc.Phone, jc.Email, jc.WebsiteUrl,
	jc.Created, jc.Modified
FROM dug_JobContacts AS jc
JOIN dug_Jobs AS j ON j.JobContactID = jc.ID
WHERE j.ID = @JobID

GO

GRANT EXEC ON dug_GetJobContactByJob TO PUBLIC
GO
