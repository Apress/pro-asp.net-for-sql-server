IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_SaveJobContact')
	BEGIN
		DROP  Procedure  dug_SaveJobContact
	END

GO

CREATE Procedure dbo.dug_SaveJobContact
(
	@LocationID bigint,	
	@Name [nvarchar](50),
	@Phone [nvarchar](50),
	@Email [nvarchar](150),
	@WebsiteUrl [nvarchar](80),	
	@OldJobContactID bigint,
	@JobContactID bigint OUTPUT
)
AS

IF (@OldJobContactID < 0)
	BEGIN
		INSERT INTO dug_JobContacts
		(
			LocationID, [Name], Phone, Email, 
			WebsiteUrl, Created, Modified
		)
		VALUES (
			@LocationID,
			@Name,
			@Phone,
			@Email,
			@WebsiteUrl,
			GETDATE(),
			GETDATE()
		)
		
		SELECT @JobContactID = @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE dug_JobContacts
		SET
			LocationID = @LocationID,
			[Name] =@Name,
			Phone = @Phone,
			Email = @Email,
			WebsiteUrl = @WebsiteUrl,
			Modified = GETDATE()
		WHERE 
			ID = @OldJobContactID
	
		SET @JobContactID = @OldJobContactID
	END

GO

GRANT EXEC ON dug_SaveJobContact TO PUBLIC
GO
