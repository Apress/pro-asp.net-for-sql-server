IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_DeleteJobContact')
	BEGIN
		DROP  Procedure  dug_DeleteJobContact
	END

GO

CREATE Procedure dbo.dug_DeleteJobContact
(
	@JobContactID bigint
)
AS

DELETE 
FROM dug_JobContacts 
WHERE ID = @JobContactID

GO

GRANT EXEC ON dug_DeleteJobContact TO PUBLIC
GO
