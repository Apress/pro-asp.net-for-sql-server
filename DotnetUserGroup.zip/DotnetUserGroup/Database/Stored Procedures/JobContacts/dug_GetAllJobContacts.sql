IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetAllJobContacts')
	BEGIN
		DROP  Procedure  dug_GetAllJobContacts
	END

GO

CREATE Procedure dbo.dug_GetAllJobContacts
AS

SELECT 
	ID, LocationID, [Name], Phone, Email, WebsiteUrl,
	Created, Modified
FROM dug_JobContacts

GO

GRANT EXEC ON dug_GetAllJobContacts TO PUBLIC
GO
