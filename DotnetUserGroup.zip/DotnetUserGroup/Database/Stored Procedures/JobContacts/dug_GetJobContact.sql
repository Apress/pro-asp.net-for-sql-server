IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetJobContact')
	BEGIN
		DROP  Procedure  dug_GetJobContact
	END

GO

CREATE Procedure dbo.dug_GetJobContact
(
	@JobContactID bigint
)
AS

SELECT 
	ID, LocationID, [Name], Phone, Email, WebsiteUrl,
	Created, Modified
FROM dug_JobContacts
WHERE ID = @JobContactID
GO

GRANT EXEC ON dug_GetJobContact TO PUBLIC
GO
