IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetLocationByEvent')
	BEGIN
		DROP  Procedure  dug_GetLocationByEvent
	END

GO

CREATE Procedure dbo.dug_GetLocationByEvent
(
	@EventID bigint
)
AS

SELECT 
	l.ID, l.Title, l.Address1, l.Address2, l.City, l.State, l.Zip, l.Created, l.Modified
FROM dug_Locations AS l
JOIN dug_Events AS e ON e.LocationID = l.ID
WHERE e.ID = @EventID

GO

GRANT EXEC ON dug_GetLocationByEvent TO PUBLIC
GO
