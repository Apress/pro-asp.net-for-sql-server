IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetLocationByJob')
	BEGIN
		DROP  Procedure  dug_GetLocationByJob
	END

GO

CREATE Procedure dbo.dug_GetLocationByJob
(
	@JobID bigint
)
AS

SELECT 
	l.ID, l.Title, l.Address1, l.Address2, l.City, l.State, l.Zip, l.Created, l.Modified
FROM dug_Locations AS l
JOIN dug_Jobs AS j ON j.LocationID = l.ID
WHERE j.ID = @JobID

GO

GRANT EXEC ON dug_GetLocationByJob TO PUBLIC
GO
