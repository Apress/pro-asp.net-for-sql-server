IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_DeleteLocation')
	BEGIN
		DROP  Procedure  dug_DeleteLocation
	END

GO

CREATE Procedure dbo.dug_DeleteLocation
(
	@LocationID bigint
)
AS

DELETE
FROM dug_Locations
WHERE ID = @LocationID

GO

GRANT EXEC ON dug_DeleteLocation TO PUBLIC
GO
