IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_SaveLocation')
	BEGIN
		DROP  Procedure  dug_SaveLocation
	END

GO

CREATE Procedure dbo.dug_SaveLocation
(
	@Title nvarchar(50),
	@Address1 nvarchar(50),
	@Address2 nvarchar(50),
	@City nvarchar(35),
	@State nvarchar(2),
	@Zip nvarchar(5),
	@OldLocationID bigint,
	@LocationID bigint OUTPUT
)
AS

IF (@OldLocationID < 0)
	BEGIN
		INSERT INTO dug_Locations
		(Title, Address1, Address2, City, State, Zip, Created, Modified)
		VALUES (
			@Title,
			@Address1,
			@Address2,
			@City,
			@State,
			@Zip,
			GETDATE(),
			GETDATE()
		)
		
		SELECT @LocationID = @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE dug_Locations
		SET
			Title = @Title,
			Address1 = @Address1,
			Address2 = @Address2,
			City = @City,
			State = @State,
			Zip = @Zip,
			Modified = GETDATE()
		WHERE 
			ID = @OldLocationID

		SET @LocationID = @OldLocationID
	END

GO

GRANT EXEC ON dug_SaveLocation TO PUBLIC
GO