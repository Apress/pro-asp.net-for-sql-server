IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetLocation')
	BEGIN
		DROP  Procedure  dug_GetLocation
	END

GO

CREATE Procedure dbo.dug_GetLocation
(
	@LocationID bigint
)
AS

SELECT 
	ID, Title, Address1, Address2, City, State, Zip, Created, Modified
FROM dug_Locations
WHERE ID = @LocationID
GO

GRANT EXEC ON dug_GetLocation TO PUBLIC
GO
