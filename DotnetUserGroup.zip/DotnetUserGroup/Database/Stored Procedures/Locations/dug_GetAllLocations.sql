IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetAllLocations')
	BEGIN
		DROP  Procedure  dug_GetAllLocations
	END

GO

CREATE Procedure dbo.dug_GetAllLocations
AS

SELECT 
	ID, Title, Address1, Address2, City, State, Zip, Created, Modified
FROM dug_Locations
GO

GRANT EXEC ON dug_GetAllLocations TO PUBLIC
GO
