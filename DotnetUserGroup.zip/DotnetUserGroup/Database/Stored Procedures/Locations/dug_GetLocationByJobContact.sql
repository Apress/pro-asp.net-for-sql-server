IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetLocationByJobContact')
	BEGIN
		DROP  Procedure  dug_GetLocationByJobContact
	END

GO

CREATE Procedure dbo.dug_GetLocationByJobContact
(
	@JobContactID bigint
)
AS

SELECT 
	l.ID, l.Title, l.Address1, l.Address2, l.City, l.State, l.Zip, l.Created, l.Modified
FROM dug_Locations AS l
JOIN dug_JobContacts AS jc ON jc.LocationID = l.ID
WHERE jc.ID = @JobContactID

GO

GRANT EXEC ON dug_GetLocationByJobContact TO PUBLIC
GO
