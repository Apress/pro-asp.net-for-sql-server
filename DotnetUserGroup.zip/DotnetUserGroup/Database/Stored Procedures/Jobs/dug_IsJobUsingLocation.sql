IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_IsJobUsingLocation')
	BEGIN
		DROP  Procedure  dug_IsJobUsingLocation
	END

GO

CREATE Procedure dbo.dug_IsJobUsingLocation
(
	@LocationID bigint
)
AS

SELECT COUNT(*)
FROM dug_Jobs
WHERE LocationID = @LocationID

GO

GRANT EXEC ON dug_IsJobUsingLocation TO PUBLIC
GO
