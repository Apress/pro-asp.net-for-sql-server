IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetJob')
	BEGIN
		DROP  Procedure  dug_GetJob
	END

GO

CREATE Procedure dbo.dug_GetJob
(
	@JobID bigint
)
AS

SELECT 
	ID, Title, Description, Skills, MinExp, MaxExp,
	CompanyName, WebsiteUrl, EffectiveStartDate, EffectiveEndDate,
	Created, Modified
FROM dug_Jobs
WHERE ID = @JobID

GO

GRANT EXEC ON dug_GetJob TO PUBLIC
GO
