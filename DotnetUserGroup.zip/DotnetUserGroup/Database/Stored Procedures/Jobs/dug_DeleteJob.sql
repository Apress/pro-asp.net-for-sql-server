IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_DeleteJob')
	BEGIN
		DROP  Procedure  dug_DeleteJob
	END

GO

CREATE Procedure dbo.dug_DeleteJob
(
	@JobID bigint
)
AS

DELETE 
FROM dug_Jobs 
WHERE ID = @JobID

GO

GRANT EXEC ON dug_DeleteJob TO PUBLIC
GO
