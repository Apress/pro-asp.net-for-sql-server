IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_SaveJob')
	BEGIN
		DROP  Procedure  dug_SaveJob
	END

GO

CREATE Procedure dbo.dug_SaveJob
	@LocationID bigint,
	@JobContactID bigint,
	@Title nvarchar(50),
	@Description text,
	@Skills nvarchar(100),
	@MinExp int,
	@MaxExp int,
	@CompanyName nvarchar(50),
	@WebsiteUrl nvarchar(80),
	@EffectiveStartDate datetime,
	@EffectiveEndDate datetime,
	@OldJobID bigint,
	@JobID bigint OUTPUT
AS

IF (@OldJobID < 0)
	BEGIN
		INSERT INTO dug_Jobs
		(
			LocationID, JobContactID, Title, Description, 
			Skills, MinExp, MaxExp, CompanyName, WebsiteUrl, 
			EffectiveStartDate, EffectiveEndDate, 
			Created, Modified
		)
		VALUES (
		    @LocationID,
			@JobContactID,
			@Title,
			@Description,
			@Skills,
			@MinExp,
			@MaxExp,
			@CompanyName,
			@WebsiteUrl,
			@EffectiveStartDate,
			@EffectiveEndDate,
			GETDATE(),
			GETDATE()
		)
		
		SELECT @JobID = @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE dug_Jobs
		SET
			LocationID = @LocationID,
			JobContactID = @JobContactID,
			Title = @Title,
			Description = @Description,
			Skills = @Skills,
			MinExp = @MinExp,
			MaxExp = @MaxExp,
			CompanyName = @CompanyName,
			WebsiteUrl = @WebsiteUrl,
			EffectiveStartDate = @EffectiveStartDate,
			EffectiveEndDate = @EffectiveEndDate,
			Modified = GETDATE()
		WHERE 
			ID = @OldJobID
	
		SET @JobID = @OldJobID
	END

GO

GRANT EXEC ON dug_SaveJob TO PUBLIC
GO
