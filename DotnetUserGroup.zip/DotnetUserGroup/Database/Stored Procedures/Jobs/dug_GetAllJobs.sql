IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetAllJobs')
	BEGIN
		DROP  Procedure  dug_GetAllJobs
	END

GO

CREATE Procedure dbo.dug_GetAllJobs
AS

SELECT 
	ID, Title, Description, Skills, MinExp, MaxExp,
	CompanyName, WebsiteUrl, EffectiveStartDate, EffectiveEndDate,
	Created, Modified
FROM dug_Jobs

GO

GRANT EXEC ON dug_GetAllJobs TO PUBLIC
GO
