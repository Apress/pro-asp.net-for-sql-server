IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_DeleteMember')
	BEGIN
		DROP  Procedure  dug_DeleteMember
	END

GO

CREATE Procedure dbo.dug_DeleteMember
(
	@MemberID bigint
)
AS

-- Note: 
-- Members are simply deactivated instead of deleted
-- as the record will stay remain associated with the 
-- ASP.NET membership records as well as registrations.

UPDATE dug_Members
SET IsActive = 0, Modified = GETDATE()
WHERE ID = @MemberID

GO

GRANT EXEC ON dug_DeleteMember TO PUBLIC
GO
