IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_SaveMember')
	BEGIN
		DROP  Procedure  dug_SaveMember
	END

GO

CREATE Procedure dbo.dug_SaveMember
(
	@UserID uniqueidentifier,
	@IsActive bit,
	@OldMemberID bigint,
	@MemberID bigint OUTPUT
)
AS

IF (@OldMemberID < 0)
	BEGIN
		INSERT INTO dug_Members
		(UserID, IsActive, Created, Modified)
		VALUES (
			@UserID,
			@IsActive,
			GETDATE(),
			GETDATE()
		)
		
		SELECT @MemberID = @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE dug_Members
		SET
			UserID = @UserID,
			IsActive = @IsActive,
			Modified = GETDATE()
		WHERE 
			ID = @OldMemberID
		
		SET @MemberID = @OldMemberID
	END

GO

GRANT EXEC ON dug_SaveMember TO PUBLIC
GO
