IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetMember')
	BEGIN
		DROP  Procedure  dug_GetMember
	END

GO

CREATE Procedure dbo.dug_GetMember
(
	@MemberID bigint
)
AS

SELECT ID, UserID, IsActive, Created, Modified
FROM dug_Members
WHERE ID = @MemberID

GO

GRANT EXEC ON dug_GetMember TO PUBLIC
GO
