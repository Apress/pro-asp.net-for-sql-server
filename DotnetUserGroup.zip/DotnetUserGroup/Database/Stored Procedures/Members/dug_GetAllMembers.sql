IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetAllMembers')
	BEGIN
		DROP  Procedure  dug_GetAllMembers
	END

GO

CREATE Procedure dbo.dug_GetAllMembers
AS

SELECT ID, UserID, IsActive, Created, Modified
FROM dug_Members
WHERE IsActive = 1

GO

GRANT EXEC ON dug_GetAllMembers TO PUBLIC
GO
