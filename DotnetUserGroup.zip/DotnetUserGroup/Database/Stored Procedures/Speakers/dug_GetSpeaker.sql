IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetSpeaker')
	BEGIN
		DROP  Procedure  dug_GetSpeaker
	END

GO

CREATE Procedure dbo.dug_GetSpeaker
(
	@SpeakerID bigint
)
AS

SELECT 
	ID, FirstName, MiddleInitial, LastName, Description, WebsiteUrl, Email, Phone, Created, Modified
FROM dug_Speakers
WHERE ID = @SpeakerID

GO

GRANT EXEC ON dug_GetSpeaker TO PUBLIC
GO
