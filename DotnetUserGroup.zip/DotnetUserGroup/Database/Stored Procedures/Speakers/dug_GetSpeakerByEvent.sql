IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetSpeakerByEvent')
	BEGIN
		DROP  Procedure  dug_GetSpeakerByEvent
	END

GO

CREATE Procedure dbo.dug_GetSpeakerByEvent
(
	@EventID bigint
)
AS

SELECT 
	s.ID, s.FirstName, s.MiddleInitial, s.LastName, s.Description, 
	s.WebsiteUrl, s.Email, s.Phone, s.Created, s.Modified
FROM dug_Speakers AS s
JOIN dug_Events AS e ON e.SpeakerID = s.ID
WHERE e.ID = @EventID

GO

GRANT EXEC ON dug_GetSpeakerByEvent TO PUBLIC
GO
