IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetSpeakersByDate')
	BEGIN
		DROP  Procedure  dug_GetSpeakersByDate
	END

GO

CREATE Procedure dbo.dug_GetSpeakersByDate
(
	@TargetDate DATETIME
)

AS

SELECT 
	s.ID, s.FirstName, s.MiddleInitial, s.LastName, s.Description, 
	s.WebsiteUrl, s.Email, s.Phone, s.Created, s.Modified
FROM dug_Speakers AS s
JOIN dug_Events AS e ON e.SpeakerID = s.ID
WHERE
	e.MeetingDate BETWEEN GETDATE() AND @TargetDate

GO

GRANT EXEC ON dug_GetSpeakersByDate TO PUBLIC
GO
