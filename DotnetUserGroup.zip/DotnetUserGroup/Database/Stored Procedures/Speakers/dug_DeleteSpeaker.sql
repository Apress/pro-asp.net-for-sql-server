IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_DeleteSpeaker')
	BEGIN
		DROP  Procedure  dug_DeleteSpeaker
	END

GO

CREATE Procedure dbo.dug_DeleteSpeaker
(
	@SpeakerID bigint
)
AS

DELETE 
FROM dug_Speakers 
WHERE ID = @SpeakerID

GO

GRANT EXEC ON dug_DeleteSpeaker TO PUBLIC
GO
