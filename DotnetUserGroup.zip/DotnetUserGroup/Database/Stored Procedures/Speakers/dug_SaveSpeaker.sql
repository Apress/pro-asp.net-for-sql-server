IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_SaveSpeaker')
	BEGIN
		DROP  Procedure  dug_SaveSpeaker
	END

GO

CREATE Procedure dbo.dug_SaveSpeaker
(
	@FirstName nvarchar(50),
	@MiddleInitial nvarchar(1),
	@LastName nvarchar(50),
	@Description text,
	@WebsiteUrl nvarchar(80),
	@Email nvarchar(80),
	@Phone nvarchar(15),
	@OldSpeakerID bigint,
	@SpeakerID bigint OUTPUT
)
AS

IF (@OldSpeakerID < 0)
	BEGIN
		INSERT INTO dug_Speakers		
		(FirstName, MiddleInitial, LastName, Description, WebsiteUrl, Email, Phone, Created, Modified)
		VALUES (
			@FirstName,
			@MiddleInitial,
			@LastName,
			@Description,
			@WebsiteUrl,
			@Email,
			@Phone,
			GETDATE(),
			GETDATE()
		)
		
		SELECT @SpeakerID = @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE dug_Speakers
		SET
			FirstName = @FirstName,
			MiddleInitial = @MiddleInitial,
			LastName = @LastName,
			Description = @Description,
			WebsiteUrl = @WebsiteUrl,
			Email = @Email,
			Phone = @Phone,
			Modified = GETDATE()
		WHERE 
			ID = @OldSpeakerID

		SET @SpeakerID = @OldSpeakerID
	END

GO

GRANT EXEC ON dug_SaveSpeaker TO PUBLIC
GO
