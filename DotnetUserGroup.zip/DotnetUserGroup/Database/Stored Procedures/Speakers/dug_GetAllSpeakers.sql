IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetAllSpeakers')
	BEGIN
		DROP  Procedure  dug_GetAllSpeakers
	END

GO

CREATE Procedure dbo.dug_GetAllSpeakers
AS

SELECT 
	ID, FirstName, MiddleInitial, LastName, Description, WebsiteUrl, Email, Phone, Created, Modified
FROM dug_Speakers

GO

GRANT EXEC ON dug_GetAllSpeakers TO PUBLIC
GO
