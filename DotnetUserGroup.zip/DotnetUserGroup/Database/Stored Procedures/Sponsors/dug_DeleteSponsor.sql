IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_DeleteSponsor')
	BEGIN
		DROP  Procedure  dug_DeleteSponsor
	END

GO

CREATE Procedure dbo.dug_DeleteSponsor
(
	@SponsorID bigint
)
AS

DELETE 
FROM dug_Sponsors 
WHERE ID = @SponsorID

GO

GRANT EXEC ON dug_DeleteSponsor TO PUBLIC
GO
