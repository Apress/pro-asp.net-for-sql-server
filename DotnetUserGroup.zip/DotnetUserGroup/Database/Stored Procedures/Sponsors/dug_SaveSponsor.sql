IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_SaveSponsor')
	BEGIN
		DROP  Procedure  dug_SaveSponsor
	END

GO

CREATE Procedure dbo.dug_SaveSponsor
(
	@LocationID bigint,
	@Name nvarchar(50),
	@Description text,
	@WebsiteUrl nvarchar(80),
	@LogoUrl nvarchar(80),
	@LogoWidth int,
	@LogoHeight int,
	@OldSponsorID bigint,
	@SponsorID bigint OUTPUT
)
AS

IF (@OldSponsorID < 0)
	BEGIN
		INSERT INTO dug_Sponsors
		(LocationID, [Name], Description, WebsiteUrl, LogoUrl, LogoWidth, LogoHeight, Created, Modified)
		VALUES (
			@LocationID,
			@Name,
			@Description,
			@WebsiteUrl,
			@LogoUrl,
			@LogoWidth,
			@LogoHeight,
			GETDATE(),
			GETDATE()
		)
		
		SELECT @SponsorID = @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE dug_Sponsors
		SET
			LocationID = @LocationID,
			[Name] = @Name,
			Description = @Description,
			WebsiteUrl = @WebsiteUrl,
			LogoUrl = @LogoUrl,
			LogoWidth = @LogoWidth,
			LogoHeight = @LogoHeight,
			Modified = GETDATE()
		WHERE 
			ID = @OldSponsorID

		SET @SponsorID = @OldSponsorID
	END

GO

GRANT EXEC ON dug_SaveSponsor TO PUBLIC
GO
