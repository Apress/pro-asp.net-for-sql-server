IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetSponsorByEvent')
	BEGIN
		DROP  Procedure  dug_GetSponsorByEvent
	END

GO

CREATE Procedure dbo.dug_GetSponsorByEvent
(
	@EventID bigint
)
AS

SELECT 
	s.ID, s.[Name], s.Description, s.WebsiteUrl, s.LogoUrl, 
	s.LogoWidth, s.LogoHeight, s.Created, s.Modified
FROM dug_Sponsors AS s
JOIN dug_Events AS e ON e.SponsorID = s.ID
WHERE e.ID = @EventID

GO

GRANT EXEC ON dug_GetSponsorByEvent TO PUBLIC
GO
