IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_IsSponsorUsingLocation')
	BEGIN
		DROP  Procedure  dug_IsSponsorUsingLocation
	END

GO

CREATE Procedure dbo.dug_IsSponsorUsingLocation
(
	@LocationID bigint
)
AS

SELECT COUNT(*)
FROM dug_Sponsors
WHERE LocationID = @LocationID

GO

GRANT EXEC ON dug_IsSponsorUsingLocation TO PUBLIC
GO
