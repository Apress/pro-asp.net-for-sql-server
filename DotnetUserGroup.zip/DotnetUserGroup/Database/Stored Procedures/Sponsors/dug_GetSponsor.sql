IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetSponsor')
	BEGIN
		DROP  Procedure  dug_GetSponsor
	END

GO

CREATE Procedure dbo.dug_GetSponsor
(
	@SponsorID bigint
)
AS

SELECT 
	ID, [Name], Description, WebsiteUrl, LogoUrl, LogoWidth, LogoHeight, Created, Modified
FROM dug_Sponsors
WHERE ID = @SponsorID

GO

GRANT EXEC ON dug_GetSponsor TO PUBLIC
GO
