IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetAllSponsors')
	BEGIN
		DROP  Procedure  dug_GetAllSponsors
	END

GO

CREATE Procedure dbo.dug_GetAllSponsors
AS

SELECT 
	ID, [Name], Description, WebsiteUrl, LogoUrl, LogoWidth, LogoHeight, Created, Modified
FROM dug_Sponsors

GO

GRANT EXEC ON dug_GetAllSponsors TO PUBLIC
GO
