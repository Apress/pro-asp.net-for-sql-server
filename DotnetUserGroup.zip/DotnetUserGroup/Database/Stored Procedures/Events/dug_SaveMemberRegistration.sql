IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_SaveMemberRegistration')
	BEGIN
		DROP  Procedure  dug_SaveMemberRegistration
	END

GO

CREATE Procedure dbo.dug_SaveMemberRegistration
(
	@MemberID bigint,
	@EventID bigint,
	@Status char(1)
)
AS

IF NOT EXISTS (
		SELECT * FROM dug_MemberRegistrations
		WHERE MemberID = @MemberID AND EventID = @EventID
	)
	BEGIN
		INSERT INTO dug_MemberRegistrations
		(MemberID, EventID, Status, Created, Modified)
		VALUES
		(@MemberID, @EventID, @Status, GETDATE(), GETDATE())
	END
ELSE
	BEGIN
		UPDATE dug_MemberRegistrations
		SET Status = @Status, Modified = GETDATE()
		WHERE MemberID = @MemberID AND EventID = @EventID
	END
	
GO

GRANT EXEC ON dug_SaveMemberRegistration TO PUBLIC
GO
