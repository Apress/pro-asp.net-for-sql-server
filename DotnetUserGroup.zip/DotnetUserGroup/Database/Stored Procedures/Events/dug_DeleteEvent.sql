IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' 
  AND name = 'dug_DeleteEvent')
	BEGIN
		DROP  Procedure  dug_DeleteEvent
	END
GO

CREATE Procedure dbo.dug_DeleteEvent
(
	@EventID bigint
)
AS

DELETE FROM dug_Events
WHERE ID = @EventID

GO

GRANT EXEC ON dug_DeleteEvent TO PUBLIC
GO
