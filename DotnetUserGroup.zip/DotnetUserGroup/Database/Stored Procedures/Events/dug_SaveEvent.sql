IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_SaveEvent')
	BEGIN
		DROP  Procedure  dug_SaveEvent
	END
GO

CREATE Procedure dbo.dug_SaveEvent
(
	@Title nvarchar(50),
	@Description text,
	@MeetingDate datetime,
	@SpeakerID bigint,
	@SponsorID bigint,
	@LocationID bigint,
	@OldEventID bigint,
	@EventID bigint OUTPUT
)
AS

IF (@OldEventID < 0)
	BEGIN
		INSERT INTO dug_Events
		(Title, Description, MeetingDate, SpeakerID, 
		 SponsorID, LocationID, Created, Modified)
		VALUES (
			@Title,
			@Description,
			@MeetingDate,
			@SpeakerID,
			@SponsorID,
			@LocationID,
			GETDATE(),
			GETDATE()
		)
		
		SELECT @EventID = @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE dug_Events
		SET
			Title = @Title,
			Description = @Description,
			MeetingDate = @MeetingDate,
			SpeakerID = @SpeakerID,
			SponsorID = @SponsorID,
			LocationID = @LocationID,
			Modified = GETDATE()
		WHERE 
			ID = @OldEventID

		SET @EventID = @OldEventID
	END

GO

GRANT EXEC ON dug_SaveEvent TO PUBLIC
GO
