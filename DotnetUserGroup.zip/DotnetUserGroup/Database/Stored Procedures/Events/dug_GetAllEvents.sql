IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetAllEvents')
	BEGIN
		DROP  Procedure  dug_GetAllEvents
	END

GO

CREATE Procedure dbo.dug_GetAllEvents
AS

SELECT 
	ID, Title, Description, MeetingDate, Created, Modified
FROM dug_Events

GO

GRANT EXEC ON dug_GetAllEvents TO PUBLIC
GO
