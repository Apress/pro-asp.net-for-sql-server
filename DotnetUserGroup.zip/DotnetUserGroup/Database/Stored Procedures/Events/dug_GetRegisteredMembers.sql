IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetRegisteredMembers')
	BEGIN
		DROP  Procedure  dug_GetRegisteredMembers
	END

GO

CREATE Procedure dbo.dug_GetRegisteredMembers
(
	@EventID bigint
)
AS

SELECT m.ID, m.UserID, m.IsActive, m.Created, m.Modified
FROM dug_Members AS m
JOIN dug_MemberRegistrations AS mr on mr.MemberID = m.ID
WHERE m.IsActive = 1 AND mr.EventID= @EventID AND mr.Status = 'Y'

GO

GRANT EXEC ON dug_GetRegisteredMembers TO PUBLIC
GO
