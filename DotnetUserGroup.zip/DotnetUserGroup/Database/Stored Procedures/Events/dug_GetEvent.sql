IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetEvent')
	BEGIN
		DROP  Procedure  dug_GetEvent
	END
GO

CREATE Procedure dbo.dug_GetEvent
(
	@EventID bigint
)
AS

SELECT 
	ID, Title, Description, MeetingDate, Created, Modified
FROM dug_Events
WHERE ID = @EventID
GO

GRANT EXEC ON dug_GetEvent TO PUBLIC
GO
