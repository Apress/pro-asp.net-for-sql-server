IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_IsEventUsingLocation')
	BEGIN
		DROP  Procedure  dug_IsEventUsingLocation
	END

GO

CREATE Procedure dbo.dug_IsEventUsingLocation
(
	@LocationID bigint
)
AS

SELECT COUNT(*) as CountResult
FROM dug_Events
WHERE LocationID = @LocationID

GO

GRANT EXEC ON dug_IsEventUsingLocation TO PUBLIC
GO
