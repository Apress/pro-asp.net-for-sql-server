IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'dug_GetEventsByDate')
	BEGIN
		DROP  Procedure  dug_GetEventsByDate
	END
GO

CREATE Procedure dbo.dug_GetEventsByDate
(
	@TargetDate DATETIME
)

AS

SELECT 
	ID, Title, Description, MeetingDate, Created, Modified
FROM dug_Events
WHERE
	MeetingDate BETWEEN GETDATE() AND @TargetDate

GO

GRANT EXEC ON dug_GetEventsByDate TO PUBLIC
GO
