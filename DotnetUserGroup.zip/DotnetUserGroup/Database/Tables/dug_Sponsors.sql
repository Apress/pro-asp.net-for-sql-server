IF EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'dug_Sponsors')
	BEGIN
		DROP  Table dug_Sponsors
	END
GO

CREATE TABLE [dbo].[dug_Sponsors](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[LocationID] [bigint] NULL,
	[Name] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WebsiteUrl] [nvarchar](80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[LogoUrl] [nvarchar](80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[LogoWidth] [int] NULL,
	[LogoHeight] [int] NULL,
	[Created] datetime NOT NULL,
	[Modified] datetime NOT NULL
 CONSTRAINT [PK_dug_Sponsors] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
