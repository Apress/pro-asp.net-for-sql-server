IF EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'dug_Members')
	BEGIN
		DROP  Table dug_Members
	END
GO

CREATE TABLE [dbo].[dug_Members](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[UserID] [uniqueidentifier] NOT NULL,
	[IsActive] [bit] NOT NULL CONSTRAINT [DF_dug_Members_IsActive]  DEFAULT ((1)),
	[Created] [datetime] NOT NULL,
	[Modified] [datetime] NOT NULL,
 CONSTRAINT [PK_dug_Members] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

GO
