IF EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'dug_MemberRegistrations')
	BEGIN
		DROP  Table dug_MemberRegistrations
	END
GO

CREATE TABLE [dbo].[dug_MemberRegistrations](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[MemberID] [bigint] NOT NULL,
	[EventID] [bigint] NOT NULL,
	[Status] [char](1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_dug_MemberRegistrations_Status]  DEFAULT ('Y'),
	[Created] [datetime] NOT NULL,
	[Modified] [datetime] NOT NULL,
 CONSTRAINT [PK_dug_MemberRegistrations] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Yes, No or Maybe (Y,N,M)' , 
	@level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dug_MemberRegistrations', 
	@level2type=N'COLUMN',@level2name=N'Status'
GO
