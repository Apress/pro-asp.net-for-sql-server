IF EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'dug_Events')
	BEGIN
		DROP  Table dug_Events
	END
GO

CREATE TABLE dbo.dug_Events
(
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[MeetingDate] [datetime] NOT NULL,
	[SpeakerID] [bigint] NULL,
	[SponsorID] [bigint] NULL,
	[LocationID] [bigint] NOT NULL,
	[Created] datetime NOT NULL,
	[Modified] datetime NOT NULL
 CONSTRAINT [PK_dug_Events] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
