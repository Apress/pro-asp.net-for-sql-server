
DECLARE @LocationID int
EXEC dug_SaveLocation '100 Main St', '', 'Milwaukee', 'WI', '53212', -1, @LocationID OUTPUT
PRINT @LocationID

DECLARE @LocationID int
EXEC dug_SaveLocation '100 Main St', '', 'Milwaukee', 'WI', '53212', -1, @LocationID OUTPUT
PRINT @LocationID

EXEC dug_GetAllLocations

DECLARE @LocationID int
EXEC dug_SaveLocation '101 Main St', '', 'Milwaukee', 'WI', '53212', 1, @LocationID OUTPUT
PRINT @LocationID

EXEC dug_GetAllLocations
