IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_dug_Jobs_dug_JobContacts')
	BEGIN
		ALTER TABLE dbo.dug_Jobs
			DROP CONSTRAINT FK_dug_Jobs_dug_JobContacts
	END
GO

ALTER TABLE dbo.dug_Jobs ADD CONSTRAINT
	FK_dug_Jobs_dug_JobContacts FOREIGN KEY
	(
	JobContactID
	) REFERENCES dbo.dug_JobContacts
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
