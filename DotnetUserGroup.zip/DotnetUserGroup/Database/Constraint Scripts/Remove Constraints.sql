IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_dug_Jobs_dug_JobContacts')
	BEGIN
		ALTER TABLE dbo.dug_Jobs
			DROP CONSTRAINT FK_dug_Jobs_dug_JobContacts
	END
GO
 