using System;
using System.Configuration.Provider;
using System.Web.Configuration;

namespace DotnetUserGroup.DataAccess.JobContacts
{
    public class JobContactManager
    {
        private static JobContactProvider _defaultProvider = null;
        private static JobContactProviderCollection _providers = null;
        private static object _lock = new object();

        private JobContactManager() {}

        public static JobContactProvider DefaultProvider
        {
            get 
            { 
                LoadProviders();
                return _defaultProvider;
            }
        }

        public static JobContactProvider GetProvider(string name)
        {
            LoadProviders();
            if (String.IsNullOrEmpty(name))
            {
                return DefaultProvider;
            }
            else
            {
                return _providers[name];
            }
        }

        private static void LoadProviders()
        {
            // Avoid claiming lock if providers are already loaded
            if (_defaultProvider == null)
            {
                lock (_lock)
                {
                    // Do this again to make sure _defaultProvider is still null
                    if (_defaultProvider == null)
                    {
                        JobContactSection section = (JobContactSection)
                            WebConfigurationManager.GetSection
                            ("dotnetUserGroup/jobContacts");

                        _providers = new JobContactProviderCollection();

                        ProvidersHelper.InstantiateProviders(
                            section.Providers, _providers, 
                            typeof(JobContactProvider));

                        _defaultProvider = _providers[section.DefaultProvider];

                        if (_defaultProvider == null)
                            throw new ProviderException
                                ("Unable to load default JobContactProvider");
                    }
                }
            }
        }
    }
}
