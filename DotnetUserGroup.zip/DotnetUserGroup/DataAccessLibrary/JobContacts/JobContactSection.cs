using System.Configuration;
using DotnetUserGroup.DataAccess.Common;

namespace DotnetUserGroup.DataAccess.JobContacts
{
    public class JobContactSection : ProviderConfigurationSection
    {
        [ConfigurationProperty("providers")]
        public override ProviderSettingsCollection Providers
        {
            get { return (ProviderSettingsCollection)base["providers"]; }
        }

        [StringValidator(MinLength = 1)]
        [ConfigurationProperty("defaultProvider",
            DefaultValue = "SqlJobContactProvider")]
        public override string DefaultProvider
        {
            get { return (string)base["defaultProvider"]; }
            set { base["defaultProvider"] = value; }
        }

        [StringValidator(MinLength = 1)]
        [ConfigurationProperty("locationProvider",
            DefaultValue = "SqlLocationProvider", 
            IsRequired = false)]
        public string LocationProvider
        {
            get { return (string)base["locationProvider"]; }
            set { base["locationProvider"] = value; }
        }
    }
}
