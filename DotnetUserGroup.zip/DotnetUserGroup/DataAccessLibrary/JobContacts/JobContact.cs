using System.Data;
using System.Runtime.Serialization;
using System.ServiceModel;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Locations;

namespace DotnetUserGroup.DataAccess.JobContacts
{
    [DataContract]
    public class JobContact : DomainObject<JobContact>
    {
        protected internal JobContact() { }

        public JobContact(DataRow row)
        {
            Load(row);
        }

        public JobContact(IDataReader dr)
        {
            Load(dr);
        }
        
        private Location _location;
        
        [DataMember(Name = "Location",Order = 1)]
        public Location Location
        {
            get {
                if (_location == null) 
                {
                    // lazy load the location
                    _location = LocationManager.DefaultProvider.GetLocation(this);
                }
                return _location;
            }
            set { _location = value; }
        }

        private string _name;
        
        [DataMember(Name = "Name",Order = 1)]
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private string _phone;
        
        [DataMember(Name = "Phone",Order = 1)]
        public string Phone
        {
            get { return _phone; }
            set { _phone = value; }
        }

        private string _email;
        
        [DataMember(Name = "Email",Order = 1)]
        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }

        private string _websiteUrl;
        
        [DataMember(Name = "WebsiteUrl",Order = 1)]
        public string WebsiteUrl
        {
            get { return _websiteUrl; }
            set { _websiteUrl = value; }
        }

    }
}
