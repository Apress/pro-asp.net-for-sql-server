using System;
using System.Collections.Specialized;
using System.Configuration.Provider;
using System.Data;
using System.Data.Common;
using System.Web.Configuration;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Jobs;
using DotnetUserGroup.DataAccess.Locations;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace DotnetUserGroup.DataAccess.JobContacts
{
    public class SqlJobContactProvider : JobContactProvider
    {

        #region "  Variables  "

        string connStringName = String.Empty;
        private Database db;

        #endregion

        #region "  Provider Methods  "

        /// <summary>
        /// SQL Implementation
        /// </summary>
        public override void Initialize(string name,
            NameValueCollection config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            if (String.IsNullOrEmpty(name))
            {
                name = "SqlJobProvider";
            }

            if (String.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "SQL Job Contacts Provider");
            }

            base.Initialize(name, config);

            if (config["connectionStringName"] == null)
            {
                throw new ProviderException(
                    "Required attribute missing: connectionStringName");
            }

            connStringName = config["connectionStringName"].ToString();
            config.Remove("connectionStringName");

            if (WebConfigurationManager.ConnectionStrings[connStringName] == null)
            {
                throw new ProviderException("Missing connection string");
            }

            db = DatabaseFactory.CreateDatabase(connStringName);

            if (config.Count > 0)
            {
                string attr = config.GetKey(0);
                if (!String.IsNullOrEmpty(attr))
                {
                    throw new ProviderException("Unrecognized attribute: " + attr);
                }
            }
        }

        #endregion

        public override JobContact GetNewJobContact()
        {
            JobContact jobContact = new JobContact();
            jobContact.ID.Value = -1;
            return jobContact;
        }

        public override JobContact GetJobContact(DomainKey key)
        {
            JobContact jobContact = null;
            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetJobContact"))
            {
                db.AddInParameter(dbCmd, "@JobContactID", DbType.Int64, key.Value);

                DataSet ds = db.ExecuteDataSet(dbCmd);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow row = ds.Tables[0].Rows[0];
                    jobContact = new JobContact(row);
                }
            }
            return jobContact;
        }

        public override JobContact GetJobContact(Job job)
        {
            JobContact jobContact = null;
            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetJobContactByJob"))
            {
                db.AddInParameter(dbCmd, "@JobID", DbType.Int64, job.ID.Value);

                DataSet ds = db.ExecuteDataSet(dbCmd);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow row = ds.Tables[0].Rows[0];
                    jobContact = new JobContact(row);
                }
            }
            return jobContact;
        }

        public override JobContactCollection GetAllJobContacts()
        {
            JobContactCollection jobContacts = new JobContactCollection();
            DataSet ds = null;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetAllJobContacts"))
            {
                ds = db.ExecuteDataSet(dbCmd);
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    JobContact jobContact = new JobContact(row);
                    jobContacts.Add(jobContact);
                }
            }

            //return the results
            return jobContacts;
        }

        public override DomainKey SaveJobContact(JobContact jobContact)
        {    
            if (jobContact == null) 
            {
                throw new ArgumentNullException("jobContact", "Job Contact must be defined");
            }
            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_SaveJobContact"))
            {
                if (jobContact.Location == null)
                {
                    db.AddInParameter(dbCmd, "@LocationID", DbType.Int64, DBNull.Value);
                }
                else
                {
                    db.AddInParameter(dbCmd, "@LocationID", DbType.Int64, jobContact.Location.ID.Value);
                }

                db.AddInParameter(dbCmd, "@Name", DbType.String, jobContact.Name);
                db.AddInParameter(dbCmd, "@Phone", DbType.String, jobContact.Phone);
                db.AddInParameter(dbCmd, "@Email", DbType.String, jobContact.Email);
                db.AddInParameter(dbCmd, "@WebsiteUrl", DbType.String, jobContact.WebsiteUrl);
                db.AddInParameter(dbCmd, "@OldJobContactID", DbType.Int64, jobContact.ID.Value);

                db.AddOutParameter(dbCmd, "@JobContactID", DbType.Int64, 0);

                db.ExecuteNonQuery(dbCmd);
                
                object id = (long) db.GetParameterValue(dbCmd, "@JobContactID");
                jobContact.ID.Value = id;
                return jobContact.ID;
            }
        }

        public override void DeleteJobContact(JobContact jobContact)
        {
            if (jobContact == null) 
            {
                throw new ArgumentNullException("jobContact", "Job Contact must be defined");
            }
            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_DeleteJobContact"))
            {
                db.AddInParameter(dbCmd, "@JobContactID", DbType.Int64, jobContact.ID.Value);

                db.ExecuteNonQuery(dbCmd);
            }
        }

        public override bool IsUsingLocation(Location location) 
        {
            if (location == null)
            {
                throw new ArgumentNullException("location");
            }
            bool result = false;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_IsJobContactUsingLocation"))
            {
                db.AddInParameter(dbCmd, "@LocationID", DbType.Int64, location.ID.Value);
                
                DataSet ds = db.ExecuteDataSet(dbCmd);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    int count = (int) ds.Tables[0].Rows[0][0];
                    result = count > 0;
                }
            }
            return result;
        }

    }
}
