using System;
using System.Configuration.Provider;

namespace DotnetUserGroup.DataAccess.JobContacts
{
    public class JobContactProviderCollection : ProviderCollection
    {
        public new JobContactProvider this[string name]
        {
            get { return (JobContactProvider)base[name]; }
        }

        public override void Add(ProviderBase provider)
        {
            if (provider == null)
                throw new ArgumentNullException("provider");

            if (!(provider is JobContactProvider))
                throw new ArgumentException
                    ("Invalid provider type", "provider");

            base.Add(provider);
        }
    }
}
