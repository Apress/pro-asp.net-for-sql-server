using System.Configuration.Provider;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Jobs;
using DotnetUserGroup.DataAccess.Locations;

namespace DotnetUserGroup.DataAccess.JobContacts
{
    public abstract class JobContactProvider : ProviderBase, ILocationConsumer
    {

        #region "  Provider Methods  "

        public abstract JobContact GetNewJobContact();

        public abstract JobContact GetJobContact(DomainKey key);

        public abstract JobContact GetJobContact(Job job);

        public abstract JobContactCollection GetAllJobContacts();

        public abstract DomainKey SaveJobContact(JobContact jobContact);

        public abstract void DeleteJobContact(JobContact jobContact);
        
        public abstract bool IsUsingLocation(Location location);

        #endregion
    }
}
