using System;
using System.Collections.Specialized;
using System.Configuration.Provider;
using System.Data;
using System.Data.Common;
using System.Web.Configuration;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Events;
using DotnetUserGroup.DataAccess.Locations;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace DotnetUserGroup.DataAccess.Sponsors
{
    public class SqlSponsorProvider : SponsorProvider
    {

        #region "  Variables  "

        string connStringName = String.Empty;
        private Database db;

        #endregion

        #region "  Provider Methods  "

        /// <summary>
        /// SQL Implementation
        /// </summary>
        public override void Initialize(string name,
            NameValueCollection config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            if (String.IsNullOrEmpty(name))
            {
                name = "SqlSponsorProvider";
            }

            if (String.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "SQL Sponsors Provider");
            }

            base.Initialize(name, config);

            if (config["connectionStringName"] == null)
            {
                throw new ProviderException(
                    "Required attribute missing: connectionStringName");
            }

            connStringName = config["connectionStringName"].ToString();
            config.Remove("connectionStringName");

            if (WebConfigurationManager.ConnectionStrings[connStringName] == null)
            {
                throw new ProviderException("Missing connection string");
            }

            db = DatabaseFactory.CreateDatabase(connStringName);

            if (config.Count > 0)
            {
                string attr = config.GetKey(0);
                if (!String.IsNullOrEmpty(attr))
                {
                    throw new ProviderException("Unrecognized attribute: " + attr);
                }
            }
        }

        #endregion

        #region "  Implementation Methods  "

        public override Sponsor GetNewSponsor()
        {
            Sponsor sponsor = new Sponsor();
            sponsor.ID.Value = -1;
            return sponsor;
        }

        public override Sponsor GetSponsor(DomainKey key)
        {
            Sponsor sponsor = null;
            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetSponsor"))
            {
                db.AddInParameter(dbCmd, "@SponsorID", DbType.Int64, key.Value);

                DataSet ds = db.ExecuteDataSet(dbCmd);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow row = ds.Tables[0].Rows[0];
                    sponsor = new Sponsor(row);
                }
            }
            return sponsor;
        }
        
        public override Sponsor GetSponsor(Event evt)
        {
            Sponsor sponsor = null;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetSponsorByEvent"))
            {
                db.AddInParameter(dbCmd, "@EventID", DbType.Int64, evt.ID.Value);

                DataSet ds = db.ExecuteDataSet(dbCmd);

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow row = ds.Tables[0].Rows[0];
                    sponsor = new Sponsor(row);
                }
            }

            return sponsor;
        }

        public override SponsorCollection GetAllSponsors()
        {
            SponsorCollection sponsors = new SponsorCollection();
            //IDataReader dr = null;
            DataSet ds = null;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetAllSponsors"))
            {
                //dr = db.ExecuteReader(dbCmd);
                //while (dr.Read())
                //{
                //    Sponsor sponsor = new Sponsor(dr);
                //    sponsors.Add(sponsor);
                //}
                ds = db.ExecuteDataSet(dbCmd);
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    Sponsor sponsor = new Sponsor(row);
                    sponsors.Add(sponsor);
                }
            }

            //return the results
            return sponsors;
        }

        public override DomainKey SaveSponsor(Sponsor sponsor)
        {
            if (sponsor == null)
            {
                throw new ArgumentNullException("sponsor");
            }

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_SaveSponsor"))
            {
                if (sponsor.Location != null)
                {
                    db.AddInParameter(dbCmd, "@LocationID", DbType.Int64, sponsor.Location.ID.Value);
                }
                else
                {
                    db.AddInParameter(dbCmd, "@LocationID", DbType.Int64, DBNull.Value);
                }
                db.AddInParameter(dbCmd, "@Name", DbType.String, sponsor.Name);
                db.AddInParameter(dbCmd, "@Description", DbType.String, sponsor.Description);
                db.AddInParameter(dbCmd, "@WebsiteUrl", DbType.String, sponsor.WebsiteUrl);
                db.AddInParameter(dbCmd, "@LogoUrl", DbType.String, sponsor.LogoUrl);
                db.AddInParameter(dbCmd, "@LogoWidth", DbType.Int32, sponsor.LogoWidth);
                db.AddInParameter(dbCmd, "@LogoHeight", DbType.Int32, sponsor.LogoHeight);
                db.AddInParameter(dbCmd, "@OldSponsorID", DbType.Int64, sponsor.ID.Value);

                db.AddOutParameter(dbCmd, "@SponsorID", DbType.Int64, 0);

                db.ExecuteNonQuery(dbCmd);
                
                object id = (long) db.GetParameterValue(dbCmd, "@SponsorID");
                sponsor.ID.Value = id;
                return sponsor.ID;
            }
        }

        public override void DeleteSponsor(Sponsor sponsor)
        {
            if (sponsor == null) 
            {
                throw new ArgumentNullException("sponsor", "Sponsor must be defined");
            }
            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_DeleteSponsor"))
            {
                db.AddInParameter(dbCmd, "@SponsorID", DbType.Int64, sponsor.ID.Value);

                db.ExecuteNonQuery(dbCmd);
            }
        }

        public override bool IsUsingLocation(Location location)
        {
            if (location == null)
            {
                throw new ArgumentNullException("location");
            }
            bool result = false;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_IsSponsorUsingLocation"))
            {
                db.AddInParameter(dbCmd, "@LocationID", DbType.Int64, location.ID.Value);
                
                DataSet ds = db.ExecuteDataSet(dbCmd);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    int count = (int) ds.Tables[0].Rows[0][0];
                    result = count > 0;
                }
            }
            return result;
        }

        #endregion

    }
}
