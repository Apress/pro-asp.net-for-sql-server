using System.Configuration.Provider;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Events;
using DotnetUserGroup.DataAccess.Locations;

namespace DotnetUserGroup.DataAccess.Sponsors
{
    public abstract class SponsorProvider : ProviderBase, ILocationConsumer
    {

        #region "  Provider Methods  "

        public abstract Sponsor GetNewSponsor();

        public abstract Sponsor GetSponsor(DomainKey key);

        public abstract Sponsor GetSponsor(Event evt);

        public abstract SponsorCollection GetAllSponsors();

        public abstract DomainKey SaveSponsor(Sponsor sponsor);

        public abstract void DeleteSponsor(Sponsor sponsor);

        public abstract bool IsUsingLocation(Location location);

        #endregion

    }
}
