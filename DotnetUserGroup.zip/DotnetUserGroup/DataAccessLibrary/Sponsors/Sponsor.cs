using System.Data;
using System.Runtime.Serialization;
using System.ServiceModel;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Locations;

namespace DotnetUserGroup.DataAccess.Sponsors
{
    [DataContract]
    public class Sponsor : DomainObject<Sponsor>
    {
        protected internal Sponsor() { }

        public Sponsor(DataRow row)
        {
            Load(row);
        }

        public Sponsor(IDataReader dr)
        {
            Load(dr);
        }

        private string _name;
        
        [DataMember(Name = "Name",Order = 1)]
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private string _description;
        
        [DataMember(Name = "Description",Order = 1)]
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        private string _websiteUrl;
        
        [DataMember(Name = "WebsiteUrl",Order = 1)]
        public string WebsiteUrl
        {
            get { return _websiteUrl; }
            set { _websiteUrl = value; }
        }

        private string _logoUrl;
        
        [DataMember(Name = "LogoUrl",Order = 1)]
        public string LogoUrl
        {
            get { return _logoUrl; }
            set { _logoUrl = value; }
        }

        private int _logoWidth;
        
        [DataMember(Name = "LogoWidth",Order = 1)]
        public int LogoWidth
        {
            get { return _logoWidth; }
            set { _logoWidth = value; }
        }

        private int _logoHeight;
        
        [DataMember(Name = "LogoHeight",Order = 1)]
        public int LogoHeight
        {
            get { return _logoHeight; }
            set { _logoHeight = value; }
        }

        private Location _location;
        
        [DataMember(Name = "Location",Order = 1)]
        public Location Location
        {
            get {
                if (_location == null) 
                {
                    // lazy load the location
                    _location = LocationManager.DefaultProvider.GetLocation(this);
                }
                return _location;
            }
            set { _location = value; }
        }

    }
}
