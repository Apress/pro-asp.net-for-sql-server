using System;
using System.Configuration.Provider;

namespace DotnetUserGroup.DataAccess.Sponsors
{
    public class SponsorProviderCollection : ProviderCollection
    {
        public new SponsorProvider this[string name]
        {
            get { return (SponsorProvider)base[name]; }
        }

        public override void Add(ProviderBase provider)
        {
            if (provider == null)
                throw new ArgumentNullException("provider");

            if (!(provider is SponsorProvider))
                throw new ArgumentException
                    ("Invalid provider type", "provider");

            base.Add(provider);
        }
    }
}
