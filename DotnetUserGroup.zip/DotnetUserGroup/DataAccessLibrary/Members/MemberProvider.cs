using System;
using System.Configuration.Provider;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Events;

namespace DotnetUserGroup.DataAccess.Members
{

    public enum RegistrationStatus
    {
        Yes = 0,
        No = 1, 
        Maybe = 2
    }

    public abstract class MemberProvider : ProviderBase
    {

        #region "  Provider Methods  "

        public abstract Member GetNewMember();

        public abstract Member GetMember(DomainKey key);

        public abstract MemberCollection GetAllMembers();

        public abstract DomainKey SaveMember(Member member);

        public abstract void DeleteMember(Member member);

        public abstract void SaveRegistration(Member member, Event evt, RegistrationStatus status);
        
        public abstract MemberCollection GetRegisteredMembers(Event evt);
        
        public abstract int GetRegisteredMemberCount(Event evt);
        
        #endregion

    }
}
