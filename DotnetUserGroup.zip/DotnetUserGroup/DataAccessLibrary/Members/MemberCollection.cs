using System.Collections.ObjectModel;
using System.Runtime.Serialization;

namespace DotnetUserGroup.DataAccess.Members
{
    public class MemberCollection : Collection<Member>
    {
    }
}
