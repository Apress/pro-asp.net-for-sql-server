using System;
using System.Configuration.Provider;
using System.Web.Configuration;

namespace DotnetUserGroup.DataAccess.Members
{
    public class MemberManager
    {
        private static MemberProvider _defaultProvider = null;
        private static MemberProviderCollection _providers = null;
        private static object _lock = new object();

        private MemberManager() {}

        public static MemberProvider DefaultProvider
        {
            get 
            {
                LoadProviders();
                return _defaultProvider;
            }
        }

        public static MemberProvider GetProvider(string name)
        {
            LoadProviders();
            if (String.IsNullOrEmpty(name))
            {
                return DefaultProvider;
            }
            else
            {
                return _providers[name];
            }
        }

        private static void LoadProviders()
        {
            // Avoid claiming lock if providers are already loaded
            if (_defaultProvider == null)
            {
                lock (_lock)
                {
                    // Do this again to make sure _defaultProvider is still null
                    if (_defaultProvider == null)
                    {
                        MemberSection section = (MemberSection)
                            WebConfigurationManager.GetSection
                            ("dotnetUserGroup/members");

                        _providers = new MemberProviderCollection();

                        ProvidersHelper.InstantiateProviders(
                            section.Providers, _providers, 
                            typeof(MemberProvider));

                        _defaultProvider = _providers[section.DefaultProvider];

                        if (_defaultProvider == null)
                            throw new ProviderException
                                ("Unable to load default MemberProvider");
                    }
                }
            }
        }
    }
}
