using System;
using System.Data;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using DotnetUserGroup.DataAccess.Common;

namespace DotnetUserGroup.DataAccess.Members
{
    [DataContract]
    public class Member : DomainObject<Member>
    {
        protected internal Member() { }

        public Member(DataRow row)
        {
            Load(row);
        }

        public Member(IDataReader dr)
        {
            Load(dr);
        }

        public static Member CreateNewMember()
        {
            Member member = new Member();
            member.ID.Value = (long) -1;
            return member;
        }

        private Guid _userId = Guid.Empty;
        
        [DataMember(Name = "UserID",Order = 1)]
        public Guid UserID
        {
            get { return _userId; }
            set { _userId = value; }
        }

        private bool _isActive = true;
        
        [DataMember(Name = "IsActive",Order = 1)]
        public bool IsActive
        {
            get { return _isActive; }
            set { _isActive = value; }
        }

    }
}
