using System;
using System.Configuration.Provider;

namespace DotnetUserGroup.DataAccess.Members
{
    public class MemberProviderCollection : ProviderCollection
    {
        public new MemberProvider this[string name]
        {
            get { return (MemberProvider)base[name]; }
        }

        public override void Add(ProviderBase provider)
        {
            if (provider == null)
                throw new ArgumentNullException("provider");

            if (!(provider is MemberProvider))
                throw new ArgumentException
                    ("Invalid provider type", "provider");

            base.Add(provider);
        }
    }
}
