using System;
using System.Collections.Specialized;
using System.Configuration.Provider;
using System.Data;
using System.Data.Common;
using System.Web.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Events;

namespace DotnetUserGroup.DataAccess.Members
{
    public class SqlMemberProvider : MemberProvider
    {

        #region "  Variables  "

        private string connStringName = String.Empty;
        private Database db;

        #endregion

        #region "  Provider Methods  "

        /// <summary>
        /// SQL Implementation
        /// </summary>
        public override void Initialize(string name,
            NameValueCollection config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            if (String.IsNullOrEmpty(name))
            {
                name = "SqlMemberProvider";
            }

            if (String.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "SQL Members Provider");
            }

            base.Initialize(name, config);

            if (config["connectionStringName"] == null)
            {
                throw new ProviderException(
                    "Required attribute missing: connectionStringName");
            }

            connStringName = config["connectionStringName"].ToString();
            config.Remove("connectionStringName");

            if (WebConfigurationManager.ConnectionStrings[connStringName] == null)
            {
                throw new ProviderException("Missing connection string");
            }

            db = DatabaseFactory.CreateDatabase(connStringName);

            if (config.Count > 0)
            {
                string attr = config.GetKey(0);
                if (!String.IsNullOrEmpty(attr))
                {
                    throw new ProviderException("Unrecognized attribute: " + attr);
                }
            }
        }

        #endregion

        #region "  Implementation Methods  "

        public override Member GetNewMember()
        {
            return Member.CreateNewMember();
        }

        public override Member GetMember(DomainKey key)
        {
            Member member = null;
            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetMember"))
            {
                db.AddInParameter(dbCmd, "@MemberID", DbType.Int64, key.Value);

                DataSet ds = db.ExecuteDataSet(dbCmd);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow row = ds.Tables[0].Rows[0];
                    member = new Member(row);
                }
            }
            return member;
        }

        public override MemberCollection GetAllMembers()
        {
            MemberCollection members = new MemberCollection();
            DataSet ds = null;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetAllMembers"))
            {
                ds = db.ExecuteDataSet(dbCmd);
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    Member member = new Member(row);
                    members.Add(member);
                }
            }

            //return the results
            return members;
        }

        public override DomainKey SaveMember(Member member)
        {
            if (member == null) 
            {
                throw new ArgumentNullException("member", "Member must be defined");
            }

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_SaveMember"))
            {
                db.AddInParameter(dbCmd, "@UserID", DbType.Guid, member.UserID);
                db.AddInParameter(dbCmd, "@IsActive", DbType.Boolean, member.IsActive);
                db.AddInParameter(dbCmd, "@OldMemberID", DbType.Int64, member.ID.Value);

                db.AddOutParameter(dbCmd, "@MemberID", DbType.Int64, 0);

                db.ExecuteNonQuery(dbCmd);
                
                object id = (long) db.GetParameterValue(dbCmd, "@MemberID");
                member.ID.Value = id;
                return member.ID;
            }
        }

        public override void DeleteMember(Member member)
        {
            if (member == null) 
            {
                throw new ArgumentNullException("member", "Member must be defined");
            }
            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_DeleteMember"))
            {
                db.AddInParameter(dbCmd, "@MemberID", DbType.Int64, member.ID.Value);

                db.ExecuteNonQuery(dbCmd);
            }
        }

        public override void SaveRegistration(Member member, Event evt, RegistrationStatus status)
        {
            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_SaveMemberRegistration"))
            {
                string statusString = "Y";
                if (RegistrationStatus.No.Equals(status))
                {
                    statusString = "N";
                }
                else if (RegistrationStatus.Maybe.Equals(status))
                {
                    statusString = "M";
                }
                db.AddInParameter(dbCmd, "@MemberID", DbType.Int64, member.ID.Value);
                db.AddInParameter(dbCmd, "@EventID", DbType.Int64, evt.ID.Value);
                db.AddInParameter(dbCmd, "@Status", DbType.String, statusString);

                db.ExecuteNonQuery(dbCmd);
                RegistrationStatus x = (RegistrationStatus) Enum.Parse(typeof(RegistrationStatus), "1");
            }
        }
        
        public override MemberCollection GetRegisteredMembers(Event evt)
        {
            MemberCollection members = new MemberCollection();
            DataSet ds = null;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetRegisteredMembers"))
            {
                db.AddInParameter(dbCmd, "@EventID", DbType.Int64, evt.ID.Value);

                ds = db.ExecuteDataSet(dbCmd);
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    Member member = new Member(row);
                    members.Add(member);
                }
            }

            //return the results
            return members;
        }
        
        public override int GetRegisteredMemberCount(Event evt)
        {
            return GetRegisteredMembers(evt).Count;
        }

        #endregion

    }
}
