namespace DotnetUserGroup.DataAccess.Locations
{
    public interface ILocationConsumer
    {
        bool IsUsingLocation(Location location);
    }
}
