using System.Configuration.Provider;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Events;
using DotnetUserGroup.DataAccess.JobContacts;
using DotnetUserGroup.DataAccess.Jobs;
using DotnetUserGroup.DataAccess.Sponsors;

namespace DotnetUserGroup.DataAccess.Locations
{
    public abstract class LocationProvider : ProviderBase
    {
        #region "  Provider Methods  "

        public abstract Location GetNewLocation();

        public abstract Location GetLocation(DomainKey key);

        public abstract Location GetLocation(Event evt);

        public abstract Location GetLocation(Job job);

        public abstract Location GetLocation(JobContact jobContact);

        public abstract Location GetLocation(Sponsor sponsor);

        public abstract LocationCollection GetAllLocations();

        public abstract DomainKey SaveLocation(Location location);

        public abstract void DeleteLocation(Location location);

        #endregion
    }
}
