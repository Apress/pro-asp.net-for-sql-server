using System;
using System.Collections.Generic;
using System.Configuration;
using System.Configuration.Provider;
using System.Web;
using System.Web.Configuration;
using DotnetUserGroup.DataAccess.Common;

namespace DotnetUserGroup.DataAccess.Locations
{
    public class LocationManager
    {
        private static LocationProvider _defaultProvider = null;
        private static LocationProviderCollection _providers = null;
        private static object _lock = new object();

        private LocationManager() {}

        public static LocationProvider DefaultProvider
        {
            get 
            {
                LoadProviders();
                return _defaultProvider; 
            }
        }

        public static LocationProvider GetProvider(string name)
        {
            LoadProviders();
            if (String.IsNullOrEmpty(name))
            {
                return DefaultProvider;
            }
            else
            {
                return _providers[name];
            }
        }

        private static void LoadProviders()
        {
            // Avoid claiming lock if providers are already loaded
            if (_defaultProvider == null)
            {
                lock (_lock)
                {
                    // Do this again to make sure _defaultProvider is still null
                    if (_defaultProvider == null)
                    {
                        LocationSection section = (LocationSection)
                            WebConfigurationManager.GetSection
                            ("dotnetUserGroup/locations");

                        _providers = new LocationProviderCollection();

                        ProvidersHelper.InstantiateProviders(
                            section.Providers, _providers, 
                            typeof(LocationProvider));

                        _defaultProvider = _providers[section.DefaultProvider];

                        if (_defaultProvider == null)
                            throw new ProviderException
                                ("Unable to load default LocationProvider");
                    }
                }
            }
        }

        private static ILocationConsumer[] GetLocationConsumers()
        {
            List<ILocationConsumer> locationConsumers = 
                new List<ILocationConsumer>();
            foreach (ProviderBase provider in 
                AssemblyHelper.GetMatchedProviders(typeof(ILocationConsumer)))
            {
                ILocationConsumer locationConsumer = provider as ILocationConsumer;
                if (locationConsumer != null)
                {
                    locationConsumers.Add(locationConsumer);
                }
            }
            return locationConsumers.ToArray();
        }

        public static bool IsLocationInUse(Location location)
        {
            foreach (ILocationConsumer locationConsumer in GetLocationConsumers())
            {
                if (locationConsumer.IsUsingLocation(location))
                {
                    return true;
                }
            }
            return false;
        }

    }
}
