using System.Data;
using System.Runtime.Serialization;
using System.ServiceModel;
using DotnetUserGroup.DataAccess.Common;

namespace DotnetUserGroup.DataAccess.Locations
{
    [DataContract]
    public class Location : DomainObject<Location>
    {
        protected internal Location() { }

        public Location(DataRow row)
        {
            Load(row);
        }

        public Location(IDataReader dr)
        {
            Load(dr);
        }

        private string _title;
        
        [DataMember(Name = "Title",Order = 1)]
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        private string _address1;
        
        [DataMember(Name = "Address1",Order = 1)]
        public string Address1
        {
            get { return _address1; }
            set { _address1 = value; }
        }

        private string _address2;
        
        [DataMember(Name = "Address2",Order = 1)]
        public string Address2
        {
            get { return _address2; }
            set { _address2 = value; }
        }

        private string _city;
        
        [DataMember(Name = "City",Order = 1)]
        public string City
        {
            get { return _city; }
            set { _city = value; }
        }

        private string _state;
        
        [DataMember(Name = "State",Order = 1)]
        public string State
        {
            get { return _state; }
            set { _state = value; }
        }

        private string _zip;
        
        [DataMember(Name = "Zip",Order = 1)]
        public string Zip
        {
            get { return _zip; }
            set { _zip = value; }
        }

    }
}
