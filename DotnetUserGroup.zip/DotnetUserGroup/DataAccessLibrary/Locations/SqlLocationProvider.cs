using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration.Provider;
using System.Data;
using System.Data.Common;
using System.Text;
using System.Web.Configuration;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Events;
using DotnetUserGroup.DataAccess.JobContacts;
using DotnetUserGroup.DataAccess.Jobs;
using DotnetUserGroup.DataAccess.Sponsors;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace DotnetUserGroup.DataAccess.Locations
{
    public class SqlLocationProvider : LocationProvider
    {

        #region "  Variables  "

        string connStringName = String.Empty;
        private Database db;

        #endregion

        #region "  Provider Methods  "

        /// <summary>
        /// SQL Implementation
        /// </summary>
        public override void Initialize(
            string name, NameValueCollection config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            if (String.IsNullOrEmpty(name))
            {
                name = "SqlLocationProvider";
            }

            if (String.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "SQL Locations Provider");
            }

            base.Initialize(name, config);

            if (config["connectionStringName"] == null)
            {
                throw new ProviderException(
                    "Required attribute missing: connectionStringName");
            }

            connStringName = config["connectionStringName"].ToString();
            config.Remove("connectionStringName");

            if (WebConfigurationManager.ConnectionStrings[connStringName] == null)
            {
                throw new ProviderException("Missing connection string");
            }

            db = DatabaseFactory.CreateDatabase(connStringName);

            if (config.Count > 0)
            {
                string attr = config.GetKey(0);
                if (!String.IsNullOrEmpty(attr))
                {
                    throw new ProviderException("Unrecognized attribute: " + attr);
                }
            }
        }

        #endregion

        #region "  Implementation Methods  "

        public override Location GetNewLocation()
        {
            Location location = new Location();
            return location;
        }

        public override LocationCollection GetAllLocations()
        {
            LocationCollection locations = new LocationCollection();
            DataSet ds = null;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetAllLocations"))
            {
                ds = db.ExecuteDataSet(dbCmd);
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    Location location = new Location(row);
                    locations.Add(location);
                }
            }

            return locations;
        }

        public override Location GetLocation(DomainKey key)
        {
            Location location = null;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetLocation"))
            {
                db.AddInParameter(dbCmd, "@LocationID", DbType.Int64, key.Value);

                DataSet ds = db.ExecuteDataSet(dbCmd);

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow row = ds.Tables[0].Rows[0];
                    location = new Location(row);
                }
            }

            return location;
        }

        public override Location GetLocation(Event evt)
        {
            Location location = null;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetLocationByEvent"))
            {
                db.AddInParameter(dbCmd, "@EventID", DbType.Int64, evt.ID.Value);

                DataSet ds = db.ExecuteDataSet(dbCmd);

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow row = ds.Tables[0].Rows[0];
                    location = new Location(row);
                }
            }

            return location;
        }
        
        public override Location GetLocation(Job job)
        {
            Location location = null;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetLocationByJob"))
            {
                db.AddInParameter(dbCmd, "@JobID", DbType.Int64, job.ID.Value);

                DataSet ds = db.ExecuteDataSet(dbCmd);

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow row = ds.Tables[0].Rows[0];
                    location = new Location(row);
                }
            }

            return location;
        }

        public override Location GetLocation(JobContact jobContact)
        {
            Location location = null;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetLocationByJobContact"))
            {
                db.AddInParameter(dbCmd, "@JobContactID", DbType.Int64, jobContact.ID.Value);

                DataSet ds = db.ExecuteDataSet(dbCmd);

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow row = ds.Tables[0].Rows[0];
                    location = new Location(row);
                }
            }

            return location;
        }

        public override Location GetLocation(Sponsor sponsor)
        {
            Location location = null;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetLocationBySponsor"))
            {
                db.AddInParameter(dbCmd, "@SponsorID", DbType.Int64, sponsor.ID.Value);

                DataSet ds = db.ExecuteDataSet(dbCmd);

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow row = ds.Tables[0].Rows[0];
                    location = new Location(row);
                }
            }

            return location;
        }

        public override DomainKey SaveLocation(Location location)
        {
            if (location == null)
            {
                throw new ArgumentNullException("location");
            }

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_SaveLocation"))
            {
                db.AddInParameter(dbCmd, "@Title", DbType.String, location.Title);
                db.AddInParameter(dbCmd, "@Address1", DbType.String, location.Address1);
                db.AddInParameter(dbCmd, "@Address2", DbType.String, location.Address2);
                db.AddInParameter(dbCmd, "@City", DbType.String, location.City);
                db.AddInParameter(dbCmd, "@State", DbType.String, location.State);
                db.AddInParameter(dbCmd, "@Zip", DbType.String, location.Zip);
                db.AddInParameter(dbCmd, "@OldLocationID", DbType.Int64, location.ID.Value);

                db.AddOutParameter(dbCmd, "@LocationID", DbType.Int64, 0);

                db.ExecuteNonQuery(dbCmd);
                object id = (long) db.GetParameterValue(dbCmd, "@LocationID");
                location.ID.Value = id;
                return location.ID;
            }
        }

        public override void DeleteLocation(Location location)
        {
            if (location == null) 
            {
                throw new ArgumentNullException(
                    "location", "Location must be defined");
            }
            if (LocationManager.IsLocationInUse(location))
            {
                throw new DomainException(
                    "Location is in use and cannot be deleted.");
            }

            using (DbCommand dbCmd = 
                db.GetStoredProcCommand("dug_DeleteLocation"))
            {
                db.AddInParameter(dbCmd, "@LocationID", 
                    DbType.Int64, location.ID.Value);
                db.ExecuteNonQuery(dbCmd);
            }
        }

        #endregion

    }
}
