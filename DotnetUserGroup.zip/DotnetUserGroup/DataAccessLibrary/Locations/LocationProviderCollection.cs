using System;
using System.Configuration.Provider;

namespace DotnetUserGroup.DataAccess.Locations
{
    public class LocationProviderCollection : ProviderCollection
    {
        public new LocationProvider this[string name]
        {
            get { return (LocationProvider)base[name]; }
        }

        public override void Add(ProviderBase provider)
        {
            if (provider == null)
                throw new ArgumentNullException("provider");

            if (!(provider is LocationProvider))
                throw new ArgumentException
                    ("Invalid provider type", "provider");

            base.Add(provider);
        }
    }
}
