using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace DotnetUserGroup.DataAccess.Locations
{
    public class LocationCollection : Collection<Location>
    {
    }
}
