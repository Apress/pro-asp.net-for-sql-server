using System.Configuration;
using DotnetUserGroup.DataAccess.Common;

namespace DotnetUserGroup.DataAccess.Locations
{
    public class LocationSection : ProviderConfigurationSection
    {
        [ConfigurationProperty("providers")]
        public override ProviderSettingsCollection Providers
        {
            get { return (ProviderSettingsCollection)base["providers"]; }
        }

        [StringValidator(MinLength = 1)]
        [ConfigurationProperty("defaultProvider",
            DefaultValue = "SqlSponsorProvider")]
        public override string DefaultProvider
        {
            get { return (string)base["defaultProvider"]; }
            set { base["defaultProvider"] = value; }
        }
    }
}
