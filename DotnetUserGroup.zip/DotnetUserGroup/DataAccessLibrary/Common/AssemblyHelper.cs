using System;
using System.Collections.Generic;
using System.Configuration;
using System.Configuration.Provider;
using System.Reflection;
using System.Web;
using System.Web.Configuration;
using DotnetUserGroup.DataAccess.Locations;

namespace DotnetUserGroup.DataAccess.Common
{
    public class AssemblyHelper
    {

        public static Type[] GetMatchedTypes(Assembly assembly, Type searchType)
        {
            List<Type> types = new List<Type>();
            Module[] modules = assembly.GetLoadedModules();
            foreach (Module module in modules)
            {
                foreach (Type type in module.GetTypes())
                {
                    if (type.IsClass && 
                        !type.IsAbstract && 
                        searchType.IsAssignableFrom(type))
                    {
                        types.Add(type);
                    }
                }
            }
            return types.ToArray();
        }

        public static ProviderBase[] GetMatchedProviders(Type searchType)
        {
            List<ProviderBase> providers = new List<ProviderBase>();
            
            DugConfiguration sectionGroup = 
                DugConfiguration.GetConfiguration();
            
            foreach (ProviderConfigurationSection section in sectionGroup.ProviderSections)
            {
                foreach (ProviderSettings settings in section.Providers)
                {
                    // The assembly should be in \bin or GAC
                    Type providerType = Type.GetType(settings.Type, false);
                    Assembly providerAssembly = providerType.Assembly;
                    if (providerType.IsClass && 
                        !providerType.IsAbstract && 
                        searchType.IsAssignableFrom(providerType))
                    {
                        ProviderBase provider = 
                            Activator.CreateInstance(providerType) as ProviderBase;
                        if (provider != null)
                        {
                            provider.Initialize(settings.Name, settings.Parameters);
                            providers.Add(provider);
                        }
                    }
                }
            }
            return providers.ToArray();
        }

    }
}
