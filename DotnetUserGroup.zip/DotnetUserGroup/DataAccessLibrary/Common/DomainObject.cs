using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.Runtime.Serialization;
using System.ServiceModel;
using DotnetUserGroup.DataAccess.Events;
using DotnetUserGroup.DataAccess.JobContacts;
using DotnetUserGroup.DataAccess.Jobs;
using DotnetUserGroup.DataAccess.Locations;
using DotnetUserGroup.DataAccess.Speakers;
using DotnetUserGroup.DataAccess.Sponsors;

namespace DotnetUserGroup.DataAccess.Common
{

    /// <summary>
    /// DataObject
    /// </summary>
    [DataContract]
    public abstract class DomainObject<T> : IComparable where T : DomainObject<T>
    {

        public static readonly DateTime DefaultDateTime = 
          DateTime.Parse("01/01/1754");

        #region "  Load Methods  "
        
        /// <summary>
        /// Loads the values from the DataRow and works to match up column names
        /// with Property names.  For example <code>row["Name"] = this.Name</code>
        /// and <code>row["IsActive"] = this.IsActive</code>. The Property must 
        /// also be set as public, not protected and also be writeable.
        /// </summary>
        /// <param name="row"></param>
        protected internal void Load(DataRow row)
        {
            List<string> mappings = GetMappings(row.Table);

            foreach (string name in mappings) 
            {
                SetValue(name, row);
            }
            if (row["ID"] != null)
            {
                ID.Value = row["ID"];
            }
        }

        protected internal void Load(IDataReader dr)
        {
            List<string> mappings = GetMappings(dr);

            foreach (string name in mappings)
            {
                SetValue(name, dr);
            }
            if (mappings.Contains("ID"))
            {
                ID.Value = dr["ID"];
            }
        }

        private static Dictionary<Type,List<string>> _mappings = 
          new Dictionary<Type,List<string>>();
        
        public List<string> GetMappings(DataTable dataTable)
        {
            Type type = GetType();
            if (! _mappings.ContainsKey(type))
            {
                _mappings[type] = CreateMappings(dataTable);
            }
            return _mappings[type];
        }

        public List<string> GetMappings(IDataReader dr)
        {
            Type type = GetType();
            if (! _mappings.ContainsKey(type))
            {
                _mappings[type] = CreateMappings(dr);
            }
            return _mappings[type];
        }

        public List<string> CreateMappings(DataTable dataTable)
        {
            List<string> mappings = new List<string>();
            Type type = GetType();

            foreach (PropertyInfo pi in type.GetProperties())
            {
                if (pi.CanWrite && 
                    dataTable.Columns.Contains(pi.Name) && 
                    dataTable.Columns[pi.Name].DataType.Equals(pi.PropertyType))
                {
                    mappings.Add(pi.Name);
                }
            }
            return mappings;
        }

        public List<string> CreateMappings(IDataReader dr)
        {
            List<string> mappings = new List<string>();

            for (int i=0;i<dr.FieldCount;i++)
            {
                PropertyInfo pi = GetProperty(dr.GetName(i));
                if (pi != null &&
                    pi.CanWrite &&
                    pi.PropertyType.Equals(dr.GetFieldType(i)))
                {
                    mappings.Add(dr.GetName(i));
                }
            }
            
            return mappings;
        }

        private void SetValue(string name, DataRow row)
        {
            PropertyInfo pi = GetProperty(name);
            if (!DBNull.Value.Equals(row[name]))
            {
                pi.SetValue(this, row[name], null);
            }
        }

        private void SetValue(string name, IDataReader dr)
        {
            PropertyInfo pi = GetProperty(name);
            if (!DBNull.Value.Equals(dr[name]))
            {
                pi.SetValue(this, dr[name], null);
            }
        }

        private static Dictionary<string,PropertyInfo> _properties = 
          new Dictionary<string,PropertyInfo>();

        private PropertyInfo GetProperty(string name)
        {
            if (!_properties.ContainsKey(name))
            {
                _properties[name] = GetType().GetProperty(name);
            }
            return _properties[name];
        }

        #endregion

        #region "  Properties  "

        private DomainKey _domainKey = DomainKey.Default;

        /// <summary>
        /// Object ID
        /// </summary>
        [DataMember(Name = "ID",Order = 1)]
        public DomainKey ID
        {
            get { return _domainKey; }
            set { _domainKey = value; }
        }

        private DateTime _created = DefaultDateTime;

        /// <summary>
        /// Object created time
        /// </summary>
        [DataMember(Name = "Created",Order = 1)]
        public DateTime Created
        {
            get
            {
                return _created;
            }
            set
            {
                _created = value;
            }
        }

        private DateTime _modified = DefaultDateTime;

        /// <summary>
        /// Object modified time
        /// </summary>
        [DataMember(Name = "Modified",Order = 1)]
        public DateTime Modified
        {
            get
            {
                return _modified;
            }
            set
            {
                _modified = value;
            }
        }

        #endregion

        #region "  Comparison Methods  "

        /// <summary>
        /// Base override
        /// </summary>
        public int CompareTo(Object obj)
        {
            int result = 0;
            DomainObject<T> otherDomainObject = obj as DomainObject<T>;
            if (otherDomainObject != null)
            {
                result = ID.CompareTo(otherDomainObject.ID);
                if (result == 0)
                {
                    result = Created.CompareTo(otherDomainObject.Created);
                    if (result == 0)
                    {
                        result = Modified.CompareTo(otherDomainObject.Modified);
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Base override
        /// </summary>
        public override int GetHashCode()
        {
            return ID.GetHashCode();
        }

        /// <summary>
        /// Base override
        /// </summary>
        public override bool Equals(object obj)
        {
            DomainObject<T> domainObject = obj as DomainObject<T>;
            if (domainObject != null)
            {
                if (ID.Equals(domainObject.ID))
                {
                    return true;
                }
            }
            return false;
        }

        #endregion

    }
}
