using System;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace DotnetUserGroup.DataAccess.Common
{
    [DataContract]
    public class DomainKey : IComparable<DomainKey>
    {
        public DomainKey(object keyValue)
        {
            Value = keyValue;
        }

        private object _keyValue;
        
        [DataMember(Name = "Value",Order = 1)]
        public object Value
        {
            get { return _keyValue; }
            set
            {
                // check in the order which is most likely
                if (value is Int32 ||
                    value is Guid ||
                    value is Int64 ||
                    value is Int16)
                {
                    _keyValue = value;
                }
                else
                {
                    throw new Exception("Type not supported as a DomainKey: " + 
                      value.GetType());
                }
            }
        }

        public static DomainKey Default
        {
            get
            {
                DomainKey defaultKey = new DomainKey(-1);
                return defaultKey;
            }
        }

        #region "  Comparison Methods  "

        public int CompareTo(DomainKey other)
        {
            return Value.ToString().CompareTo(other.Value.ToString());
        }

        public override int GetHashCode()
        {
            return Value.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            if (obj != null && obj is DomainKey)
            {
                DomainKey other = (DomainKey) obj;
                return Equals(other);
            }
            return false;
        }

        public bool Equals(DomainKey other)
        {
            if (other != null && Value.Equals(other.Value))
            {
                return true;
            }
            return false;
        }

        #endregion

    }
}
