using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;

namespace DotnetUserGroup.DataAccess.Common
{
    public abstract class ProviderConfigurationSection : ConfigurationSection
    {
        public abstract ProviderSettingsCollection Providers { get; }
        public abstract string DefaultProvider { get; set; }
    }
}
