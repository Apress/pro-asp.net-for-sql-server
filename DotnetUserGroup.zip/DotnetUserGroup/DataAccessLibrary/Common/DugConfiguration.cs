using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Web;
using System.Web.Configuration;
using DotnetUserGroup.DataAccess.Events;
using DotnetUserGroup.DataAccess.JobContacts;
using DotnetUserGroup.DataAccess.Jobs;
using DotnetUserGroup.DataAccess.Locations;
using DotnetUserGroup.DataAccess.Speakers;
using DotnetUserGroup.DataAccess.Sponsors;

namespace DotnetUserGroup.DataAccess.Common
{
    public class DugConfiguration : ConfigurationSectionGroup
    {
        public static DugConfiguration GetConfiguration()
        {
            Configuration config = OpenConfiguration();
            DugConfiguration sectionGroup = 
                config.SectionGroups["dotnetUserGroup"] as DugConfiguration;
            return sectionGroup;
        }

        private List<ProviderConfigurationSection> _providerSections = null;

        public ProviderConfigurationSection[] ProviderSections
        {
            get
            {
                if (_providerSections == null)
                {
                    _providerSections = new List<ProviderConfigurationSection>();
                    _providerSections.Add(EventSection);
                    _providerSections.Add(JobContactSection);
                    _providerSections.Add(JobSection);
                    _providerSections.Add(LocationSection);
                    _providerSections.Add(SpeakerSection);
                    _providerSections.Add(SponsorSection);
                }
                return _providerSections.ToArray();
            }
        }
        
        [ConfigurationProperty("events")]
        public EventSection EventSection
        {
            get {
                return Sections["events"] as EventSection;
            }
        }
        
        [ConfigurationProperty("jobContacts")]
        public JobContactSection JobContactSection
        {
            get {
                return Sections["jobContacts"] as JobContactSection;
            }
        }
        
        [ConfigurationProperty("jobs")]
        public JobSection JobSection
        {
            get {
                return Sections["jobs"] as JobSection;
            }
        }
        
        [ConfigurationProperty("locations")]
        public LocationSection LocationSection
        {
            get {
                return Sections["locations"] as LocationSection;
            }
        }

        [ConfigurationProperty("speakers")]
        public SpeakerSection SpeakerSection
        {
            get {
                return Sections["speakers"] as SpeakerSection;
            }
        }
        
        [ConfigurationProperty("sponsors")]
        public SponsorSection SponsorSection
        {
            get {
                return Sections["sponsors"] as SponsorSection;
            }
        }
        
        private static Configuration OpenConfiguration()
        {
            Configuration config;
            HttpContext context = HttpContext.Current;
            if (context != null)
            {
                string path = "~";
                config = WebConfigurationManager.OpenWebConfiguration(path);
            }
            else
            {
                config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            }
            return config;
        }

    }
}
