using System;
using System.Configuration.Provider;

namespace DotnetUserGroup.DataAccess.Speakers
{
    public class SpeakerProviderCollection : ProviderCollection
    {
        public new SpeakerProvider this[string name]
        {
            get { return (SpeakerProvider)base[name]; }
        }

        public override void Add(ProviderBase provider)
        {
            if (provider == null)
                throw new ArgumentNullException("provider");

            if (!(provider is SpeakerProvider))
                throw new ArgumentException
                    ("Invalid provider type", "provider");

            base.Add(provider);
        }
    }
}
