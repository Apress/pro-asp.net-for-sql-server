using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace DotnetUserGroup.DataAccess.Speakers
{
    public class SpeakerCollection : Collection<Speaker>
    {
    }
}
