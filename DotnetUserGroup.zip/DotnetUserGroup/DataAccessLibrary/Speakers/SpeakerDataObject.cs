using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.Caching;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Locations;

namespace DotnetUserGroup.DataAccess.Speakers
{
    [DataObject()]
    public class SpeakerDataObject
    {
        
        #region "  Constants  "

        private static readonly string AllSpeakersCacheKey = "AllSpeakers-" + typeof(SpeakerCollection).FullName;

        #endregion

        #region "  Data Methods  "

        public Speaker GetNewSpeaker()
        {
            return Provider.GetNewSpeaker();
        }
        
        [DataObjectMethod(DataObjectMethodType.Select)]
        public Speaker GetSpeaker(DomainKey key)
        {
            return Provider.GetSpeaker(key);
        }
        
        [DataObjectMethod(DataObjectMethodType.Select)]
        public SpeakerCollection GetAllSpeakers()
        {
            return Provider.GetAllSpeakers();
        }
        
        [DataObjectMethod(DataObjectMethodType.Select)]
        public SpeakerCollection GetAllSpeakersWithCache()
        {
            SpeakerCollection speakerCollection = null;
            
            Cache cache = HttpRuntime.Cache;
            if (cache[AllSpeakersCacheKey] != null)
            {
                return cache[AllSpeakersCacheKey] as SpeakerCollection;
            }
            else
            {
                speakerCollection = Provider.GetAllSpeakers();
                CacheItemRemovedCallback removedCallback = delegate(
                        string key, object value, CacheItemRemovedReason reason)
                           {
                               // do nothing
                           };
                cache.Insert(AllSpeakersCacheKey, speakerCollection, null,
                    DateTime.Now.AddSeconds(3600), Cache.NoSlidingExpiration,
                    CacheItemPriority.Normal, removedCallback);
            }
            return speakerCollection;
        }

        public SpeakerCollection GetAllSpeakersWithCache(int maximumRows, int startRowIndex)
        {
            SpeakerCollection fullSpeakersCollection = GetAllSpeakersWithCache();
            SpeakerCollection filteredSpeakersCollection = new SpeakerCollection();
            
            int i = 0;
            int maxIndex = startRowIndex + maximumRows;
            foreach (Speaker speaker in fullSpeakersCollection)
            {
                if (i >=startRowIndex && i < maxIndex)
                {
                    filteredSpeakersCollection.Add(speaker);
                }
                i++;
                if (i >= maxIndex)
                {
                    break;
                }
            }

            return filteredSpeakersCollection;
        }

        public int GetAllSpeakersCount()
        {
            return GetAllSpeakersWithCache().Count;
        }
        
        [DataObjectMethod(DataObjectMethodType.Select)]
        public SpeakerCollection GetSpeakersByDate(DateTime targetDate)
        {
            return Provider.GetSpeakersByDate(targetDate);
        }

        public DomainKey SaveSpeaker(Speaker speaker)
        {
            ClearAllSpeakersCache();
            return Provider.SaveSpeaker(speaker);
        }

        public void DeleteSpeaker(Speaker speaker)
        {
            Provider.DeleteSpeaker(speaker);
            ClearAllSpeakersCache();
        }

        private void ClearAllSpeakersCache()
        {
            Cache cache = HttpRuntime.Cache;
            cache.Remove(AllSpeakersCacheKey);
        }
        
        #endregion

        #region "  Provider Properties  "

        public SpeakerProvider Provider
        {
            get
            {
                return SpeakerManager.GetProvider(ProviderName);
            }
        }

        private string _providerName = String.Empty;

        public string ProviderName
        {
            get 
            {
                return _providerName;
            }
            set
            {
                _providerName = value;
            }
        }

        #endregion

    }
}
