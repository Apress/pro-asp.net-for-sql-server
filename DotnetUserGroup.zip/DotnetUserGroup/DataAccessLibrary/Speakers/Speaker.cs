using System;
using System.Collections.Generic;
using System.Data;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using DotnetUserGroup.DataAccess.Common;

namespace DotnetUserGroup.DataAccess.Speakers
{
    [DataContract]
    public class Speaker : DomainObject<Speaker>
    {
        protected internal Speaker() { }

        public Speaker(DataRow row)
        {
            Load(row);
        }

        public Speaker(IDataReader dr)
        {
            Load(dr);
        }

        public string FullName
        {
            get
            {
                if (String.IsNullOrEmpty(MiddleInitial))
                {
                    return FirstName + " " + LastName;
                }
                else
                {
                    return FirstName + " " + MiddleInitial + ". " + LastName;
                }
            }
        }

        private string _firstName;
        
        [DataMember(Name = "FirstName",Order = 1)]
        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }

        private string _middleInitial;
        
        [DataMember(Name = "MiddleInitial",Order = 1)]
        public string MiddleInitial
        {
            get { return _middleInitial; }
            set { _middleInitial = value; }
        }

        private string _lastName;
        
        [DataMember(Name = "LastName",Order = 1)]
        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }

        private string _description;
        
        [DataMember(Name = "Description",Order = 1)]
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        private string _websiteUrl;
        
        [DataMember(Name = "WebsiteUrl",Order = 1)]
        public string WebsiteUrl
        {
            get { return _websiteUrl; }
            set { _websiteUrl = value; }
        }

        private string _email;
        
        [DataMember(Name = "Email",Order = 1)]
        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }

        private string _phone;
        
        [DataMember(Name = "Phone",Order = 1)]
        public string Phone
        {
            get { return _phone; }
            set { _phone = value; }
        }

    }
}
