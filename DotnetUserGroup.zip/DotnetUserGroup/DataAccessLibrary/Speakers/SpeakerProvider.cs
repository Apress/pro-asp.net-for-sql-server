using System;
using System.Configuration.Provider;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Events;
using DotnetUserGroup.DataAccess.Locations;

namespace DotnetUserGroup.DataAccess.Speakers
{
    public abstract class SpeakerProvider : ProviderBase
    {

        #region "  Provider Methods  "

        public abstract Speaker GetNewSpeaker();

        public abstract Speaker GetSpeaker(DomainKey key);

        public abstract Speaker GetSpeaker(Event evt);

        public abstract SpeakerCollection GetAllSpeakers();

        public abstract SpeakerCollection GetSpeakersByDate(DateTime targetDate);

        public abstract DomainKey SaveSpeaker(Speaker speaker);

        public abstract void DeleteSpeaker(Speaker speaker);

        #endregion

    }
}
