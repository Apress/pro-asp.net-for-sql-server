using System;
using System.Configuration.Provider;
using System.Web.Configuration;

namespace DotnetUserGroup.DataAccess.Speakers
{
    public class SpeakerManager
    {
        private static SpeakerProvider _defaultProvider = null;
        private static SpeakerProviderCollection _providers = null;
        private static object _lock = new object();

        private SpeakerManager() {}

        public static SpeakerProvider DefaultProvider
        {
            get 
            {
                LoadProviders();
                return _defaultProvider;
            }
        }

        public static SpeakerProvider GetProvider(string name)
        {
            LoadProviders();
            if (String.IsNullOrEmpty(name))
            {
                return DefaultProvider;
            }
            else
            {
                return _providers[name];
            }
        }

        private static void LoadProviders()
        {
            // Avoid claiming lock if providers are already loaded
            if (_defaultProvider == null)
            {
                lock (_lock)
                {
                    // Do this again to make sure _defaultProvider is still null
                    if (_defaultProvider == null)
                    {
                        SpeakerSection section = (SpeakerSection)
                            WebConfigurationManager.GetSection
                            ("dotnetUserGroup/speakers");

                        _providers = new SpeakerProviderCollection();

                        ProvidersHelper.InstantiateProviders(
                            section.Providers, _providers, 
                            typeof(SpeakerProvider));

                        _defaultProvider = _providers[section.DefaultProvider];

                        if (_defaultProvider == null)
                            throw new ProviderException
                                ("Unable to load default SpeakerProvider");
                    }
                }
            }
        }
    }
}
