using System;
using System.Collections.Specialized;
using System.Configuration.Provider;
using System.Data;
using System.Data.Common;
using System.Web.Configuration;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Events;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace DotnetUserGroup.DataAccess.Speakers
{
    public class SqlSpeakerProvider : SpeakerProvider
    {

        #region "  Variables  "

        string connStringName = String.Empty;
        private Database db;

        #endregion

        #region "  Provider Methods  "

        /// <summary>
        /// SQL Implementation
        /// </summary>
        public override void Initialize(string name,
            NameValueCollection config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            if (String.IsNullOrEmpty(name))
            {
                name = "SqlSpeakerProvider";
            }

            if (String.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "SQL Speakers Provider");
            }

            base.Initialize(name, config);

            if (config["connectionStringName"] == null)
            {
                throw new ProviderException(
                    "Required attribute missing: connectionStringName");
            }

            connStringName = config["connectionStringName"].ToString();
            config.Remove("connectionStringName");

            if (WebConfigurationManager.ConnectionStrings[connStringName] == null)
            {
                throw new ProviderException("Missing connection string");
            }

            db = DatabaseFactory.CreateDatabase(connStringName);

            if (config.Count > 0)
            {
                string attr = config.GetKey(0);
                if (!String.IsNullOrEmpty(attr))
                {
                    throw new ProviderException("Unrecognized attribute: " + attr);
                }
            }
        }

        #endregion

        #region "  Implementation Methods  "

        public override Speaker GetNewSpeaker()
        {
            Speaker speaker = new Speaker();
            speaker.ID.Value = -1;
            return speaker;
        }

        public override Speaker GetSpeaker(DomainKey key)
        {
            Speaker speaker = null;
            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetSpeaker"))
            {
                db.AddInParameter(dbCmd, "@SpeakerID", DbType.Int64, key.Value);

                DataSet ds = db.ExecuteDataSet(dbCmd);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow row = ds.Tables[0].Rows[0];
                    speaker = new Speaker(row);
                }
            }
            return speaker;
        }
        
        public override Speaker GetSpeaker(Event evt)
        {
            Speaker speaker = null;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetSpeakerByEvent"))
            {
                db.AddInParameter(dbCmd, "@EventID", DbType.Int64, evt.ID.Value);

                DataSet ds = db.ExecuteDataSet(dbCmd);

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow row = ds.Tables[0].Rows[0];
                    speaker = new Speaker(row);
                }
            }

            return speaker;
        }

        public override SpeakerCollection GetAllSpeakers()
        {
            SpeakerCollection speakers = new SpeakerCollection();
            //IDataReader dr = null;
            DataSet ds = null;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetAllSpeakers"))
            {
                //dr = db.ExecuteReader(dbCmd);
                //while (dr.Read())
                //{
                //    Speaker speaker = new Speaker(dr);
                //    speakers.Add(speaker);
                //}
                ds = db.ExecuteDataSet(dbCmd);
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    Speaker speaker = new Speaker(row);
                    speakers.Add(speaker);
                }
            }

            //return the results
            return speakers;
        }

        public override SpeakerCollection GetSpeakersByDate(DateTime targetDate)
        {
            SpeakerCollection speakers = new SpeakerCollection();
            //IDataReader dr = null;
            DataSet ds = null;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetSpeakersByDate"))
            {
                //dr = db.ExecuteReader(dbCmd);
                //while (dr.Read())
                //{
                //    Speaker speaker = new Speaker(dr);
                //    speakers.Add(speaker);
                //}
                ds = db.ExecuteDataSet(dbCmd);
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    Speaker speaker = new Speaker(row);
                    speakers.Add(speaker);
                }
            }

            //return the results
            return speakers;
        }

        public override DomainKey SaveSpeaker(Speaker speaker)
        {
            if (speaker == null)
            {
                throw new ArgumentNullException("speaker");
            }

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_SaveSpeaker"))
            {
                db.AddInParameter(dbCmd, "@FirstName", DbType.String, speaker.FirstName);
                db.AddInParameter(dbCmd, "@MiddleInitial", DbType.String, speaker.MiddleInitial);
                db.AddInParameter(dbCmd, "@LastName", DbType.String, speaker.LastName);
                db.AddInParameter(dbCmd, "@Description", DbType.String, speaker.Description);
                db.AddInParameter(dbCmd, "@WebsiteUrl", DbType.String, speaker.WebsiteUrl);
                db.AddInParameter(dbCmd, "@Email", DbType.String, speaker.Email);
                db.AddInParameter(dbCmd, "@Phone", DbType.String, speaker.Phone);
                db.AddInParameter(dbCmd, "@OldSpeakerID", DbType.Int64, speaker.ID.Value);

                db.AddOutParameter(dbCmd, "@SpeakerID", DbType.Int64, 0);

                db.ExecuteNonQuery(dbCmd);
                
                object id = (long) db.GetParameterValue(dbCmd, "@SpeakerID");
                speaker.ID.Value = id;
                return speaker.ID;
            }
        }

        public override void DeleteSpeaker(Speaker speaker)
        {
            if (speaker == null) 
            {
                throw new ArgumentNullException("speaker", "Speaker must be defined");
            }

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_DeleteSpeaker"))
            {
                db.AddInParameter(dbCmd, "@SpeakerID", DbType.Int64, speaker.ID.Value);

                db.ExecuteNonQuery(dbCmd);
            }
        }

        #endregion

    }
}
