using System.Configuration.Provider;
using System.Web.Configuration;

namespace DotnetUserGroup.DataAccess.Jobs
{
    public class JobManager
    {
        private static JobProvider _defaultProvider = null;
        private static JobProviderCollection _providers = null;
        private static object _lock = new object();

        private JobManager() {}

        public static JobProvider DefaultProvider
        {
            get 
            {
                LoadProviders();
                return _defaultProvider; 
            }
        }

        public static JobProvider GetProvider(string name)
        {
            LoadProviders();
            return _providers[name];
        }

        private static void LoadProviders()
        {
            // Avoid claiming lock if providers are already loaded
            if (_defaultProvider == null)
            {
                lock (_lock)
                {
                    // Do this again to make sure _defaultProvider is still null
                    if (_defaultProvider == null)
                    {
                        JobSection section = (JobSection)
                            WebConfigurationManager.GetSection
                            ("dotnetUserGroup/jobs");

                        _providers = new JobProviderCollection();

                        ProvidersHelper.InstantiateProviders(
                            section.Providers, _providers, 
                            typeof(JobProvider));

                        _defaultProvider = _providers[section.DefaultProvider];

                        if (_defaultProvider == null)
                            throw new ProviderException
                                ("Unable to load default JobProvider");
                    }
                }
            }
        }
    }
}
