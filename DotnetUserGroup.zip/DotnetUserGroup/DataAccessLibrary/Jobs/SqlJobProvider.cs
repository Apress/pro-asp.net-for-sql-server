using System;
using System.Collections.Specialized;
using System.Configuration.Provider;
using System.Data;
using System.Data.Common;
using System.Web.Configuration;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.JobContacts;
using DotnetUserGroup.DataAccess.Locations;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace DotnetUserGroup.DataAccess.Jobs
{
    public class SqlJobProvider : JobProvider
    {

        #region "  Variables  "

        string connStringName = String.Empty;
        private Database db;

        #endregion

        #region "  Provider Methods  "

        /// <summary>
        /// SQL Implementation
        /// </summary>
        public override void Initialize(string name,
            NameValueCollection config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            if (String.IsNullOrEmpty(name))
            {
                name = "SqlJobProvider";
            }

            if (String.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "SQL Jobs Provider");
            }

            base.Initialize(name, config);

            if (config["connectionStringName"] == null)
            {
                throw new ProviderException(
                    "Required attribute missing: connectionStringName");
            }

            connStringName = config["connectionStringName"].ToString();
            config.Remove("connectionStringName");

            if (WebConfigurationManager.ConnectionStrings[connStringName] == null)
            {
                throw new ProviderException("Missing connection string");
            }

            db = DatabaseFactory.CreateDatabase(connStringName);

            if (config.Count > 0)
            {
                string attr = config.GetKey(0);
                if (!String.IsNullOrEmpty(attr))
                {
                    throw new ProviderException("Unrecognized attribute: " + attr);
                }
            }
        }

        #endregion

        #region "  Implementation Methods  "

        public override Job GetNewJob() 
        {
            Job job = new Job();
            job.ID.Value = -1;
            return job;
        }

        public override Job GetJob(DomainKey key)
        {
            Job job = null;
            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetJob"))
            {
                db.AddInParameter(dbCmd, "@JobID", DbType.Int64, key.Value);

                DataSet ds = db.ExecuteDataSet(dbCmd);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow row = ds.Tables[0].Rows[0];
                    job = new Job(row);
                }
            }
            return job;
        }

        public override JobCollection GetAllJobs()
        {
            JobCollection jobs = new JobCollection();
            DataSet ds = null;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetAllJobs"))
            {
                ds = db.ExecuteDataSet(dbCmd);
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    Job job = new Job(row);
                    jobs.Add(job);
                }
            }

            //return the results
            return jobs;
        }

        public override DomainKey SaveJob(Job job)
        {
            if (job == null)
            {
                throw new ArgumentNullException("job");
            }

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_SaveJob"))
            {
                if (job.Location == null) 
                {
                    db.AddInParameter(dbCmd, "@LocationID", DbType.Int64, DBNull.Value);
                }
                else 
                {
                    db.AddInParameter(dbCmd, "@LocationID", DbType.Int64, job.Location.ID.Value);
                }

                if (job.Contact == null) 
                {
                    db.AddInParameter(dbCmd, "@JobContactID", DbType.Int64, DBNull.Value);
                }
                else 
                {
                    db.AddInParameter(dbCmd, "@JobContactID", DbType.Int64, job.Contact.ID.Value);
                }
                
                db.AddInParameter(dbCmd, "@Title", DbType.String, job.Title);
                db.AddInParameter(dbCmd, "@Description", DbType.String, job.Description);
                db.AddInParameter(dbCmd, "@Skills", DbType.String, job.Skills);
                db.AddInParameter(dbCmd, "@MinExp", DbType.Int16, job.MinExp);
                db.AddInParameter(dbCmd, "@MaxExp", DbType.Int16, job.MaxExp);
                db.AddInParameter(dbCmd, "@CompanyName", DbType.String, job.CompanyName);
                db.AddInParameter(dbCmd, "@WebsiteUrl", DbType.String, job.WebsiteUrl);
                db.AddInParameter(dbCmd, "@EffectiveStartDate", DbType.DateTime, job.EffectiveStartDate);
                db.AddInParameter(dbCmd, "@EffectiveEndDate", DbType.DateTime, job.EffectiveEndDate);
                db.AddInParameter(dbCmd, "@OldJobID", DbType.Int64, job.ID.Value);

                db.AddOutParameter(dbCmd, "@JobID", DbType.Int64, 0);

                db.ExecuteNonQuery(dbCmd);
                
                object id = (long) db.GetParameterValue(dbCmd, "@JobID");
                job.ID.Value = id;
                return job.ID;
            }
        }

        public override void DeleteJob(Job job)
        {
            if (job == null) 
            {
                throw new ArgumentNullException("job", "Job must be defined");
            }
            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_DeleteJob"))
            {
                db.AddInParameter(dbCmd, "@JobID", DbType.Int64, job.ID.Value);

                db.ExecuteNonQuery(dbCmd);
            }
        }

        public override bool IsUsingLocation(Location location) 
        {
            if (location == null)
            {
                throw new ArgumentNullException("location");
            }
            bool result = false;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_IsJobUsingLocation"))
            {
                db.AddInParameter(dbCmd, "@LocationID", DbType.Int64, location.ID.Value);
                
                DataSet ds = db.ExecuteDataSet(dbCmd);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    int count = (int) ds.Tables[0].Rows[0][0];
                    result = count > 0;
                }
            }
            return result;
        }

        #endregion

    }
}
