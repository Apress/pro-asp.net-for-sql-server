using System.Configuration.Provider;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Locations;

namespace DotnetUserGroup.DataAccess.Jobs
{
    public abstract class JobProvider : ProviderBase, ILocationConsumer
    {

        #region "  Provider Methods  "

        public abstract Job GetNewJob();

        public abstract Job GetJob(DomainKey key);

        public abstract JobCollection GetAllJobs();

        public abstract DomainKey SaveJob(Job job);

        public abstract void DeleteJob(Job job);
        
        public abstract bool IsUsingLocation(Location location);

        #endregion

    }
}
