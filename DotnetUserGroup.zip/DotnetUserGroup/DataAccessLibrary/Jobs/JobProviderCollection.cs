using System;
using System.Configuration.Provider;

namespace DotnetUserGroup.DataAccess.Jobs
{
    public class JobProviderCollection : ProviderCollection
    {
        public new JobProvider this[string name]
        {
            get { return (JobProvider)base[name]; }
        }

        public override void Add(ProviderBase provider)
        {
            if (provider == null)
                throw new ArgumentNullException("provider");

            if (!(provider is JobProvider))
                throw new ArgumentException
                    ("Invalid provider type", "provider");

            base.Add(provider);
        }
    }
}
