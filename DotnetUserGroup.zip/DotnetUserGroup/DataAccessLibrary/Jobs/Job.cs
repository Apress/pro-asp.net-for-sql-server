using System;
using System.Data;
using System.Runtime.Serialization;
using System.ServiceModel;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.JobContacts;
using DotnetUserGroup.DataAccess.Locations;

namespace DotnetUserGroup.DataAccess.Jobs
{
    [DataContract]
    public class Job : DomainObject<Job>
    {
        protected internal Job() { }

        public Job(DataRow row)
        {
            Load(row);
        }

        public Job(IDataReader dr)
        {
            Load(dr);
        }

        private Location _location;
        
        [DataMember(Name = "Location",Order = 1)]
        public Location Location
        {
            get {
                if (_location == null) 
                {
                    // lazy load the location
                    _location = LocationManager.DefaultProvider.GetLocation(this);
                }
                return _location;
            }
            set { _location = value; }
        }

        private JobContact _jobContact;
        
        [DataMember(Name = "Contact",Order = 1)]
        public JobContact Contact
        {
            get 
            {
                // lazy load the job contact
                if (_jobContact == null)
                {
                    _jobContact = JobContactManager.DefaultProvider.GetJobContact(this);
                }
                return _jobContact;
            }
            set { _jobContact = value; }
        }

        private string _title = String.Empty;
        
        [DataMember(Name = "Title",Order = 1)]
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        private string _description = String.Empty;
        
        [DataMember(Name = "Description",Order = 1)]
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        private string _skills = String.Empty;
        
        [DataMember(Name = "Skills",Order = 1)]
        public string Skills
        {
            get { return _skills; }
            set { _skills = value; }
        }

        private int _minExp = 0;
        
        [DataMember(Name = "MinExp",Order = 1)]
        public int MinExp
        {
            get { return _minExp; }
            set { _minExp = value; }
        }

        private int _maxExp = 100;
        
        [DataMember(Name = "MaxExp",Order = 1)]
        public int MaxExp
        {
            get { return _maxExp; }
            set { _maxExp = value; }
        }

        private string _companyName = String.Empty;
        
        [DataMember(Name = "CompanyName",Order = 1)]
        public string CompanyName
        {
            get { return _companyName; }
            set { _companyName = value; }
        }

        private string _websiteUrl = String.Empty;
        
        [DataMember(Name = "WebsiteUrl",Order = 1)]
        public string WebsiteUrl
        {
            get { return _websiteUrl; }
            set { _websiteUrl = value; }
        }

        private DateTime _effectiveStartDate = DefaultDateTime;
        
        [DataMember(Name = "EffectiveStartDate",Order = 1)]
        public DateTime EffectiveStartDate
        {
            get { return _effectiveStartDate; }
            set { _effectiveStartDate = value; }
        }

        private DateTime _effectiveEndDate = DefaultDateTime;
        
        [DataMember(Name = "EffectiveEndDate",Order = 1)]
        public DateTime EffectiveEndDate
        {
            get { return _effectiveEndDate; }
            set { _effectiveEndDate = value; }
        }

    }
}
