using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace DotnetUserGroup.DataAccess.Jobs
{
    public class JobCollection : Collection<Job>
    {
    }
}
