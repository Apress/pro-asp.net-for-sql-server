using System;
using System.Configuration.Provider;
using System.Web.Configuration;

namespace DotnetUserGroup.DataAccess.Events
{
    public class EventManager
    {
        private static EventProvider _defaultProvider = null;
        private static EventProviderCollection _providers = null;
        private static object _lock = new object();

        private EventManager() {}

        public static EventProvider DefaultProvider
        {
            get 
            {
                LoadProviders();
                return _defaultProvider;
            }
        }

        public static EventProvider GetProvider(string name)
        {
            LoadProviders();
            if (String.IsNullOrEmpty(name))
            {
                return DefaultProvider;
            }
            else
            {
                return _providers[name];
            }
        }

        private static void LoadProviders()
        {
            // Avoid claiming lock if providers are already loaded
            if (_defaultProvider == null)
            {
                lock (_lock)
                {
                    // Do this again to make sure _defaultProvider is still null
                    if (_defaultProvider == null)
                    {
                        EventSection section = (EventSection)
                            WebConfigurationManager.GetSection
                            ("dotnetUserGroup/events");

                        _providers = new EventProviderCollection();

                        ProvidersHelper.InstantiateProviders(
                            section.Providers, _providers, 
                            typeof(EventProvider));

                        _defaultProvider = _providers[section.DefaultProvider];

                        if (_defaultProvider == null)
                            throw new ProviderException
                                ("Unable to load default EventProvider");
                    }
                }
            }
        }
    }
}
