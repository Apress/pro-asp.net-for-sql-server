using System;
using System.Collections.Specialized;
using System.Configuration.Provider;
using System.Data;
using System.Data.Common;
using System.Web.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Locations;
using DotnetUserGroup.DataAccess.Sponsors;

namespace DotnetUserGroup.DataAccess.Events
{
    public class SqlEventProvider : EventProvider, ILocationConsumer
    {

        #region "  Variables  "

        private string connStringName = String.Empty;
        private Database db;

        #endregion

        #region "  Provider Methods  "

        /// <summary>
        /// SQL Implementation
        /// </summary>
        public override void Initialize(string name,
            NameValueCollection config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            if (String.IsNullOrEmpty(name))
            {
                name = "SqlEventProvider";
            }

            if (String.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "SQL Events Provider");
            }

            base.Initialize(name, config);

            if (config["connectionStringName"] == null)
            {
                throw new ProviderException(
                    "Required attribute missing: connectionStringName");
            }

            connStringName = config["connectionStringName"].ToString();
            config.Remove("connectionStringName");

            if (WebConfigurationManager.ConnectionStrings[connStringName] == null)
            {
                throw new ProviderException("Missing connection string");
            }

            db = DatabaseFactory.CreateDatabase(connStringName);

            if (config.Count > 0)
            {
                string attr = config.GetKey(0);
                if (!String.IsNullOrEmpty(attr))
                {
                    throw new ProviderException("Unrecognized attribute: " + attr);
                }
            }
        }

        #endregion

        #region "  Implementation Methods  "

        public override Event GetNewEvent()
        {
            return Event.CreateNewEvent();
        }

        public override Event GetEvent(DomainKey key)
        {
            Event evt = null;
            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetEvent"))
            {
                db.AddInParameter(dbCmd, "@EventID", DbType.Int64, key.Value);

                DataSet ds = db.ExecuteDataSet(dbCmd);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow row = ds.Tables[0].Rows[0];
                    evt = new Event(row);
                }
            }
            return evt;
        }

        public override EventCollection GetAllEvents()
        {
            EventCollection events = new EventCollection();
            DataSet ds = null;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetAllEvents"))
            {
                ds = db.ExecuteDataSet(dbCmd);
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    Event evt = new Event(row);
                    events.Add(evt);
                }
            }

            //return the results
            return events;
        }

        public override EventCollection GetEventsByDate(DateTime targetDate)
        {
            EventCollection events = new EventCollection();
            DataSet ds = null;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_GetEventsByDate"))
            {
                db.AddInParameter(dbCmd, "@TargetDate", DbType.DateTime, targetDate);

                ds = db.ExecuteDataSet(dbCmd);
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    Event evt = new Event(row);
                    events.Add(evt);
                }
            }

            //return the results
            return events;
        }

        public override DomainKey SaveEvent(Event evt)
        {
            if (evt == null) 
            {
                throw new ArgumentNullException("evt", "Event must be defined");
            }

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_SaveEvent"))
            {
                if (evt.Speaker == null) 
                {
                    db.AddInParameter(dbCmd, "@SpeakerID", DbType.Int64, DBNull.Value);
                }
                else 
                {
                    db.AddInParameter(dbCmd, "@SpeakerID", DbType.Int64, evt.Speaker.ID.Value);
                }
                
                if (evt.Sponsor == null) 
                {
                    db.AddInParameter(dbCmd, "@SponsorID", DbType.Int64, DBNull.Value);
                }
                else 
                {
                    db.AddInParameter(dbCmd, "@SponsorID", DbType.Int64, evt.Sponsor.ID.Value);
                }

                if (evt.Location == null) 
                {
                    db.AddInParameter(dbCmd, "@LocationID", DbType.Int64, DBNull.Value);
                }
                else 
                {
                    db.AddInParameter(dbCmd, "@LocationID", DbType.Int64, evt.Location.ID.Value);
                }

                db.AddInParameter(dbCmd, "@Title", DbType.String, evt.Title);
                db.AddInParameter(dbCmd, "@Description", DbType.String, evt.Description);
                db.AddInParameter(dbCmd, "@MeetingDate", DbType.DateTime, evt.MeetingDate);
                db.AddInParameter(dbCmd, "@OldEventID", DbType.Int64, evt.ID.Value);

                db.AddOutParameter(dbCmd, "@EventID", DbType.Int64, 0);

                db.ExecuteNonQuery(dbCmd);
                
                object id = (long) db.GetParameterValue(dbCmd, "@EventID");
                evt.ID.Value = id;
                return evt.ID;
            }
        }

        public override void DeleteEvent(Event evt)
        {
            if (evt == null) 
            {
                throw new ArgumentNullException("evt", "Event must be defined");
            }
            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_DeleteEvent"))
            {
                db.AddInParameter(dbCmd, "@EventID", DbType.Int64, evt.ID.Value);

                db.ExecuteNonQuery(dbCmd);
            }
        }
        
        public override bool IsUsingLocation(Location location)
        {
            if (location == null)
            {
                throw new ArgumentNullException("location");
            }
            bool result = false;

            using (DbCommand dbCmd = db.GetStoredProcCommand("dug_IsEventUsingLocation"))
            {
                db.AddInParameter(dbCmd, "@LocationID", DbType.Int64, location.ID.Value);
                
                DataSet ds = db.ExecuteDataSet(dbCmd);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    int count = (int) ds.Tables[0].Rows[0][0];
                    result = count > 0;
                }
            }
            return result;
        }

        #endregion

    }
}
