using System.Collections.ObjectModel;
using System.Runtime.Serialization;

namespace DotnetUserGroup.DataAccess.Events
{
    public class EventCollection : Collection<Event>
    {
    }
}
