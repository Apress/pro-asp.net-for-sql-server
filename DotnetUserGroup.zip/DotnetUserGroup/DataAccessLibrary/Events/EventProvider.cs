using System;
using System.Configuration.Provider;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Locations;

namespace DotnetUserGroup.DataAccess.Events
{
    public abstract class EventProvider : ProviderBase, ILocationConsumer
    {

        #region "  Provider Methods  "

        public abstract Event GetNewEvent();

        public abstract Event GetEvent(DomainKey key);

        public abstract EventCollection GetAllEvents();

        public abstract EventCollection GetEventsByDate(DateTime targetDate);

        public abstract DomainKey SaveEvent(Event evt);

        public abstract void DeleteEvent(Event evt);
        
        public abstract bool IsUsingLocation(Location location);

        #endregion

    }
}
