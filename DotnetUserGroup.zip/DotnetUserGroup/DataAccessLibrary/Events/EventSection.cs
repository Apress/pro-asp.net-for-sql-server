using System.Configuration;
using DotnetUserGroup.DataAccess.Common;

namespace DotnetUserGroup.DataAccess.Events
{
    public class EventSection : ProviderConfigurationSection
    {
        [ConfigurationProperty("providers")]
        public override ProviderSettingsCollection Providers
        {
            get { return (ProviderSettingsCollection)base["providers"]; }
        }

        [StringValidator(MinLength = 1)]
        [ConfigurationProperty("defaultProvider",
            DefaultValue = "SqlEventProvider")]
        public override string DefaultProvider
        {
            get { return (string)base["defaultProvider"]; }
            set { base["defaultProvider"] = value; }
        }

        [StringValidator(MinLength = 1)]
        [ConfigurationProperty("speakerProvider",
            DefaultValue = "SqlSpeakerProvider", 
            IsRequired = false)]
        public string SpeakerProvider
        {
            get { return (string)base["speakerProvider"]; }
            set { base["speakerProvider"] = value; }
        }

        [StringValidator(MinLength = 1)]
        [ConfigurationProperty("sponsorProvider",
            DefaultValue = "SqlSponsorProvider", 
            IsRequired = false)]
        public string SponsorProvider
        {
            get { return (string)base["sponsorProvider"]; }
            set { base["sponsorProvider"] = value; }
        }

        [StringValidator(MinLength = 1)]
        [ConfigurationProperty("locationProvider",
            DefaultValue = "SqlLocationProvider", 
            IsRequired = false)]
        public string LocationProvider
        {
            get { return (string)base["locationProvider"]; }
            set { base["locationProvider"] = value; }
        }
    }
}
