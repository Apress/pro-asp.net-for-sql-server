using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Locations;

namespace DotnetUserGroup.DataAccess.Events
{
    [DataObject()]
    public class EventDataObject
    {

        #region "  Data Methods  "

        public Event GetNewEvent()
        {
            return Provider.GetNewEvent();
        }
        
        [DataObjectMethod(DataObjectMethodType.Select)]
        public Event GetEvent(DomainKey key)
        {
            return Provider.GetEvent(key);
        }
        
        [DataObjectMethod(DataObjectMethodType.Select)]
        public EventCollection GetAllEvents()
        {
            return Provider.GetAllEvents();
        }
        
        [DataObjectMethod(DataObjectMethodType.Select)]
        public EventCollection GetEventsByDate(DateTime targetDate)
        {
            return Provider.GetEventsByDate(targetDate);
        }
        
        [DataObjectMethod(DataObjectMethodType.Update)]
        public DomainKey SaveEvent(Event evt)
        {
            return Provider.SaveEvent(evt);
        }

        [DataObjectMethod(DataObjectMethodType.Delete)]
        public void DeleteEvent(Event evt)
        {
            Provider.DeleteEvent(evt);
        }
        
        public bool IsUsingLocation(Location location)
        {
            return Provider.IsUsingLocation(location);
        }

        #endregion

        #region "  Provider Properties  "

        public EventProvider Provider
        {
            get
            {
                return EventManager.GetProvider(ProviderName);
            }
        }

        private string _providerName = String.Empty;

        public string ProviderName
        {
            get 
            {
                return _providerName;
            }
            set
            {
                _providerName = value;
            }
        }

        #endregion

    }
}
