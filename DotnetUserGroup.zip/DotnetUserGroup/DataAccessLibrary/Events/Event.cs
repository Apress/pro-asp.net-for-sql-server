using System;
using System.Data;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Locations;
using DotnetUserGroup.DataAccess.Speakers;
using DotnetUserGroup.DataAccess.Sponsors;

namespace DotnetUserGroup.DataAccess.Events
{
    [DataContract]
    public class Event : DomainObject<Event>
    {
        protected internal Event() { }

        public Event(DataRow row)
        {
            Load(row);
        }

        public Event(IDataReader dr)
        {
            Load(dr);
        }

        public static Event CreateNewEvent()
        {
            Event evt = new Event();
            evt.ID.Value = (long) -1;
            return evt;
        }

        private string _title;
        
        [DataMember(Name = "Title",Order = 1)]
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        private string _description;
        
        [DataMember(Name = "Description",Order = 1)]
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        private DateTime _meetingDate = DefaultDateTime;
        
        [DataMember(Name = "MeetingDate",Order = 1)]
        public DateTime MeetingDate
        {
            get { return _meetingDate; }
            set { _meetingDate = value; }
        }

        private Speaker _speaker;
        
        [DataMember(Name = "Speaker",Order = 1)]
        public Speaker Speaker
        {
            get 
            {
                if (_speaker == null)
                {
                    // lazy load the speaker
                    EventSection section = new EventSection();
                    _speaker = SpeakerManager.
                        GetProvider(section.SpeakerProvider).GetSpeaker(this);
                }
                return _speaker; 
            }
            set { _speaker = value; }
        }

        private Sponsor _sponsor;
        
        [DataMember(Name = "Sponsor",Order = 1)]
        public Sponsor Sponsor
        {
            get 
            {
                if (_sponsor == null)
                {
                    // lazy load the sponsor
                    EventSection section = new EventSection();
                    _sponsor = SponsorManager.
                        GetProvider(section.SponsorProvider).GetSponsor(this);
                }
                return _sponsor;
            }
            set { _sponsor = value; }
        }

        private Location _location;
        
        [DataMember(Name = "Location",Order = 1)]
        public Location Location
        {
            get 
            {   
                if (_location == null) 
                {
                    // lazy load the location
                    EventSection section = new EventSection();
                    _location = LocationManager.
                        GetProvider(section.LocationProvider).GetLocation(this);
                }
                return _location; 
            }
            set { _location = value; }
        }

    }
}
