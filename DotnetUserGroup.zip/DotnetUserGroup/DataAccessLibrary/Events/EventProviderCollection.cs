using System;
using System.Configuration.Provider;

namespace DotnetUserGroup.DataAccess.Events
{
    public class EventProviderCollection : ProviderCollection
    {
        public new EventProvider this[string name]
        {
            get { return (EventProvider)base[name]; }
        }

        public override void Add(ProviderBase provider)
        {
            if (provider == null)
                throw new ArgumentNullException("provider");

            if (!(provider is EventProvider))
                throw new ArgumentException
                    ("Invalid provider type", "provider");

            base.Add(provider);
        }
    }
}
