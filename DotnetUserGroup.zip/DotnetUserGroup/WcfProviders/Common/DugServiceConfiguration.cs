using System;
using System.Configuration;
using System.Web;
using System.Web.Configuration;
using DotnetUserGroup.DataAccess.WcfProviders.Events;

namespace DotnetUserGroup.DataAccess.WcfProviders.Common
{
    public class DugServiceConfiguration : ConfigurationSectionGroup
    {
        public static DugServiceConfiguration GetConfiguration()
        {
            Configuration config = OpenConfiguration();
            
            ConfigurationSectionGroup parentSectionGroup = 
                config.SectionGroups["dotnetUserGroup"];
            DugServiceConfiguration sectionGroup = 
                parentSectionGroup.SectionGroups["services"] as 
                DugServiceConfiguration;
            return sectionGroup;
        }

        [ConfigurationProperty("eventService")]
        public EventServiceSection EventServiceSection
        {
            get 
            {
                return Sections["eventService"] as EventServiceSection;
            }
        }
        
        private static Configuration OpenConfiguration()
        {
            Configuration config;
            HttpContext context = HttpContext.Current;
            if (context != null)
            {
                string path = "~";
                config = WebConfigurationManager.OpenWebConfiguration(path);
            }
            else
            {
                config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            }
            return config;
        }
    }
}
