using System;
using System.ServiceModel;
using System.Configuration;
using System.ServiceModel.Configuration;
using System.Text;

namespace DotnetUserGroup.DataAccess.WcfProviders.Common
{
    public static class WcfHelper
    {

        public static bool IsSelfHosting(Type contractType)
        {
            return GetIsSelfHosting(contractType);
        }

        public static bool GetIsSelfHosting(Type contractType)
        {
            bool isSelfHosting = false;
            ServicesSection config = ConfigurationManager.GetSection("system.serviceModel/services") as ServicesSection;
            if (config != null)
            {
                foreach (ServiceElement service in config.Services)
                {
                    foreach (ServiceEndpointElement endpoint in service.Endpoints)
                    {
                        if (endpoint.Contract.Equals(contractType.FullName))
                        {
                            isSelfHosting = true;
                            break;
                        }
                    }
                }
            }
            return isSelfHosting;
        }

    }
}
