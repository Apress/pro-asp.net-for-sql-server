using System;
using System.Diagnostics;
using System.ServiceModel;
using System.Text;

namespace DotnetUserGroup.DataAccess.WcfProviders.Events
{
    public class EventServiceHost
    {
        private static readonly EventServiceHost _instance = 
            new EventServiceHost();

        private ServiceHost host;

        public EventServiceHost()
        {
        }

        public static EventServiceHost Instance
        {
            get
            {
                return _instance;
            }
        }

        public void StartEventService()
        {
            Trace.WriteLine("Internal Hosting: StartEventService");
            host = new ServiceHost(typeof(EventService));
            host.Open();
        }

        public void StopEventService()
        {
            Trace.WriteLine("Internal Hosting: StopEventService");
            if (host != null)
            {
                host.Close();
                host = null;
            }
        }

    }
}
