using System.Configuration;

namespace DotnetUserGroup.DataAccess.WcfProviders.Events
{
    public class EventServiceSection : ConfigurationSection
    {
        [StringValidator(MinLength = 1)]
        [ConfigurationProperty("eventProvider",
            DefaultValue = "SqlEventProvider", 
            IsRequired = false)]
        public string EventProvider
        {
            get { return (string)base["eventProvider"]; }
            set { base["eventProvider"] = value; }
        }
    }
}
