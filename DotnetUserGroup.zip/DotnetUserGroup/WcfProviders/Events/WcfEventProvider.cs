using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration.Provider;
using System.ComponentModel;
using System.Diagnostics;
using System.ServiceModel;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Events;
using DotnetUserGroup.DataAccess.Locations;

namespace DotnetUserGroup.DataAccess.WcfProviders.Events
{
    public class WcfEventProvider : EventProvider, ILocationConsumer
    {

        #region "  Provider Methods  "

        /// <summary>
        /// SQL Implementation
        /// </summary>
        public override void Initialize(string name,
            NameValueCollection config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            if (String.IsNullOrEmpty(name))
            {
                name = "WcfEventProvider";
            }

            if (String.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "WCF Events Provider");
            }

            base.Initialize(name, config);

            if (config.Count > 0)
            {
                string attr = config.GetKey(0);
                if (!String.IsNullOrEmpty(attr))
                {
                    throw new ProviderException("Unrecognized attribute: " + attr);
                }
            }
        }

        #endregion

        #region "  Implementation Methods  "

        public override Event GetNewEvent()
        {
            try
            {
                return Proxy.GetNewEvent();
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
                ResetProxy();
                throw;
            }
        }

        public override Event GetEvent(DomainKey key)
        {
            try
            {
                return Proxy.GetEvent(key);
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
                ResetProxy();
                throw;
            }
        }

        public override EventCollection GetAllEvents()
        {
            try
            {
                return Proxy.GetAllEvents();
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
                ResetProxy();
                throw;
            }
        }

        public override EventCollection GetEventsByDate(DateTime targetDate)
        {
            try
            {
                return Proxy.GetEventsByDate(targetDate);
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
                ResetProxy();
                throw;
            }
        }

        public override DomainKey SaveEvent(Event evt)
        {
            if (evt == null) 
            {
                throw new ArgumentNullException("evt", "Event must be defined");
            }

            try
            {
                return Proxy.SaveEvent(evt);
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
                ResetProxy();
                throw;
            }
        }

        public override void DeleteEvent(Event evt)
        {
            if (evt == null) 
            {
                throw new ArgumentNullException("evt", "Event must be defined");
            }

            try
            {
                Proxy.DeleteEvent(evt);
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
                ResetProxy();
                throw;
            }
        }
        
        public override bool IsUsingLocation(Location location)
        {
            if (location == null)
            {
                throw new ArgumentNullException("location");
            }
            try
            {
                return Proxy.IsUsingLocation(location);
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
                ResetProxy();
                throw;
            }
        }

        #endregion

        #region "  Utility Methods and Properties  "

        private IEventService _proxy = null;

        public IEventService Proxy
        {
            get
            {
                if (_proxy == null)
                {
                    _proxy = GetProxy();
                }
                return _proxy;
            }
        }

        public IEventService GetProxy()
        {
            Trace.WriteLine("DataServiceClient: GetProxy");
            ChannelFactory<IEventService> factory = 
                new ChannelFactory<IEventService>(String.Empty);

            IEventService proxy = factory.CreateChannel();
            return proxy;
        }

        public void ResetProxy()
        {
            _proxy = null;
        }

        #endregion

    }
}
