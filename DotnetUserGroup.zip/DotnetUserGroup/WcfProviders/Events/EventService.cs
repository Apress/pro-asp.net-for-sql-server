using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.ServiceModel;
using System.Text;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Events;
using DotnetUserGroup.DataAccess.Locations;
using DotnetUserGroup.DataAccess.Speakers;
using DotnetUserGroup.DataAccess.Sponsors;
using DotnetUserGroup.DataAccess.WcfProviders.Common;

namespace DotnetUserGroup.DataAccess.WcfProviders.Events
{
    
    [ServiceContract(Namespace = "http://dug/events/")]
    [ServiceKnownType(typeof(DomainKey))]
    [ServiceKnownType(typeof(Event))]
    [ServiceKnownType(typeof(Location))]
    [ServiceKnownType(typeof(Speaker))]
    public interface IEventService
    {
        
        [OperationContract]
        Event GetNewEvent();
        
        [OperationContract]
        Event GetEvent(DomainKey key);
        
        [OperationContract]
        EventCollection GetAllEvents();
        
        [OperationContract]
        EventCollection GetEventsByDate(DateTime targetDate);
        
        [OperationContract]
        DomainKey SaveEvent(Event evt);
        
        [OperationContract]
        void DeleteEvent(Event evt);
        
        [OperationContract]
        bool IsUsingLocation(Location location);

    }

    public class EventService : IEventService
    {

        public Event GetNewEvent()
        {
            Trace.WriteLine("GetNewEvent");
            EventProvider provider = EventManager.GetProvider(ProviderName);
            return provider.GetNewEvent();
        }
        
        public Event GetEvent(DomainKey key)
        {
            Trace.WriteLine("GetEvent");
            EventProvider provider = EventManager.GetProvider(ProviderName);
            return provider.GetEvent(key);
        }
        
        public EventCollection GetAllEvents()
        {
            Trace.WriteLine("GetAllEvents");
            EventProvider provider = EventManager.GetProvider(ProviderName);
            return provider.GetAllEvents();
        }
        
        public EventCollection GetEventsByDate(DateTime targetDate)
        {
            Trace.WriteLine("GetEventsByDate");
            EventProvider provider = EventManager.GetProvider(ProviderName);
            return provider.GetEventsByDate(targetDate);
        }
        
        public DomainKey SaveEvent(Event evt)
        {
            Trace.WriteLine("SaveEvent");
            EventProvider provider = EventManager.GetProvider(ProviderName);
            DomainKey key = provider.SaveEvent(evt);
            Event evtSaved = provider.GetEvent(key);
            evt.ID = key;
            evt.Created = evtSaved.Created;            
            evt.Modified = evtSaved.Modified;
            return key;
        }
        
        public void DeleteEvent(Event evt)
        {
            Trace.WriteLine("DeleteEvent");
            EventProvider provider = EventManager.GetProvider(ProviderName);
            provider.DeleteEvent(evt);
        }
        
        public bool IsUsingLocation(Location location)
        {
            Trace.WriteLine("IsUsingLocation");
            EventProvider provider = EventManager.GetProvider(ProviderName);
            return provider.IsUsingLocation(location);
        }

        private string _providerName = String.Empty;

        public string ProviderName
        {
            get
            {
                if (String.IsNullOrEmpty(_providerName))
                {
                    DugServiceConfiguration sectionGroup =
                        DugServiceConfiguration.GetConfiguration();
                    EventServiceSection section = sectionGroup.EventServiceSection;
                    _providerName = section.EventProvider;
                }
                return _providerName; 
            }
        }

    }
}
