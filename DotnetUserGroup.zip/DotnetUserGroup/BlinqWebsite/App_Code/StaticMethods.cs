using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.DLinq;
using System.Query;
using System.Web.Configuration;
using Microsoft.Web.Blinq.Utils;

namespace DotnetUserGroup.BlinqDAL {

  public partial class DotnetUserGroup : DataContext {
    public static DotnetUserGroup CreateDataContext() {
      ConnectionUtil connectionUtil = new ConnectionUtil();
      ConnectionStringSettings connectionStringSettings = WebConfigurationManager.ConnectionStrings["DotnetUserGroupConnectionString"];
      return new DotnetUserGroup(connectionUtil.CreateConnection(connectionStringSettings));
    }
  }

  public partial class AspnetPersonalizationAllUser {
    // This method retrieves all AspnetPersonalizationAllUsers.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetPersonalizationAllUser> GetAllAspnetPersonalizationAllUsers() {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetPersonalizationAllUsers;
    }
    // This method gets record counts of all AspnetPersonalizationAllUsers.
    // Do not change this method.
    public static int GetAllAspnetPersonalizationAllUsersCount() {
      return GetAllAspnetPersonalizationAllUsers().Count();
    }
    // This method retrieves a single AspnetPersonalizationAllUser.
    // Change this method to alter how that record is received.
    public static AspnetPersonalizationAllUser GetAspnetPersonalizationAllUser(Guid PathId) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetPersonalizationAllUsers.Where(x=>x.PathId == PathId).FirstOrDefault();
    }
    // This method pages and sorts over all AspnetPersonalizationAllUsers.
    // Do not change this method.
    public static IQueryable<AspnetPersonalizationAllUser> GetAllAspnetPersonalizationAllUsers(string sortExpression, int startRowIndex, int maximumRows) {
      return GetAllAspnetPersonalizationAllUsers().SortAndPage(sortExpression, startRowIndex, maximumRows, "PathId");
    }
    // This method deletes a record in the table.
    // Change this method to alter how records are deleted.
    public static int Delete(AspnetPersonalizationAllUser x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetPersonalizationAllUsers.Remove(x);
      db.SubmitChanges();
      return 1;
    }
    // This method inserts a new record in the table.
    // Change this method to alter how records are inserted.
    public static int Insert(AspnetPersonalizationAllUser x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetPersonalizationAllUsers.Add(x);
      db.SubmitChanges();
      return 1;
    }
    // This method updates a record in the table.
    // Change this method to alter how records are updated.
    public static int Update(AspnetPersonalizationAllUser original_x, AspnetPersonalizationAllUser x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetPersonalizationAllUsers.Attach(original_x);
      original_x.LastUpdatedDate = x.LastUpdatedDate;
      db.SubmitChanges();
      return 1;
    }
  }

  public partial class AspnetPersonalizationPerUser {
    // This method retrieves all AspnetPersonalizationPerUsers.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetPersonalizationPerUser> GetAllAspnetPersonalizationPerUsers() {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetPersonalizationPerUsers;
    }
    // This method gets record counts of all AspnetPersonalizationPerUsers.
    // Do not change this method.
    public static int GetAllAspnetPersonalizationPerUsersCount() {
      return GetAllAspnetPersonalizationPerUsers().Count();
    }
    // This method retrieves a single AspnetPersonalizationPerUser.
    // Change this method to alter how that record is received.
    public static AspnetPersonalizationPerUser GetAspnetPersonalizationPerUser(Guid Id) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetPersonalizationPerUsers.Where(x=>x.Id == Id).FirstOrDefault();
    }
    // This method retrieves AspnetPersonalizationPerUsers by AspnetUser.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetPersonalizationPerUser> GetAspnetPersonalizationPerUsersByAspnetUser(Guid UserId) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetUsers.Where(x=>x.UserId == UserId).SelectMany(x=>x.AspnetPersonalizationPerUsers);
    }
    // This method retrieves AspnetPersonalizationPerUsers by AspnetPath.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetPersonalizationPerUser> GetAspnetPersonalizationPerUsersByAspnetPath(Guid PathId) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetPaths.Where(x=>x.PathId == PathId).SelectMany(x=>x.AspnetPersonalizationPerUsers);
    }
    // This method gets sorted and paged records of all AspnetPersonalizationPerUsers filtered by a specified field.
    // Do not change this method.
    public static IQueryable<AspnetPersonalizationPerUser> GetAspnetPersonalizationPerUsers(string tableName, Guid AspnetPersonalizationPerUsers_UserId, Guid AspnetPersonalizationPerUsers_PathId, string sortExpression, int startRowIndex, int maximumRows) {
      IQueryable<AspnetPersonalizationPerUser> x = GetFilteredAspnetPersonalizationPerUsers(tableName, AspnetPersonalizationPerUsers_UserId, AspnetPersonalizationPerUsers_PathId);
      return x.SortAndPage(sortExpression, startRowIndex, maximumRows, "Id");
    }
    // This method routes a request for filtering by a field value to another method.
    // Do not change this method.
    private static IQueryable<AspnetPersonalizationPerUser> GetFilteredAspnetPersonalizationPerUsers(string tableName, Guid AspnetPersonalizationPerUsers_UserId, Guid AspnetPersonalizationPerUsers_PathId) {
      switch (tableName) {
        case "AspnetUser_AspnetPersonalizationPerUsers":
          return GetAspnetPersonalizationPerUsersByAspnetUser(AspnetPersonalizationPerUsers_UserId);
        case "AspnetPath_AspnetPersonalizationPerUsers":
          return GetAspnetPersonalizationPerUsersByAspnetPath(AspnetPersonalizationPerUsers_PathId);
        default:
          return GetAllAspnetPersonalizationPerUsers();
      }
    }
    // This method gets records counts of all AspnetPersonalizationPerUsers filtered by a specified field.
    // Do not change this method.
    public static int GetAspnetPersonalizationPerUsersCount(string tableName, Guid AspnetPersonalizationPerUsers_UserId, Guid AspnetPersonalizationPerUsers_PathId) {
      IQueryable<AspnetPersonalizationPerUser> x = GetFilteredAspnetPersonalizationPerUsers(tableName, AspnetPersonalizationPerUsers_UserId, AspnetPersonalizationPerUsers_PathId);
      return x.Count();
    }
    // This method deletes a record in the table.
    // Change this method to alter how records are deleted.
    public static int Delete(AspnetPersonalizationPerUser x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetPersonalizationPerUsers.Remove(x);
      db.SubmitChanges();
      return 1;
    }
    // This method inserts a new record in the table.
    // Change this method to alter how records are inserted.
    public static int Insert(AspnetPersonalizationPerUser x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetPersonalizationPerUsers.Add(x);
      db.SubmitChanges();
      return 1;
    }
    // This method updates a record in the table.
    // Change this method to alter how records are updated.
    public static int Update(AspnetPersonalizationPerUser original_x, AspnetPersonalizationPerUser x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetPersonalizationPerUsers.Attach(original_x);
      original_x.PathId = x.PathId;
      original_x.UserId = x.UserId;
      original_x.LastUpdatedDate = x.LastUpdatedDate;
      db.SubmitChanges();
      return 1;
    }
  }

  public partial class AspnetWebEventEvent {
    // This method retrieves all AspnetWebEventEvents.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetWebEventEvent> GetAllAspnetWebEventEvents() {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetWebEventEvents;
    }
    // This method gets record counts of all AspnetWebEventEvents.
    // Do not change this method.
    public static int GetAllAspnetWebEventEventsCount() {
      return GetAllAspnetWebEventEvents().Count();
    }
    // This method retrieves a single AspnetWebEventEvent.
    // Change this method to alter how that record is received.
    public static AspnetWebEventEvent GetAspnetWebEventEvent(String EventId) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetWebEventEvents.Where(x=>x.EventId == EventId).FirstOrDefault();
    }
    // This method pages and sorts over all AspnetWebEventEvents.
    // Do not change this method.
    public static IQueryable<AspnetWebEventEvent> GetAllAspnetWebEventEvents(string sortExpression, int startRowIndex, int maximumRows) {
      return GetAllAspnetWebEventEvents().SortAndPage(sortExpression, startRowIndex, maximumRows, "EventId");
    }
    // This method deletes a record in the table.
    // Change this method to alter how records are deleted.
    public static int Delete(AspnetWebEventEvent x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetWebEventEvents.Remove(x);
      db.SubmitChanges();
      return 1;
    }
    // This method inserts a new record in the table.
    // Change this method to alter how records are inserted.
    public static int Insert(AspnetWebEventEvent x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetWebEventEvents.Add(x);
      db.SubmitChanges();
      return 1;
    }
    // This method updates a record in the table.
    // Change this method to alter how records are updated.
    public static int Update(AspnetWebEventEvent original_x, AspnetWebEventEvent x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetWebEventEvents.Attach(original_x);
      original_x.EventTimeUtc = x.EventTimeUtc;
      original_x.EventTime = x.EventTime;
      original_x.EventType = x.EventType;
      original_x.EventSequence = x.EventSequence;
      original_x.EventOccurrence = x.EventOccurrence;
      original_x.EventCode = x.EventCode;
      original_x.EventDetailCode = x.EventDetailCode;
      original_x.Message = x.Message;
      original_x.ApplicationPath = x.ApplicationPath;
      original_x.ApplicationVirtualPath = x.ApplicationVirtualPath;
      original_x.MachineName = x.MachineName;
      original_x.RequestUrl = x.RequestUrl;
      original_x.ExceptionType = x.ExceptionType;
      original_x.Details = x.Details;
      db.SubmitChanges();
      return 1;
    }
  }

  public partial class DugEvent {
    // This method retrieves all DugEvents.
    // Change this method to alter how records are retrieved.
    public static IQueryable<DugEvent> GetAllDugEvents() {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.DugEvents;
    }
    // This method gets record counts of all DugEvents.
    // Do not change this method.
    public static int GetAllDugEventsCount() {
      return GetAllDugEvents().Count();
    }
    // This method retrieves a single DugEvent.
    // Change this method to alter how that record is received.
    public static DugEvent GetDugEvent(Int64 ID) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.DugEvents.Where(x=>x.ID == ID).FirstOrDefault();
    }
    // This method pages and sorts over all DugEvents.
    // Do not change this method.
    public static IQueryable<DugEvent> GetAllDugEvents(string sortExpression, int startRowIndex, int maximumRows) {
      return GetAllDugEvents().SortAndPage(sortExpression, startRowIndex, maximumRows, "ID");
    }
    // This method deletes a record in the table.
    // Change this method to alter how records are deleted.
    public static int Delete(DugEvent x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugEvents.Remove(x);
      db.SubmitChanges();
      return 1;
    }
    // This method inserts a new record in the table.
    // Change this method to alter how records are inserted.
    public static int Insert(DugEvent x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugEvents.Add(x);
      db.SubmitChanges();
      return 1;
    }
    // This method updates a record in the table.
    // Change this method to alter how records are updated.
    public static int Update(DugEvent original_x, DugEvent x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugEvents.Attach(original_x);
      original_x.Title = x.Title;
      original_x.Description = x.Description;
      original_x.MeetingDate = x.MeetingDate;
      original_x.SpeakerID = x.SpeakerID;
      original_x.SponsorID = x.SponsorID;
      original_x.LocationID = x.LocationID;
      original_x.Created = x.Created;
      original_x.Modified = x.Modified;
      db.SubmitChanges();
      return 1;
    }
  }

  public partial class DugSponsor {
    // This method retrieves all DugSponsors.
    // Change this method to alter how records are retrieved.
    public static IQueryable<DugSponsor> GetAllDugSponsors() {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.DugSponsors;
    }
    // This method gets record counts of all DugSponsors.
    // Do not change this method.
    public static int GetAllDugSponsorsCount() {
      return GetAllDugSponsors().Count();
    }
    // This method retrieves a single DugSponsor.
    // Change this method to alter how that record is received.
    public static DugSponsor GetDugSponsor(Int64 ID) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.DugSponsors.Where(x=>x.ID == ID).FirstOrDefault();
    }
    // This method pages and sorts over all DugSponsors.
    // Do not change this method.
    public static IQueryable<DugSponsor> GetAllDugSponsors(string sortExpression, int startRowIndex, int maximumRows) {
      return GetAllDugSponsors().SortAndPage(sortExpression, startRowIndex, maximumRows, "ID");
    }
    // This method deletes a record in the table.
    // Change this method to alter how records are deleted.
    public static int Delete(DugSponsor x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugSponsors.Remove(x);
      db.SubmitChanges();
      return 1;
    }
    // This method inserts a new record in the table.
    // Change this method to alter how records are inserted.
    public static int Insert(DugSponsor x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugSponsors.Add(x);
      db.SubmitChanges();
      return 1;
    }
    // This method updates a record in the table.
    // Change this method to alter how records are updated.
    public static int Update(DugSponsor original_x, DugSponsor x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugSponsors.Attach(original_x);
      original_x.LocationID = x.LocationID;
      original_x.Name = x.Name;
      original_x.Description = x.Description;
      original_x.WebsiteUrl = x.WebsiteUrl;
      original_x.LogoUrl = x.LogoUrl;
      original_x.LogoWidth = x.LogoWidth;
      original_x.LogoHeight = x.LogoHeight;
      original_x.Created = x.Created;
      original_x.Modified = x.Modified;
      db.SubmitChanges();
      return 1;
    }
  }

  public partial class DugJobContact {
    // This method retrieves all DugJobContacts.
    // Change this method to alter how records are retrieved.
    public static IQueryable<DugJobContact> GetAllDugJobContacts() {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.DugJobContacts;
    }
    // This method gets record counts of all DugJobContacts.
    // Do not change this method.
    public static int GetAllDugJobContactsCount() {
      return GetAllDugJobContacts().Count();
    }
    // This method retrieves a single DugJobContact.
    // Change this method to alter how that record is received.
    public static DugJobContact GetDugJobContact(Int64 ID) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.DugJobContacts.Where(x=>x.ID == ID).FirstOrDefault();
    }
    // This method pages and sorts over all DugJobContacts.
    // Do not change this method.
    public static IQueryable<DugJobContact> GetAllDugJobContacts(string sortExpression, int startRowIndex, int maximumRows) {
      return GetAllDugJobContacts().SortAndPage(sortExpression, startRowIndex, maximumRows, "ID");
    }
    // This method deletes a record in the table.
    // Change this method to alter how records are deleted.
    public static int Delete(DugJobContact x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugJobContacts.Remove(x);
      db.SubmitChanges();
      return 1;
    }
    // This method inserts a new record in the table.
    // Change this method to alter how records are inserted.
    public static int Insert(DugJobContact x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugJobContacts.Add(x);
      db.SubmitChanges();
      return 1;
    }
    // This method updates a record in the table.
    // Change this method to alter how records are updated.
    public static int Update(DugJobContact original_x, DugJobContact x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugJobContacts.Attach(original_x);
      original_x.LocationID = x.LocationID;
      original_x.Name = x.Name;
      original_x.Phone = x.Phone;
      original_x.Email = x.Email;
      original_x.WebsiteUrl = x.WebsiteUrl;
      original_x.Created = x.Created;
      original_x.Modified = x.Modified;
      db.SubmitChanges();
      return 1;
    }
  }

  public partial class DugJob {
    // This method retrieves all DugJobs.
    // Change this method to alter how records are retrieved.
    public static IQueryable<DugJob> GetAllDugJobs() {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.DugJobs;
    }
    // This method gets record counts of all DugJobs.
    // Do not change this method.
    public static int GetAllDugJobsCount() {
      return GetAllDugJobs().Count();
    }
    // This method retrieves a single DugJob.
    // Change this method to alter how that record is received.
    public static DugJob GetDugJob(Int64 ID) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.DugJobs.Where(x=>x.ID == ID).FirstOrDefault();
    }
    // This method pages and sorts over all DugJobs.
    // Do not change this method.
    public static IQueryable<DugJob> GetAllDugJobs(string sortExpression, int startRowIndex, int maximumRows) {
      return GetAllDugJobs().SortAndPage(sortExpression, startRowIndex, maximumRows, "ID");
    }
    // This method deletes a record in the table.
    // Change this method to alter how records are deleted.
    public static int Delete(DugJob x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugJobs.Remove(x);
      db.SubmitChanges();
      return 1;
    }
    // This method inserts a new record in the table.
    // Change this method to alter how records are inserted.
    public static int Insert(DugJob x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugJobs.Add(x);
      db.SubmitChanges();
      return 1;
    }
    // This method updates a record in the table.
    // Change this method to alter how records are updated.
    public static int Update(DugJob original_x, DugJob x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugJobs.Attach(original_x);
      original_x.LocationID = x.LocationID;
      original_x.JobContactID = x.JobContactID;
      original_x.Title = x.Title;
      original_x.Description = x.Description;
      original_x.Skills = x.Skills;
      original_x.MinExp = x.MinExp;
      original_x.MaxExp = x.MaxExp;
      original_x.CompanyName = x.CompanyName;
      original_x.WebsiteUrl = x.WebsiteUrl;
      original_x.EffectiveStartDate = x.EffectiveStartDate;
      original_x.EffectiveEndDate = x.EffectiveEndDate;
      original_x.Created = x.Created;
      original_x.Modified = x.Modified;
      db.SubmitChanges();
      return 1;
    }
  }

  public partial class DugLocation {
    // This method retrieves all DugLocations.
    // Change this method to alter how records are retrieved.
    public static IQueryable<DugLocation> GetAllDugLocations() {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.DugLocations;
    }
    // This method gets record counts of all DugLocations.
    // Do not change this method.
    public static int GetAllDugLocationsCount() {
      return GetAllDugLocations().Count();
    }
    // This method retrieves a single DugLocation.
    // Change this method to alter how that record is received.
    public static DugLocation GetDugLocation(Int64 ID) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.DugLocations.Where(x=>x.ID == ID).FirstOrDefault();
    }
    // This method pages and sorts over all DugLocations.
    // Do not change this method.
    public static IQueryable<DugLocation> GetAllDugLocations(string sortExpression, int startRowIndex, int maximumRows) {
      return GetAllDugLocations().SortAndPage(sortExpression, startRowIndex, maximumRows, "ID");
    }
    // This method deletes a record in the table.
    // Change this method to alter how records are deleted.
    public static int Delete(DugLocation x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugLocations.Remove(x);
      db.SubmitChanges();
      return 1;
    }
    // This method inserts a new record in the table.
    // Change this method to alter how records are inserted.
    public static int Insert(DugLocation x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugLocations.Add(x);
      db.SubmitChanges();
      return 1;
    }
    // This method updates a record in the table.
    // Change this method to alter how records are updated.
    public static int Update(DugLocation original_x, DugLocation x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugLocations.Attach(original_x);
      original_x.Title = x.Title;
      original_x.Address1 = x.Address1;
      original_x.Address2 = x.Address2;
      original_x.City = x.City;
      original_x.State = x.State;
      original_x.Zip = x.Zip;
      original_x.Created = x.Created;
      original_x.Modified = x.Modified;
      db.SubmitChanges();
      return 1;
    }
  }

  public partial class DugSpeaker {
    // This method retrieves all DugSpeakers.
    // Change this method to alter how records are retrieved.
    public static IQueryable<DugSpeaker> GetAllDugSpeakers() {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.DugSpeakers;
    }
    // This method gets record counts of all DugSpeakers.
    // Do not change this method.
    public static int GetAllDugSpeakersCount() {
      return GetAllDugSpeakers().Count();
    }
    // This method retrieves a single DugSpeaker.
    // Change this method to alter how that record is received.
    public static DugSpeaker GetDugSpeaker(Int64 ID) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.DugSpeakers.Where(x=>x.ID == ID).FirstOrDefault();
    }
    // This method pages and sorts over all DugSpeakers.
    // Do not change this method.
    public static IQueryable<DugSpeaker> GetAllDugSpeakers(string sortExpression, int startRowIndex, int maximumRows) {
      return GetAllDugSpeakers().SortAndPage(sortExpression, startRowIndex, maximumRows, "ID");
    }
    // This method deletes a record in the table.
    // Change this method to alter how records are deleted.
    public static int Delete(DugSpeaker x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugSpeakers.Remove(x);
      db.SubmitChanges();
      return 1;
    }
    // This method inserts a new record in the table.
    // Change this method to alter how records are inserted.
    public static int Insert(DugSpeaker x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugSpeakers.Add(x);
      db.SubmitChanges();
      return 1;
    }
    // This method updates a record in the table.
    // Change this method to alter how records are updated.
    public static int Update(DugSpeaker original_x, DugSpeaker x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.DugSpeakers.Attach(original_x);
      original_x.FirstName = x.FirstName;
      original_x.MiddleInitial = x.MiddleInitial;
      original_x.LastName = x.LastName;
      original_x.Description = x.Description;
      original_x.WebsiteUrl = x.WebsiteUrl;
      original_x.Email = x.Email;
      original_x.Phone = x.Phone;
      original_x.Created = x.Created;
      original_x.Modified = x.Modified;
      db.SubmitChanges();
      return 1;
    }
  }

  public partial class AspnetApplication {
    // This method retrieves all AspnetApplications.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetApplication> GetAllAspnetApplications() {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetApplications;
    }
    // This method gets record counts of all AspnetApplications.
    // Do not change this method.
    public static int GetAllAspnetApplicationsCount() {
      return GetAllAspnetApplications().Count();
    }
    // This method retrieves a single AspnetApplication.
    // Change this method to alter how that record is received.
    public static AspnetApplication GetAspnetApplication(Guid ApplicationId) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetApplications.Where(x=>x.ApplicationId == ApplicationId).FirstOrDefault();
    }
    // This method pages and sorts over all AspnetApplications.
    // Do not change this method.
    public static IQueryable<AspnetApplication> GetAllAspnetApplications(string sortExpression, int startRowIndex, int maximumRows) {
      return GetAllAspnetApplications().SortAndPage(sortExpression, startRowIndex, maximumRows, "ApplicationId");
    }
    // This method deletes a record in the table.
    // Change this method to alter how records are deleted.
    public static int Delete(AspnetApplication x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetApplications.Remove(x);
      db.SubmitChanges();
      return 1;
    }
    // This method inserts a new record in the table.
    // Change this method to alter how records are inserted.
    public static int Insert(AspnetApplication x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetApplications.Add(x);
      db.SubmitChanges();
      return 1;
    }
    // This method updates a record in the table.
    // Change this method to alter how records are updated.
    public static int Update(AspnetApplication original_x, AspnetApplication x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetApplications.Attach(original_x);
      original_x.ApplicationName = x.ApplicationName;
      original_x.LoweredApplicationName = x.LoweredApplicationName;
      original_x.Description = x.Description;
      db.SubmitChanges();
      return 1;
    }
  }

  public partial class AspnetUser {
    // This method retrieves all AspnetUsers.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetUser> GetAllAspnetUsers() {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetUsers;
    }
    // This method gets record counts of all AspnetUsers.
    // Do not change this method.
    public static int GetAllAspnetUsersCount() {
      return GetAllAspnetUsers().Count();
    }
    // This method retrieves a single AspnetUser.
    // Change this method to alter how that record is received.
    public static AspnetUser GetAspnetUser(Guid UserId) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetUsers.Where(x=>x.UserId == UserId).FirstOrDefault();
    }
    // This method retrieves AspnetUsers by AspnetApplication.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetUser> GetAspnetUsersByAspnetApplication(Guid ApplicationId) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetApplications.Where(x=>x.ApplicationId == ApplicationId).SelectMany(x=>x.AspnetUsers);
    }
    // This method gets sorted and paged records of all AspnetUsers filtered by a specified field.
    // Do not change this method.
    public static IQueryable<AspnetUser> GetAspnetUsers(string tableName, Guid AspnetUsers_ApplicationId, string sortExpression, int startRowIndex, int maximumRows) {
      IQueryable<AspnetUser> x = GetFilteredAspnetUsers(tableName, AspnetUsers_ApplicationId);
      return x.SortAndPage(sortExpression, startRowIndex, maximumRows, "UserId");
    }
    // This method routes a request for filtering by a field value to another method.
    // Do not change this method.
    private static IQueryable<AspnetUser> GetFilteredAspnetUsers(string tableName, Guid AspnetUsers_ApplicationId) {
      switch (tableName) {
        case "AspnetApplication_AspnetUsers":
          return GetAspnetUsersByAspnetApplication(AspnetUsers_ApplicationId);
        default:
          return GetAllAspnetUsers();
      }
    }
    // This method gets records counts of all AspnetUsers filtered by a specified field.
    // Do not change this method.
    public static int GetAspnetUsersCount(string tableName, Guid AspnetUsers_ApplicationId) {
      IQueryable<AspnetUser> x = GetFilteredAspnetUsers(tableName, AspnetUsers_ApplicationId);
      return x.Count();
    }
    // This method deletes a record in the table.
    // Change this method to alter how records are deleted.
    public static int Delete(AspnetUser x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetUsers.Remove(x);
      db.SubmitChanges();
      return 1;
    }
    // This method inserts a new record in the table.
    // Change this method to alter how records are inserted.
    public static int Insert(AspnetUser x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetUsers.Add(x);
      db.SubmitChanges();
      return 1;
    }
    // This method updates a record in the table.
    // Change this method to alter how records are updated.
    public static int Update(AspnetUser original_x, AspnetUser x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetUsers.Attach(original_x);
      original_x.ApplicationId = x.ApplicationId;
      original_x.UserName = x.UserName;
      original_x.LoweredUserName = x.LoweredUserName;
      original_x.MobileAlias = x.MobileAlias;
      original_x.IsAnonymous = x.IsAnonymous;
      original_x.LastActivityDate = x.LastActivityDate;
      db.SubmitChanges();
      return 1;
    }
  }

  public partial class AspnetSchemaVersion {
    // This method retrieves all AspnetSchemaVersions.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetSchemaVersion> GetAllAspnetSchemaVersions() {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetSchemaVersions;
    }
    // This method gets record counts of all AspnetSchemaVersions.
    // Do not change this method.
    public static int GetAllAspnetSchemaVersionsCount() {
      return GetAllAspnetSchemaVersions().Count();
    }
    // This method retrieves a single AspnetSchemaVersion.
    // Change this method to alter how that record is received.
    public static AspnetSchemaVersion GetAspnetSchemaVersion(String Feature, String CompatibleSchemaVersion) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetSchemaVersions.Where(x=>x.Feature == Feature && x.CompatibleSchemaVersion == CompatibleSchemaVersion).FirstOrDefault();
    }
    // This method pages and sorts over all AspnetSchemaVersions.
    // Do not change this method.
    public static IQueryable<AspnetSchemaVersion> GetAllAspnetSchemaVersions(string sortExpression, int startRowIndex, int maximumRows) {
      return GetAllAspnetSchemaVersions().SortAndPage(sortExpression, startRowIndex, maximumRows, "Feature");
    }
    // This method deletes a record in the table.
    // Change this method to alter how records are deleted.
    public static int Delete(AspnetSchemaVersion x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetSchemaVersions.Remove(x);
      db.SubmitChanges();
      return 1;
    }
    // This method inserts a new record in the table.
    // Change this method to alter how records are inserted.
    public static int Insert(AspnetSchemaVersion x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetSchemaVersions.Add(x);
      db.SubmitChanges();
      return 1;
    }
    // This method updates a record in the table.
    // Change this method to alter how records are updated.
    public static int Update(AspnetSchemaVersion original_x, AspnetSchemaVersion x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetSchemaVersions.Attach(original_x);
      original_x.IsCurrentVersion = x.IsCurrentVersion;
      db.SubmitChanges();
      return 1;
    }
  }

  public partial class AspnetMembership {
    // This method retrieves all AspnetMemberships.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetMembership> GetAllAspnetMemberships() {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetMemberships;
    }
    // This method gets record counts of all AspnetMemberships.
    // Do not change this method.
    public static int GetAllAspnetMembershipsCount() {
      return GetAllAspnetMemberships().Count();
    }
    // This method retrieves a single AspnetMembership.
    // Change this method to alter how that record is received.
    public static AspnetMembership GetAspnetMembership(Guid UserId) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetMemberships.Where(x=>x.UserId == UserId).FirstOrDefault();
    }
    // This method retrieves AspnetMemberships by AspnetApplication.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetMembership> GetAspnetMembershipsByAspnetApplication(Guid ApplicationId) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetApplications.Where(x=>x.ApplicationId == ApplicationId).SelectMany(x=>x.AspnetMemberships);
    }
    // This method gets sorted and paged records of all AspnetMemberships filtered by a specified field.
    // Do not change this method.
    public static IQueryable<AspnetMembership> GetAspnetMemberships(string tableName, Guid AspnetMemberships_ApplicationId, string sortExpression, int startRowIndex, int maximumRows) {
      IQueryable<AspnetMembership> x = GetFilteredAspnetMemberships(tableName, AspnetMemberships_ApplicationId);
      return x.SortAndPage(sortExpression, startRowIndex, maximumRows, "UserId");
    }
    // This method routes a request for filtering by a field value to another method.
    // Do not change this method.
    private static IQueryable<AspnetMembership> GetFilteredAspnetMemberships(string tableName, Guid AspnetMemberships_ApplicationId) {
      switch (tableName) {
        case "AspnetApplication_AspnetMemberships":
          return GetAspnetMembershipsByAspnetApplication(AspnetMemberships_ApplicationId);
        default:
          return GetAllAspnetMemberships();
      }
    }
    // This method gets records counts of all AspnetMemberships filtered by a specified field.
    // Do not change this method.
    public static int GetAspnetMembershipsCount(string tableName, Guid AspnetMemberships_ApplicationId) {
      IQueryable<AspnetMembership> x = GetFilteredAspnetMemberships(tableName, AspnetMemberships_ApplicationId);
      return x.Count();
    }
    // This method deletes a record in the table.
    // Change this method to alter how records are deleted.
    public static int Delete(AspnetMembership x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetMemberships.Remove(x);
      db.SubmitChanges();
      return 1;
    }
    // This method inserts a new record in the table.
    // Change this method to alter how records are inserted.
    public static int Insert(AspnetMembership x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetMemberships.Add(x);
      db.SubmitChanges();
      return 1;
    }
    // This method updates a record in the table.
    // Change this method to alter how records are updated.
    public static int Update(AspnetMembership original_x, AspnetMembership x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetMemberships.Attach(original_x);
      original_x.ApplicationId = x.ApplicationId;
      original_x.Password = x.Password;
      original_x.PasswordFormat = x.PasswordFormat;
      original_x.PasswordSalt = x.PasswordSalt;
      original_x.MobilePIN = x.MobilePIN;
      original_x.Email = x.Email;
      original_x.LoweredEmail = x.LoweredEmail;
      original_x.PasswordQuestion = x.PasswordQuestion;
      original_x.PasswordAnswer = x.PasswordAnswer;
      original_x.IsApproved = x.IsApproved;
      original_x.IsLockedOut = x.IsLockedOut;
      original_x.CreateDate = x.CreateDate;
      original_x.LastLoginDate = x.LastLoginDate;
      original_x.LastPasswordChangedDate = x.LastPasswordChangedDate;
      original_x.LastLockoutDate = x.LastLockoutDate;
      original_x.FailedPasswordAttemptCount = x.FailedPasswordAttemptCount;
      original_x.FailedPasswordAttemptWindowStart = x.FailedPasswordAttemptWindowStart;
      original_x.FailedPasswordAnswerAttemptCount = x.FailedPasswordAnswerAttemptCount;
      original_x.FailedPasswordAnswerAttemptWindowStart = x.FailedPasswordAnswerAttemptWindowStart;
      original_x.Comment = x.Comment;
      db.SubmitChanges();
      return 1;
    }
  }

  public partial class AspnetProfile {
    // This method retrieves all AspnetProfiles.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetProfile> GetAllAspnetProfiles() {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetProfiles;
    }
    // This method gets record counts of all AspnetProfiles.
    // Do not change this method.
    public static int GetAllAspnetProfilesCount() {
      return GetAllAspnetProfiles().Count();
    }
    // This method retrieves a single AspnetProfile.
    // Change this method to alter how that record is received.
    public static AspnetProfile GetAspnetProfile(Guid UserId) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetProfiles.Where(x=>x.UserId == UserId).FirstOrDefault();
    }
    // This method pages and sorts over all AspnetProfiles.
    // Do not change this method.
    public static IQueryable<AspnetProfile> GetAllAspnetProfiles(string sortExpression, int startRowIndex, int maximumRows) {
      return GetAllAspnetProfiles().SortAndPage(sortExpression, startRowIndex, maximumRows, "UserId");
    }
    // This method deletes a record in the table.
    // Change this method to alter how records are deleted.
    public static int Delete(AspnetProfile x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetProfiles.Remove(x);
      db.SubmitChanges();
      return 1;
    }
    // This method inserts a new record in the table.
    // Change this method to alter how records are inserted.
    public static int Insert(AspnetProfile x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetProfiles.Add(x);
      db.SubmitChanges();
      return 1;
    }
    // This method updates a record in the table.
    // Change this method to alter how records are updated.
    public static int Update(AspnetProfile original_x, AspnetProfile x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetProfiles.Attach(original_x);
      original_x.PropertyNames = x.PropertyNames;
      original_x.PropertyValuesString = x.PropertyValuesString;
      original_x.LastUpdatedDate = x.LastUpdatedDate;
      db.SubmitChanges();
      return 1;
    }
  }

  public partial class AspnetRoles {
    // This method retrieves all AspnetRoles.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetRoles> GetAllAspnetRoles() {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetRoles;
    }
    // This method gets record counts of all AspnetRoles.
    // Do not change this method.
    public static int GetAllAspnetRolesCount() {
      return GetAllAspnetRoles().Count();
    }
    // This method retrieves a single AspnetRoles.
    // Change this method to alter how that record is received.
    public static AspnetRoles GetAspnetRoles(Guid RoleId) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetRoles.Where(x=>x.RoleId == RoleId).FirstOrDefault();
    }
    // This method retrieves AspnetRoles by AspnetApplication.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetRoles> GetAspnetRolesByAspnetApplication(Guid ApplicationId) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetApplications.Where(x=>x.ApplicationId == ApplicationId).SelectMany(x=>x.AspnetRoles);
    }
    // This method gets sorted and paged records of all AspnetRoles filtered by a specified field.
    // Do not change this method.
    public static IQueryable<AspnetRoles> GetAspnetRoles(string tableName, Guid AspnetRoles_ApplicationId, string sortExpression, int startRowIndex, int maximumRows) {
      IQueryable<AspnetRoles> x = GetFilteredAspnetRoles(tableName, AspnetRoles_ApplicationId);
      return x.SortAndPage(sortExpression, startRowIndex, maximumRows, "RoleId");
    }
    // This method routes a request for filtering by a field value to another method.
    // Do not change this method.
    private static IQueryable<AspnetRoles> GetFilteredAspnetRoles(string tableName, Guid AspnetRoles_ApplicationId) {
      switch (tableName) {
        case "AspnetApplication_AspnetRoles":
          return GetAspnetRolesByAspnetApplication(AspnetRoles_ApplicationId);
        default:
          return GetAllAspnetRoles();
      }
    }
    // This method gets records counts of all AspnetRoles filtered by a specified field.
    // Do not change this method.
    public static int GetAspnetRolesCount(string tableName, Guid AspnetRoles_ApplicationId) {
      IQueryable<AspnetRoles> x = GetFilteredAspnetRoles(tableName, AspnetRoles_ApplicationId);
      return x.Count();
    }
    // This method deletes a record in the table.
    // Change this method to alter how records are deleted.
    public static int Delete(AspnetRoles x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetRoles.Remove(x);
      db.SubmitChanges();
      return 1;
    }
    // This method inserts a new record in the table.
    // Change this method to alter how records are inserted.
    public static int Insert(AspnetRoles x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetRoles.Add(x);
      db.SubmitChanges();
      return 1;
    }
    // This method updates a record in the table.
    // Change this method to alter how records are updated.
    public static int Update(AspnetRoles original_x, AspnetRoles x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetRoles.Attach(original_x);
      original_x.ApplicationId = x.ApplicationId;
      original_x.RoleName = x.RoleName;
      original_x.LoweredRoleName = x.LoweredRoleName;
      original_x.Description = x.Description;
      db.SubmitChanges();
      return 1;
    }
  }

  public partial class AspnetUsersInRoles {
    // This method retrieves all AspnetUsersInRoles.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetUsersInRoles> GetAllAspnetUsersInRoles() {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetUsersInRoles;
    }
    // This method gets record counts of all AspnetUsersInRoles.
    // Do not change this method.
    public static int GetAllAspnetUsersInRolesCount() {
      return GetAllAspnetUsersInRoles().Count();
    }
    // This method retrieves a single AspnetUsersInRoles.
    // Change this method to alter how that record is received.
    public static AspnetUsersInRoles GetAspnetUsersInRoles(Guid UserId, Guid RoleId) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetUsersInRoles.Where(x=>x.UserId == UserId && x.RoleId == RoleId).FirstOrDefault();
    }
    // This method retrieves AspnetUsersInRoles by AspnetUser.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetUsersInRoles> GetAspnetUsersInRolesByAspnetUser(Guid UserId) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetUsers.Where(x=>x.UserId == UserId).SelectMany(x=>x.AspnetUsersInRoles);
    }
    // This method retrieves AspnetUsersInRoles by AspnetRoles.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetUsersInRoles> GetAspnetUsersInRolesByAspnetRoles(Guid RoleId) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetRoles.Where(x=>x.RoleId == RoleId).SelectMany(x=>x.AspnetUsersInRoles);
    }
    // This method gets sorted and paged records of all AspnetUsersInRoles filtered by a specified field.
    // Do not change this method.
    public static IQueryable<AspnetUsersInRoles> GetAspnetUsersInRoles(string tableName, Guid AspnetUsersInRoles_UserId, Guid AspnetUsersInRoles_RoleId, string sortExpression, int startRowIndex, int maximumRows) {
      IQueryable<AspnetUsersInRoles> x = GetFilteredAspnetUsersInRoles(tableName, AspnetUsersInRoles_UserId, AspnetUsersInRoles_RoleId);
      return x.SortAndPage(sortExpression, startRowIndex, maximumRows, "UserId");
    }
    // This method routes a request for filtering by a field value to another method.
    // Do not change this method.
    private static IQueryable<AspnetUsersInRoles> GetFilteredAspnetUsersInRoles(string tableName, Guid AspnetUsersInRoles_UserId, Guid AspnetUsersInRoles_RoleId) {
      switch (tableName) {
        case "AspnetUser_AspnetUsersInRoles":
          return GetAspnetUsersInRolesByAspnetUser(AspnetUsersInRoles_UserId);
        case "AspnetRoles_AspnetUsersInRoles":
          return GetAspnetUsersInRolesByAspnetRoles(AspnetUsersInRoles_RoleId);
        default:
          return GetAllAspnetUsersInRoles();
      }
    }
    // This method gets records counts of all AspnetUsersInRoles filtered by a specified field.
    // Do not change this method.
    public static int GetAspnetUsersInRolesCount(string tableName, Guid AspnetUsersInRoles_UserId, Guid AspnetUsersInRoles_RoleId) {
      IQueryable<AspnetUsersInRoles> x = GetFilteredAspnetUsersInRoles(tableName, AspnetUsersInRoles_UserId, AspnetUsersInRoles_RoleId);
      return x.Count();
    }
    // This method deletes a record in the table.
    // Change this method to alter how records are deleted.
    public static int Delete(AspnetUsersInRoles x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetUsersInRoles.Remove(x);
      db.SubmitChanges();
      return 1;
    }
    // This method inserts a new record in the table.
    // Change this method to alter how records are inserted.
    public static int Insert(AspnetUsersInRoles x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetUsersInRoles.Add(x);
      db.SubmitChanges();
      return 1;
    }
    // This method updates a record in the table.
    // Change this method to alter how records are updated.
    public static int Update(AspnetUsersInRoles original_x, AspnetUsersInRoles x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetUsersInRoles.Attach(original_x);
      db.SubmitChanges();
      return 1;
    }
  }

  public partial class AspnetPath {
    // This method retrieves all AspnetPaths.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetPath> GetAllAspnetPaths() {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetPaths;
    }
    // This method gets record counts of all AspnetPaths.
    // Do not change this method.
    public static int GetAllAspnetPathsCount() {
      return GetAllAspnetPaths().Count();
    }
    // This method retrieves a single AspnetPath.
    // Change this method to alter how that record is received.
    public static AspnetPath GetAspnetPath(Guid PathId) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetPaths.Where(x=>x.PathId == PathId).FirstOrDefault();
    }
    // This method retrieves AspnetPaths by AspnetApplication.
    // Change this method to alter how records are retrieved.
    public static IQueryable<AspnetPath> GetAspnetPathsByAspnetApplication(Guid ApplicationId) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      return db.AspnetApplications.Where(x=>x.ApplicationId == ApplicationId).SelectMany(x=>x.AspnetPaths);
    }
    // This method gets sorted and paged records of all AspnetPaths filtered by a specified field.
    // Do not change this method.
    public static IQueryable<AspnetPath> GetAspnetPaths(string tableName, Guid AspnetPaths_ApplicationId, string sortExpression, int startRowIndex, int maximumRows) {
      IQueryable<AspnetPath> x = GetFilteredAspnetPaths(tableName, AspnetPaths_ApplicationId);
      return x.SortAndPage(sortExpression, startRowIndex, maximumRows, "PathId");
    }
    // This method routes a request for filtering by a field value to another method.
    // Do not change this method.
    private static IQueryable<AspnetPath> GetFilteredAspnetPaths(string tableName, Guid AspnetPaths_ApplicationId) {
      switch (tableName) {
        case "AspnetApplication_AspnetPaths":
          return GetAspnetPathsByAspnetApplication(AspnetPaths_ApplicationId);
        default:
          return GetAllAspnetPaths();
      }
    }
    // This method gets records counts of all AspnetPaths filtered by a specified field.
    // Do not change this method.
    public static int GetAspnetPathsCount(string tableName, Guid AspnetPaths_ApplicationId) {
      IQueryable<AspnetPath> x = GetFilteredAspnetPaths(tableName, AspnetPaths_ApplicationId);
      return x.Count();
    }
    // This method deletes a record in the table.
    // Change this method to alter how records are deleted.
    public static int Delete(AspnetPath x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetPaths.Remove(x);
      db.SubmitChanges();
      return 1;
    }
    // This method inserts a new record in the table.
    // Change this method to alter how records are inserted.
    public static int Insert(AspnetPath x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetPaths.Add(x);
      db.SubmitChanges();
      return 1;
    }
    // This method updates a record in the table.
    // Change this method to alter how records are updated.
    public static int Update(AspnetPath original_x, AspnetPath x) {
      DotnetUserGroup db = DotnetUserGroup.CreateDataContext();
      db.AspnetPaths.Attach(original_x);
      original_x.ApplicationId = x.ApplicationId;
      original_x.Path = x.Path;
      original_x.LoweredPath = x.LoweredPath;
      db.SubmitChanges();
      return 1;
    }
  }
}
