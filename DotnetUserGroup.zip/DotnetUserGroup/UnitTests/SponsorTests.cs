using System;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Locations;
using DotnetUserGroup.DataAccess.Sponsors;
using NUnit.Framework;

namespace UnitTests
{
    [TestFixture]
    public class SponsorTests : TestBase
    {

        [SetUp]
        public void SetUp()
        {
        }

        [TearDown]
        public void TearDown()
        {
            PurgeDummySponsors();
        }

        [Test]
        public void Test101_GetAllSponsors_Test()
        {
            SponsorProvider provider = SponsorManager.DefaultProvider;
            SponsorCollection sponsors = provider.GetAllSponsors();
            foreach (Sponsor sponsor in sponsors)
            {
                Console.WriteLine(sponsor.Name);
            }
        }
        
        [Test]
        public void Test102_SaveSponsor_Test()
        {
            SponsorProvider provider = SponsorManager.DefaultProvider;
            Sponsor sponsor = provider.GetNewSponsor();
            sponsor.Name = DummySponsorName;
            provider.SaveSponsor(sponsor);
        }
        
        [Test]
        public void Test103_GetSponsor_Test()
        {
            SponsorProvider provider = SponsorManager.DefaultProvider;
            Sponsor sponsor = provider.GetNewSponsor();
            sponsor.Name = DummySponsorName;
            DomainKey key = provider.SaveSponsor(sponsor);
            sponsor = null;
            sponsor = provider.GetSponsor(key);
            Assert.IsNotNull(sponsor);
            Assert.IsTrue(DummySponsorName.Equals(sponsor.Name));
        }
        
        [Test]
        public void Test104_DeleteSponsor_Test()
        {
            SponsorProvider provider = SponsorManager.DefaultProvider;
            Sponsor sponsor = provider.GetNewSponsor();
            sponsor.Name = DummySponsorName;
            provider.SaveSponsor(sponsor);
            provider.DeleteSponsor(sponsor);
            sponsor = provider.GetSponsor(sponsor.ID);
            Assert.IsNull(sponsor);
        }

        [Test]
        public void Test105_IsSponsorUsingLocation_Test()
        {
            SponsorProvider provider = SponsorManager.DefaultProvider;

            // test for false
            Location location = GetNewLocation();
            bool isUsed = provider.IsUsingLocation(location);
            Assert.IsFalse(isUsed);

            // test for true
            Sponsor sponsor = provider.GetNewSponsor();
            sponsor.Name = DummySponsorName;
            sponsor.Location = location;
            provider.SaveSponsor(sponsor);
            isUsed = provider.IsUsingLocation(location);
            Assert.IsTrue(isUsed);
        }

    }
}
