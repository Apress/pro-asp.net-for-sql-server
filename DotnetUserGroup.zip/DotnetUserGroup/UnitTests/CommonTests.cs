using System;
using System.Configuration;
using System.Configuration.Provider;
using System.Reflection;
using System.Web;
using System.Web.Configuration;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Events;
using DotnetUserGroup.DataAccess.JobContacts;
using DotnetUserGroup.DataAccess.Jobs;
using DotnetUserGroup.DataAccess.Locations;
using DotnetUserGroup.DataAccess.Speakers;
using DotnetUserGroup.DataAccess.Sponsors;
using NUnit.Framework;

namespace UnitTests
{
    [TestFixture]
    public class CommonTests : TestBase
    {

        [SetUp]
        public void SetUp()
        {
        }

        [TearDown]
        public void TearDown()
        {
        }

        [Test]
        public void Test101_Configuration_Test()
        {
            Configuration config = 
                ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
             DugConfiguration sectionGroup = 
                (DugConfiguration) config.SectionGroups["dotnetUserGroup"];

            EventSection eventSection = sectionGroup.EventSection;
            Assert.IsNotNull(eventSection);
            Console.WriteLine("DefaultProvider: " + eventSection.DefaultProvider);

            JobContactSection jobContactSection = sectionGroup.JobContactSection;
            Assert.IsNotNull(jobContactSection);
            Console.WriteLine("DefaultProvider: " + jobContactSection.DefaultProvider);
            
            JobSection jobSection = sectionGroup.JobSection;
            Assert.IsNotNull(jobSection);
            Console.WriteLine("DefaultProvider: " + jobSection.DefaultProvider);

            LocationSection locationSection = sectionGroup.LocationSection;
            Assert.IsNotNull(locationSection);
            Console.WriteLine("DefaultProvider: " + locationSection.DefaultProvider);

            SpeakerSection speakerSection = sectionGroup.SpeakerSection;
            Assert.IsNotNull(speakerSection);
            Console.WriteLine("DefaultProvider: " + speakerSection.DefaultProvider);

            SponsorSection sponsorSection = sectionGroup.SponsorSection;
            Assert.IsNotNull(sponsorSection);
            Console.WriteLine("DefaultProvider: " + sponsorSection.DefaultProvider);
        }

        [Test]
        public void Test102_Configuration_Test()
        {
             DugConfiguration sectionGroup = 
                DugConfiguration.GetConfiguration();

            foreach (ProviderConfigurationSection section in sectionGroup.ProviderSections)
            {
                Console.WriteLine("Default Provider: " + section.DefaultProvider);
                foreach (ProviderSettings settings in section.Providers)
                {
                    Console.WriteLine("# " + settings.Name + ": " + settings.Type);
                    Type type = Type.GetType(settings.Type, false);
                    Assert.IsNotNull(type);
                    Console.WriteLine("Found Type: " + type.FullName);
                }
            }
        }

        [Test]
        public void Test103_ShowMatchedAssemblies_Test()
        {
            ProviderBase[] providers = AssemblyHelper.GetMatchedProviders(typeof(ILocationConsumer));
            Assert.IsTrue(providers.Length > 0);
            foreach (ProviderBase provider in providers)
            {
                Console.WriteLine(provider.Name + " implements ILocationConsumer");
            }
        }

    }
}
