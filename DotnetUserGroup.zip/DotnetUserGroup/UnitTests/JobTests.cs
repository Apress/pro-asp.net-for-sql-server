using System;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Locations;
using DotnetUserGroup.DataAccess.JobContacts;
using DotnetUserGroup.DataAccess.Jobs;
using NUnit.Framework;

namespace UnitTests
{
    [TestFixture]
    public class JobTests : TestBase
    {

        [SetUp]
        public void SetUp()
        {
        }

        [TearDown]
        public void TearDown()
        {
            PurgeDummyJobs();
        }

        [Test]
        public void Test101_GetAllJobs_Test()
        {
            JobProvider provider = JobManager.DefaultProvider;
            JobCollection jobs = provider.GetAllJobs();
            foreach (Job job in jobs)
            {
                Console.WriteLine(job.Title);
            }
        }
        
        [Test]
        public void Test102_SaveJob_Test()
        {
            JobProvider provider = JobManager.DefaultProvider;
            Job job = provider.GetNewJob();
            job.Title = DummyJobTitle;
            provider.SaveJob(job);
        }
        
        [Test]
        public void Test103_GetJob_Test()
        {
            JobProvider provider = JobManager.DefaultProvider;
            Job job = provider.GetNewJob();
            job.Title = DummyJobTitle;
            DomainKey key = provider.SaveJob(job);
            job = null;
            job = provider.GetJob(key);
            Assert.IsNotNull(job);
            Assert.IsTrue(DummyJobTitle.Equals(job.Title));
        }
        
        [Test]
        public void Test104_DeleteJob_Test()
        {
            JobProvider provider = JobManager.DefaultProvider;
            Job job = provider.GetNewJob();
            job.Title = DummyJobTitle;
            provider.SaveJob(job);
            provider.DeleteJob(job);
            job = provider.GetJob(job.ID);
            Assert.IsNull(job);
        }

        [Test]
        public void Test105_IsJobUsingLocation_Test()
        {
            JobProvider provider = JobManager.DefaultProvider;

            // test for false
            Location location = GetNewLocation();
            bool isUsed = provider.IsUsingLocation(location);
            Assert.IsFalse(isUsed);

            // test for true
            Job job = provider.GetNewJob();
            job.Title = DummyJobTitle;
            job.Location = location;
            provider.SaveJob(job);
            isUsed = provider.IsUsingLocation(location);
            Assert.IsTrue(isUsed);
        }

    }
}
