using System;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Events;
using DotnetUserGroup.DataAccess.Jobs;
using DotnetUserGroup.DataAccess.JobContacts;
using DotnetUserGroup.DataAccess.Locations;
using DotnetUserGroup.DataAccess.Members;
using DotnetUserGroup.DataAccess.Speakers;
using DotnetUserGroup.DataAccess.Sponsors;

namespace UnitTests
{
    public class TestBase
    {
        #region "  Dummy Variables  "

        public const string DummyAddress1 = "123 Dummy Road";
        public const string DummyEventTitle = "Dummy Event";        
        public const string DummyJobTitle = "Dummy Job";
        public const string DummyJobContactName = "Dummy Name";
        public const string DummyLocationTitle = "Dummy Location";        
        public const string DummySpeakerFirstName = "Joe";
        public const string DummySpeakerLastName = "Speaker";        
        public const string DummySponsorName = "ACME Consulting";
        public readonly Guid DummyUserId = Guid.NewGuid();        

        #endregion

        #region "  Purge Methods  "
        
        protected void PurgeDummyEvents()
        {
            EventProvider provider = EventManager.DefaultProvider;
            EventCollection events = provider.GetAllEvents();
            foreach (Event evt in events)
            {
                if (DummyEventTitle.Equals(evt.Title))
                {
                    Location location = evt.Location;
                    provider.DeleteEvent(evt);
                    DeleteLocation(location);
                }
            }
        }
        
        protected void PurgeDummyJobs()
        {
            JobProvider provider = JobManager.DefaultProvider;
            JobCollection jobs = provider.GetAllJobs();
            foreach (Job job in jobs)
            {
                if (DummyJobTitle.Equals(job.Title))
                {
                    Location location = job.Location;
                    provider.DeleteJob(job);
                    if (location != null)
                    {
                        DeleteLocation(location);
                    }
                }
            }
        }

        protected void PurgeDummyJobContacts()
        {
            JobContactProvider provider = JobContactManager.DefaultProvider;
            JobContactCollection jobContacts = provider.GetAllJobContacts();
            foreach (JobContact jobContact in jobContacts)
            {
                if (DummyJobContactName.Equals(jobContact.Name))
                {
                    Location location = jobContact.Location;
                    provider.DeleteJobContact(jobContact);
                    if (location != null)
                    {
                        DeleteLocation(location);
                    }
                }
            }
        }

        protected void PurgeDummyLocations()
        {
            LocationProvider provider = LocationManager.DefaultProvider;
            LocationCollection locations = provider.GetAllLocations();
            foreach (Location location in locations)
            {
                if (DummyAddress1.Equals(location.Address1))
                {
                    provider.DeleteLocation(location);
                }
            }
        }

        protected void PurgeDummyMembers()
        {
            MemberProvider provider = MemberManager.DefaultProvider;
            MemberCollection members = provider.GetAllMembers();
            foreach (Member member in members)
            {
                if (DummyUserId.Equals(member.UserID))
                {
                    provider.DeleteMember(member);
                }
            }
        }
        
        protected void PurgeDummySpeakers()
        {
            SpeakerProvider provider = SpeakerManager.DefaultProvider;
            SpeakerCollection speakers = provider.GetAllSpeakers();
            foreach (Speaker speaker in speakers)
            {
                if (DummySpeakerFirstName.Equals(speaker.FirstName) &&
                    DummySpeakerLastName.Equals(speaker.LastName))
                {
                    provider.DeleteSpeaker(speaker);
                }
            }
        }
        
        protected void PurgeDummySponsors()
        {
            SponsorProvider provider = SponsorManager.DefaultProvider;
            SponsorCollection sponsors = provider.GetAllSponsors();
            foreach (Sponsor sponsor in sponsors)
            {
                if (DummySponsorName.Equals(sponsor.Name))
                {
                    Location location = sponsor.Location;
                    provider.DeleteSponsor(sponsor);
                    if (location != null)
                    {
                        DeleteLocation(location);
                    }
                }
            }
        }

        #endregion

        #region "  GetNew Methods  "

        protected Event GetNewEvent()
        {
            EventProvider provider = EventManager.DefaultProvider;

            Event evt = provider.GetNewEvent();
            evt.Title = DummyEventTitle;
            evt.Description = "SQL Server Tips";
            evt.MeetingDate = DateTime.Now;

            // Location is required
            evt.Location = GetNewLocation();

            provider.SaveEvent(evt);
            return evt;
        }

        protected Location GetNewLocation()
        {
            LocationProvider provider = LocationManager.DefaultProvider;

            Location location = provider.GetNewLocation();
            location.ID.Value = -100;
            location.Title = DummyLocationTitle;
            location.Address1 = DummyAddress1;
            location.City = "Milwaukee";
            location.State = "WI";
            location.Zip = "53212";
            provider.SaveLocation(location);
            return location;
        }

        protected void DeleteLocation(Location location)
        {
            LocationProvider provider = LocationManager.DefaultProvider;
            provider.DeleteLocation(location);
        }

        #endregion

    }
}
