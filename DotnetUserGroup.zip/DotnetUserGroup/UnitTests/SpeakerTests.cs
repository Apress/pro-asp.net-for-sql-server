using System;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Speakers;
using NUnit.Framework;

namespace UnitTests
{
    [TestFixture]
    public class SpeakerTests : TestBase
    {

        [SetUp]
        public void SetUp()
        {
        }

        [TearDown]
        public void TearDown()
        {
            PurgeDummySpeakers();
        }

        [Test]
        public void Test101_GetAllSpeakers_Test()
        {
            SpeakerProvider provider = SpeakerManager.DefaultProvider;
            SpeakerCollection speakers = provider.GetAllSpeakers();
            foreach (Speaker speaker in speakers)
            {
                Console.WriteLine(speaker.FullName);
            }
        }
        
        [Test]
        public void Test102_SaveSpeaker_Test()
        {
            SpeakerProvider provider = SpeakerManager.DefaultProvider;
            Speaker speaker = provider.GetNewSpeaker();
            speaker.FirstName = DummySpeakerFirstName;
            speaker.LastName = DummySpeakerLastName;
            speaker.Email = "joe.speaker@dug.org";
            speaker.Phone = "(414) 123-1234";
            provider.SaveSpeaker(speaker);
        }
        
        [Test]
        public void Test103_GetSpeaker_Test()
        {
            SpeakerProvider provider = SpeakerManager.DefaultProvider;
            Speaker speaker = provider.GetNewSpeaker();
            speaker.FirstName = DummySpeakerFirstName;
            speaker.LastName = DummySpeakerLastName;
            speaker.Email = "joe.speaker@dug.org";
            speaker.Phone = "(414) 123-1234";
            DomainKey key = provider.SaveSpeaker(speaker);
            speaker = null;
            speaker = provider.GetSpeaker(key);
            Assert.IsNotNull(speaker);
            Assert.IsTrue(DummySpeakerFirstName.Equals(speaker.FirstName));
            Assert.IsTrue(DummySpeakerLastName.Equals(speaker.LastName));
        }
        
        [Test]
        public void Test104_DeleteSpeaker_Test()
        {
            SpeakerProvider provider = SpeakerManager.DefaultProvider;
            Speaker speaker = provider.GetNewSpeaker();
            speaker.FirstName = DummySpeakerFirstName;
            speaker.LastName = DummySpeakerLastName;
            speaker.Email = "joe.speaker@dug.org";
            speaker.Phone = "(414) 123-1234";
            provider.SaveSpeaker(speaker);
            provider.DeleteSpeaker(speaker);
            speaker = provider.GetSpeaker(speaker.ID);
            Assert.IsNull(speaker);
        }

    }
}
