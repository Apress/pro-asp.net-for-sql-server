using System;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Sponsors;
using DotnetUserGroup.DataAccess.Locations;
using DotnetUserGroup.DataAccess.Events;
using NUnit.Framework;

namespace UnitTests
{
    [TestFixture]
    public class EventTests : TestBase
    {

        [SetUp]
        public void SetUp()
        {
        }

        [TearDown]
        public void TearDown()
        {
            PurgeDummyEvents();
        }

        [Test]
        public void Test101_GetAllEvents_Test()
        {
            EventProvider provider = EventManager.DefaultProvider;
            EventCollection events = provider.GetAllEvents();
            foreach (Event evt in events)
            {
                Console.WriteLine(evt.Title);
            }
        }
        
        [Test]
        public void Test102_SaveEvent_Test()
        {
            EventProvider provider = EventManager.DefaultProvider;

            Event evt = provider.GetNewEvent();
            evt.Title = DummyEventTitle;
            evt.Description = "SQL Server Tips";
            evt.MeetingDate = DateTime.Now;

            // Location is required
            evt.Location = GetNewLocation();

            provider.SaveEvent(evt);
        }
        
        [Test]
        public void Test103_GetEvent_Test()
        {
            EventProvider provider = EventManager.DefaultProvider;

            Location location = GetNewLocation();
            Event evt = provider.GetNewEvent();

            evt.Title = DummyEventTitle;
            evt.Description = "SQL Server Tips";
            evt.MeetingDate = DateTime.Now;
            evt.Location = location;

            DomainKey key = provider.SaveEvent(evt);
            evt = null;
            evt = provider.GetEvent(key);
            Assert.IsNotNull(evt);
            Assert.IsTrue(DummyEventTitle.Equals(evt.Title));
        }
        
        [Test]
        public void Test104_DeleteEvent_Test()
        {
            EventProvider provider = EventManager.DefaultProvider;

            Location location = GetNewLocation();

            Event evt = provider.GetNewEvent();
            evt.Title = DummyEventTitle;
            evt.Description = "SQL Server Tips";
            evt.MeetingDate = DateTime.Now;
            evt.Location = location;
            DomainKey key = provider.SaveEvent(evt);
            provider.DeleteEvent(evt);
            DeleteLocation(location);
            evt = provider.GetEvent(key);
            Assert.IsNull(evt);
        }

        [Test]
        public void Test105_IsEventUsingLocation_Test()
        {
            EventProvider provider = EventManager.DefaultProvider;

            // test for false
            Location location = GetNewLocation();
            bool isUsed = provider.IsUsingLocation(location);
            Assert.IsFalse(isUsed);

            // test for true
            Event evt = provider.GetNewEvent();
            evt.Title = DummyEventTitle;
            evt.Location = location;
            evt.Description = "SQL Server Tips";
            evt.MeetingDate = DateTime.Now;
            provider.SaveEvent(evt);
            isUsed = provider.IsUsingLocation(location);
            Assert.IsTrue(isUsed);
        }

    }
}
