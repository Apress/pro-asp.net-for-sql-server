using System;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Locations;
using NUnit.Framework;

namespace UnitTests
{
    [TestFixture]
    public class LocationsTests : TestBase
    {

        [SetUp]
        public void SetUp()
        {
        }

        [TearDown]
        public void TearDown()
        {
            PurgeDummyLocations();
        }

        [Test]
        public void Test101_GetNewLocation_Test()
        {
            Location location = LocationManager.DefaultProvider.GetNewLocation();
            Assert.IsNotNull(location);
        }

        [Test]
        public void Test102_GetSaveAndDeleteLocation_Test()
        {
            LocationProvider provider = LocationManager.DefaultProvider;
            Location newLocation = provider.GetNewLocation();
            newLocation.Title = DummyLocationTitle;
            newLocation.Address1 = DummyAddress1;
            newLocation.City = "Milwaukee";
            newLocation.State = "WI";
            newLocation.Zip = "53212";

            Assert.IsNotNull(newLocation);
            
            DomainKey key = provider.SaveLocation(newLocation);
            Location savedLocation = provider.GetLocation(key);

            Assert.IsNotNull(savedLocation);
            Assert.IsTrue(DummyAddress1.Equals(savedLocation.Address1));
            Assert.IsTrue("Milwaukee".Equals(savedLocation.City));
            Assert.IsTrue("WI".Equals(savedLocation.State));
            Assert.IsTrue("53212".Equals(savedLocation.Zip));

            provider.DeleteLocation(savedLocation);

        }

        [Test]
        public void Test103_GetAllLocations_Test()
        {
            LocationProvider provider = LocationManager.DefaultProvider;
            LocationCollection locations = provider.GetAllLocations();
            foreach (Location location in locations)
            {
                Console.WriteLine(location.Address1);
            }
        }

    }
}
