using System;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Events;
using DotnetUserGroup.DataAccess.Locations;
using DotnetUserGroup.DataAccess.Members;
using NUnit.Framework;

namespace UnitTests
{
    [TestFixture]
    public class MemberTests : TestBase
    {
        
        [SetUp]
        public void SetUp()
        {
        }

        [TearDown]
        public void TearDown()
        {
            PurgeDummyMembers();
            PurgeDummyEvents();
        }

        [Test]
        public void Test101_GetAllMembers_Test()
        {
            MemberProvider provider = MemberManager.DefaultProvider;
            MemberCollection members = provider.GetAllMembers();
            foreach (Member member in members)
            {
                Console.WriteLine(member.UserID.ToString());
            }
        }
        
        [Test]
        public void Test102_SaveMember_Test()
        {
            MemberProvider provider = MemberManager.DefaultProvider;
            Member member = provider.GetNewMember();
            member.UserID = DummyUserId;
            provider.SaveMember(member);
        }
        
        [Test]
        public void Test103_GetMember_Test()
        {
            MemberProvider provider = MemberManager.DefaultProvider;
            Member member = provider.GetNewMember();

            member.UserID = DummyUserId;

            DomainKey key = provider.SaveMember(member);
            member = null;
            member = provider.GetMember(key);
            Assert.IsNotNull(member);
            Assert.IsTrue(DummyUserId.Equals(member.UserID));
        }
        
        [Test]
        public void Test104_DeleteMember_Test()
        {
            MemberProvider provider = MemberManager.DefaultProvider;
            Member member = provider.GetNewMember();
            member.UserID = DummyUserId;
            DomainKey key = provider.SaveMember(member);
            provider.DeleteMember(member);
            member = provider.GetMember(key);
            Assert.IsNotNull(member);
            Assert.IsFalse(member.IsActive);
        }
 
        [Test]
        public void Test105_RegisterForEvent_Test()
        {
            MemberProvider provider = MemberManager.DefaultProvider;
            Member member = provider.GetNewMember();
            member.UserID = DummyUserId;
            DomainKey key = provider.SaveMember(member);
            Event evt = GetNewEvent();
            int count = provider.GetRegisteredMemberCount(evt);
            // should be 0 for a new event with no registrations
            Assert.IsTrue(count == 0);
            provider.SaveRegistration(member, evt, RegistrationStatus.Yes);
            count = provider.GetRegisteredMemberCount(evt);
            // should be 1 with new registration
            Assert.IsTrue(count == 1);
            provider.SaveRegistration(member, evt, RegistrationStatus.No);
            count = provider.GetRegisteredMemberCount(evt);
            // should be 0 again with the only registration set to no
            Assert.IsTrue(count == 0);
        }

    }
}
