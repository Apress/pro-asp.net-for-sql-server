using System;
using System.Configuration;
using System.ServiceModel;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Events;
using DotnetUserGroup.DataAccess.Locations;
using DotnetUserGroup.DataAccess.Sponsors;
using DotnetUserGroup.DataAccess.LinqProviders.Data;
using DotnetUserGroup.DataAccess.LinqProviders.Events;

//using System.Reflection;
using System.Query;
using System.Expressions;
using System.Data;
using System.Data.DLinq;

using NUnit.Framework;

namespace UnitTests
{
    [TestFixture]
    public class LinqTests : TestBase
    {
        
        [SetUp]
        public void SetUp()
        {
        }

        [TearDown]
        public void TearDown()
        {
            PurgeDummyEvents();
        }

        [Test]
        public void Test101_ReadConfiguration_Test()
        {
            string connString = ConfigurationManager.ConnectionStrings["dug"].ConnectionString;
            DugDataContext dataContext = new DugDataContext(connString);
        }

        [Test]
        public void Test102_GetAllEvents_Test()
        {
            string connString = ConfigurationManager.ConnectionStrings["dug"].ConnectionString;
            DugDataContext db = new DugDataContext(connString);
            StoredProcedureResult<EventResult> eventResults = db.GetAllEvents();
            foreach (EventResult eventResult in eventResults)
            {
                Console.WriteLine("Title: " + eventResult.Title);
            }


        }
        
        [Test]
        public void Test103_GetThree_Test()
        {
            if (EventManager.DefaultProvider.Name.Equals("LinqEventProvider"))
            {
                Assert.IsTrue(true);
                EventProvider provider = EventManager.DefaultProvider;
                Event evt1 = provider.GetNewEvent();
                evt1.Title = DummyEventTitle;
                evt1.Description = "SQL Server Tips";
                evt1.MeetingDate = DateTime.Now;
                evt1.Location = GetNewLocation();
                DomainKey key1 = provider.SaveEvent(evt1);
                Console.WriteLine("Event 1 ID: " + key1.Value.ToString());
                
                Event evt2 = provider.GetNewEvent();
                evt2.Title = DummyEventTitle;
                evt2.Description = "SQL Server Tips";
                evt2.MeetingDate = DateTime.Now;
                evt2.Location = GetNewLocation();
                DomainKey key2 = provider.SaveEvent(evt2);
                Console.WriteLine("Event 2 ID: " + key2.Value.ToString());
                
                Event evt3 = provider.GetNewEvent();
                evt3.Title = DummyEventTitle;
                evt3.Description = "SQL Server Tips";
                evt3.MeetingDate = DateTime.Now;
                evt3.Location = GetNewLocation();
                DomainKey key3 = provider.SaveEvent(evt3);
                Console.WriteLine("Event 3 ID: " + key3.Value.ToString());

                EventCollection events = provider.GetAllEvents();
                Assert.IsTrue(events.Count == 3);
                foreach (Event evt in events)
                {
                    Console.WriteLine(evt.ID.Value + ": " + evt.Title);
                }
            }
            else
            {
                Console.WriteLine("LINQ Testing Disabled");
                Assert.IsTrue(true);
            }
        }

        [Test]
        public void Test103_IsEventUsingLocation_Test()
        {
            EventProvider provider = EventManager.DefaultProvider;

            // test for false
            Location location = GetNewLocation();
            bool isUsed = provider.IsUsingLocation(location);
            Assert.IsFalse(isUsed);

            // test for true
            Event evt = provider.GetNewEvent();
            evt.Title = DummyEventTitle;
            evt.Location = location;
            evt.Description = "SQL Server Tips";
            evt.MeetingDate = DateTime.Now;
            provider.SaveEvent(evt);
            isUsed = provider.IsUsingLocation(location);
            Assert.IsTrue(isUsed);
        }

    }
}
