using System;
using System.Collections.Generic;
using System.Text;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Locations;
using DotnetUserGroup.DataAccess.JobContacts;
using DotnetUserGroup.DataAccess.Jobs;
using NUnit.Framework;

namespace UnitTests
{
    [TestFixture]
    public class JobContactTests : TestBase
    {

        [SetUp]
        public void SetUp()
        {
        }

        [TearDown]
        public void TearDown()
        {
            PurgeDummyJobContacts();
        }

        [Test]
        public void Test101_GetAllJobContacts_Test()
        {
            JobContactProvider provider = JobContactManager.DefaultProvider;
            JobContactCollection jobContacts = provider.GetAllJobContacts();
            foreach (JobContact jobContact in jobContacts)
            {
                Console.WriteLine(jobContact.Name);
            }
        }
        
        [Test]
        public void Test102_SaveJobContact_Test()
        {
            JobContactProvider provider = JobContactManager.DefaultProvider;
            JobContact jobContact = provider.GetNewJobContact();
            jobContact.Name = DummyJobContactName;
            jobContact.Phone = "(123) 123-1234";
            jobContact.Email = "job@employer.com";
            jobContact.WebsiteUrl = "http://www.employer.com/";
            provider.SaveJobContact(jobContact);
        }
        
        [Test]
        public void Test103_GetJobContact_Test()
        {
            JobContactProvider provider = JobContactManager.DefaultProvider;
            JobContact jobContact = provider.GetNewJobContact();
            jobContact.Name = DummyJobContactName;
            jobContact.Phone = "(123) 123-1234";
            jobContact.Email = "job@employer.com";
            jobContact.WebsiteUrl = "http://www.employer.com/";
            DomainKey key = provider.SaveJobContact(jobContact);
            jobContact = null;
            jobContact = provider.GetJobContact(key);
            Assert.IsNotNull(jobContact);
            Assert.IsTrue(DummyJobContactName.Equals(jobContact.Name));
        }
        
        [Test]
        public void Test104_DeleteJobContact_Test()
        {
            JobContactProvider provider = JobContactManager.DefaultProvider;
            JobContact jobContact = provider.GetNewJobContact();
            jobContact.Name = DummyJobContactName;
            jobContact.Phone = "(123) 123-1234";
            jobContact.Email = "job@employer.com";
            jobContact.WebsiteUrl = "http://www.employer.com/";
            provider.SaveJobContact(jobContact);
            provider.DeleteJobContact(jobContact);
            jobContact = provider.GetJobContact(jobContact.ID);
            Assert.IsNull(jobContact);
        }

        [Test]
        public void Test105_IsJobContactUsingLocation_Test()
        {
            JobContactProvider provider = JobContactManager.DefaultProvider;

            // test for false
            Location location = GetNewLocation();
            bool isUsed = provider.IsUsingLocation(location);
            Assert.IsFalse(isUsed);

            // test for true
            JobContact jobContact = provider.GetNewJobContact();
            jobContact.Name = DummyJobContactName;
            jobContact.Phone = "(123) 123-1234";
            jobContact.Email = "job@employer.com";
            jobContact.WebsiteUrl = "http://www.employer.com/";
            jobContact.Location = location;
            provider.SaveJobContact(jobContact);
            isUsed = provider.IsUsingLocation(location);
            Assert.IsTrue(isUsed);
        }

    }
}
