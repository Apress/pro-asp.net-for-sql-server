using System;
using System.ServiceModel;
using DotnetUserGroup.DataAccess.Common;
using DotnetUserGroup.DataAccess.Events;
using DotnetUserGroup.DataAccess.Locations;
using DotnetUserGroup.DataAccess.Sponsors;
using DotnetUserGroup.DataAccess.WcfProviders.Common;
using DotnetUserGroup.DataAccess.WcfProviders.Events;
using NUnit.Framework;

namespace UnitTests
{
    [TestFixture]
    public class WcfTests
    {
        private string dummyLocationTitle = "Dummy Location";
        private string dummyEventTitle = "Dummy Event";
        private string dummyAddress1 = "123 Dummy Road";
        
        [SetUp]
        public void SetUp()
        {
            if (WcfHelper.IsSelfHosting(typeof(IEventService)))
            {
                EventServiceHost.Instance.StartEventService();
            }
        }

        [TearDown]
        public void TearDown()
        {
            try
            {
                EventProvider provider = EventManager.DefaultProvider;
                EventCollection events = provider.GetAllEvents();
                foreach (Event evt in events)
                {
                    if (dummyEventTitle.Equals(evt.Title))
                    {
                        Location location = evt.Location;
                        provider.DeleteEvent(evt);
                        DeleteLocation(location);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unclean Tear Down: " + ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
            if (WcfHelper.IsSelfHosting(typeof(IEventService)))
            {
                EventServiceHost.Instance.StopEventService();
            }
        }

        [Test]
        public void Test101_ReadConfiguration_Test()
        {
            DugServiceConfiguration sectionGroup =
                DugServiceConfiguration.GetConfiguration();
            Assert.IsNotNull(sectionGroup, "sectionGroup");
            EventServiceSection section = sectionGroup.EventServiceSection;
            Assert.IsNotNull(section, "section");
        }

        [Test]
        public void Test102_GetThreeEvents_Test()
        {
            // only run test when WcfEventProvider is configured
            if (EventManager.DefaultProvider.Name.Equals("WcfEventProvider"))
            {
                Assert.IsTrue(true);
                EventProvider provider = EventManager.DefaultProvider;
                Event evt1 = provider.GetNewEvent();
                evt1.Title = dummyEventTitle;
                evt1.Description = "SQL Server Tips";
                evt1.MeetingDate = DateTime.Now;
                evt1.Location = GetNewLocation();
                DomainKey key1 = provider.SaveEvent(evt1);
                Console.WriteLine("Event 1 ID: " + key1.Value.ToString());
                
                Event evt2 = provider.GetNewEvent();
                evt2.Title = dummyEventTitle;
                evt2.Description = "SQL Server Tips";
                evt2.MeetingDate = DateTime.Now;
                evt2.Location = GetNewLocation();
                DomainKey key2 = provider.SaveEvent(evt2);
                Console.WriteLine("Event 2 ID: " + key2.Value.ToString());
                
                Event evt3 = provider.GetNewEvent();
                evt3.Title = dummyEventTitle;
                evt3.Description = "SQL Server Tips";
                evt3.MeetingDate = DateTime.Now;
                evt3.Location = GetNewLocation();
                DomainKey key3 = provider.SaveEvent(evt3);
                Console.WriteLine("Event 3 ID: " + key3.Value.ToString());

                EventCollection events = provider.GetAllEvents();
                int count = 0;
                
                foreach (Event evt in events)
                {
                    Console.WriteLine(evt.ID.Value + ": " + evt.Title);
                    if (dummyEventTitle.Equals(evt.Title))
                    {
                        count++;
                    }
                }
                Assert.IsTrue(count == 3, "Expected 3 event records: " + count);
            }
            else
            {
                Console.WriteLine("WCF Testing Disabled");
                Assert.IsTrue(true);
            }
        }

        private Location GetNewLocation()
        {
            LocationProvider provider = LocationManager.DefaultProvider;

            Location location = provider.GetNewLocation();
            location.ID.Value = -100;
            location.Title = dummyLocationTitle;
            location.Address1 = dummyAddress1;
            location.City = "Milwaukee";
            location.State = "WI";
            location.Zip = "53212";
            provider.SaveLocation(location);
            return location;
        }

        private void DeleteLocation(Location location)
        {
            LocationProvider provider = LocationManager.DefaultProvider;
            provider.DeleteLocation(location);
        }

    }
}
